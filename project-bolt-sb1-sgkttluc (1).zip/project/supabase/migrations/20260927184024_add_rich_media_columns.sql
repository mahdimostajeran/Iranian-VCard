/* Add rich media columns to profiles and create storage buckets */
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS cover_image_url text DEFAULT '';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS audio_intro_url text DEFAULT '';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS video_url text DEFAULT '';
