/* Storage policies for covers, audio, video buckets */
DROP POLICY IF EXISTS "public_read_covers" ON storage.objects;
CREATE POLICY "public_read_covers" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'covers');
DROP POLICY IF EXISTS "insert_own_cover" ON storage.objects;
CREATE POLICY "insert_own_cover" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (bucket_id = 'covers' AND (storage.foldername(name))[1] = auth.uid()::text);
DROP POLICY IF EXISTS "update_own_cover" ON storage.objects;
CREATE POLICY "update_own_cover" ON storage.objects FOR UPDATE
  TO authenticated USING (bucket_id = 'covers' AND (storage.foldername(name))[1] = auth.uid()::text)
  WITH CHECK (bucket_id = 'covers' AND (storage.foldername(name))[1] = auth.uid()::text);
DROP POLICY IF EXISTS "delete_own_cover" ON storage.objects;
CREATE POLICY "delete_own_cover" ON storage.objects FOR DELETE
  TO authenticated USING (bucket_id = 'covers' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "public_read_audio" ON storage.objects;
CREATE POLICY "public_read_audio" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'audio');
DROP POLICY IF EXISTS "insert_own_audio" ON storage.objects;
CREATE POLICY "insert_own_audio" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (bucket_id = 'audio' AND (storage.foldername(name))[1] = auth.uid()::text);
DROP POLICY IF EXISTS "update_own_audio" ON storage.objects;
CREATE POLICY "update_own_audio" ON storage.objects FOR UPDATE
  TO authenticated USING (bucket_id = 'audio' AND (storage.foldername(name))[1] = auth.uid()::text)
  WITH CHECK (bucket_id = 'audio' AND (storage.foldername(name))[1] = auth.uid()::text);
DROP POLICY IF EXISTS "delete_own_audio" ON storage.objects;
CREATE POLICY "delete_own_audio" ON storage.objects FOR DELETE
  TO authenticated USING (bucket_id = 'audio' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "public_read_video" ON storage.objects;
CREATE POLICY "public_read_video" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'video');
DROP POLICY IF EXISTS "insert_own_video" ON storage.objects;
CREATE POLICY "insert_own_video" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (bucket_id = 'video' AND (storage.foldername(name))[1] = auth.uid()::text);
DROP POLICY IF EXISTS "update_own_video" ON storage.objects;
CREATE POLICY "update_own_video" ON storage.objects FOR UPDATE
  TO authenticated USING (bucket_id = 'video' AND (storage.foldername(name))[1] = auth.uid()::text)
  WITH CHECK (bucket_id = 'video' AND (storage.foldername(name))[1] = auth.uid()::text);
DROP POLICY IF EXISTS "delete_own_video" ON storage.objects;
CREATE POLICY "delete_own_video" ON storage.objects FOR DELETE
  TO authenticated USING (bucket_id = 'video' AND (storage.foldername(name))[1] = auth.uid()::text);
