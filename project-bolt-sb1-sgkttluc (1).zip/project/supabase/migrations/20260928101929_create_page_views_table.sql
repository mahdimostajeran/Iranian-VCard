-- Page views tracking table
CREATE TABLE IF NOT EXISTS page_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  viewed_at timestamptz NOT NULL DEFAULT now()
);

-- vCard downloads counter on profiles
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS vcard_downloads integer NOT NULL DEFAULT 0;

-- Enable RLS on page_views
ALTER TABLE page_views ENABLE ROW LEVEL SECURITY;

-- Anyone can insert a page view (public cards are viewable by anon)
CREATE POLICY "insert_page_views" ON page_views FOR INSERT
  TO anon, authenticated WITH CHECK (true);

-- Users can read their own page views
CREATE POLICY "select_own_page_views" ON page_views FOR SELECT
  TO authenticated USING (profile_id = auth.uid());

-- Index for analytics queries
CREATE INDEX IF NOT EXISTS idx_page_views_profile_id ON page_views(profile_id);
CREATE INDEX IF NOT EXISTS idx_page_views_viewed_at ON page_views(viewed_at);
