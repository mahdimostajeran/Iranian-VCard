/*
# Admin Panel: orders table, admins table, is_admin() function, admin RLS policies

1. New Tables
- `orders` — business card order requests from users/customers.
  - id (uuid, primary key, default gen_random_uuid())
  - user_id (uuid, nullable — links to auth.users if the orderer has an account)
  - full_name (text, not null)
  - phone (text, not null)
  - email (text, nullable)
  - card_type (text, not null — 'digital' | 'hybrid_nfc')
  - quantity (integer, not null, default 1)
  - notes (text, nullable)
  - status (text, not null, default 'pending' — 'pending' | 'confirmed' | 'shipped' | 'cancelled')
  - created_at (timestamptz, default now())
- `admins` — whitelist of admin user IDs.
  - id (uuid, primary key, references auth.users(id) on delete cascade)
  - created_at (timestamptz, default now())

2. Functions
- `public.is_admin()` — SECURITY DEFINER function returning true if auth.uid() exists in admins table.
  Used in RLS policies so admin users can manage all profiles and orders.

3. Security (RLS)
- orders: enabled. Admins have full CRUD; regular authenticated users can insert (place orders) and read their own.
- admins: enabled. Only admins can SELECT/INSERT/DELETE (self-manage is prevented for non-admins).
- profiles: existing owner-scoped policies kept; new admin-scoped SELECT/UPDATE/DELETE policies added so admins can manage all profiles.
*/

-- =========================================================
-- admins table
-- =========================================================
CREATE TABLE IF NOT EXISTS public.admins (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.admins ENABLE ROW LEVEL SECURITY;

-- is_admin() helper (SECURITY DEFINER so it can read admins table regardless of caller RLS)
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admins WHERE id = auth.uid()
  );
$$;

-- admins table policies: only existing admins can manage the admin list
DROP POLICY IF EXISTS "admins_select_all" ON public.admins;
CREATE POLICY "admins_select_all" ON public.admins
  FOR SELECT TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS "admins_insert_admin" ON public.admins;
CREATE POLICY "admins_insert_admin" ON public.admins
  FOR INSERT TO authenticated
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "admins_delete_admin" ON public.admins;
CREATE POLICY "admins_delete_admin" ON public.admins
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- =========================================================
-- orders table
-- =========================================================
CREATE TABLE IF NOT EXISTS public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  full_name text NOT NULL,
  phone text NOT NULL,
  email text,
  card_type text NOT NULL CHECK (card_type IN ('digital', 'hybrid_nfc')),
  quantity integer NOT NULL DEFAULT 1 CHECK (quantity > 0),
  notes text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'shipped', 'cancelled')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Any authenticated user can place an order (insert)
DROP POLICY IF EXISTS "orders_insert_own" ON public.orders;
CREATE POLICY "orders_insert_own" ON public.orders
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- Users can read their own orders; admins can read all
DROP POLICY IF EXISTS "orders_select_own_or_admin" ON public.orders;
CREATE POLICY "orders_select_own_or_admin" ON public.orders
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_admin());

-- Only admins can update orders (change status etc.)
DROP POLICY IF EXISTS "orders_update_admin" ON public.orders;
CREATE POLICY "orders_update_admin" ON public.orders
  FOR UPDATE TO authenticated
  USING (public.is_admin()) WITH CHECK (public.is_admin());

-- Only admins can delete orders
DROP POLICY IF EXISTS "orders_delete_admin" ON public.orders;
CREATE POLICY "orders_delete_admin" ON public.orders
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- =========================================================
-- profiles: add admin-scoped policies (keep existing owner policies)
-- =========================================================
DROP POLICY IF EXISTS "profiles_admin_select_all" ON public.profiles;
CREATE POLICY "profiles_admin_select_all" ON public.profiles
  FOR SELECT TO authenticated
  USING (public.is_admin());

DROP POLICY IF EXISTS "profiles_admin_update_all" ON public.profiles;
CREATE POLICY "profiles_admin_update_all" ON public.profiles
  FOR UPDATE TO authenticated
  USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "profiles_admin_delete_all" ON public.profiles;
CREATE POLICY "profiles_admin_delete_all" ON public.profiles
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- Index for faster admin queries
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON public.orders(created_at DESC);