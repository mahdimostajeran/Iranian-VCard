/*
# Create Digital Business Card Platform Schema

## Overview
Creates the full schema for a Persian RTL digital business card platform (similar to HiHello/Popl).
Users sign up, build a profile card, share it via username/QR, and connect with others.

## New Tables

1. `profiles`
   - id (uuid, PK, references auth.users, ON DELETE CASCADE)
   - username (text, unique) — public URL slug for the card (/:username)
   - full_name (text) — display name
   - headline (text) — job title / catchy tagline
   - bio (text) — short about
   - email (text) — contact email shown on card
   - phone (text) — contact phone
   - website (text) — personal/company website
   - avatar_url (text) — Supabase Storage public URL
   - template_type (text, default 'personal') — 'personal' | 'corporate'
   - created_at (timestamptz)

2. `skills`
   - id (uuid, PK)
   - profile_id (uuid, FK profiles, ON DELETE CASCADE)
   - skill_name (text)

3. `social_links`
   - id (uuid, PK)
   - profile_id (uuid, FK profiles, ON DELETE CASCADE)
   - platform (text) — 'linkedin' | 'instagram' | 'telegram' | 'whatsapp'
   - url (text)

4. `connections`
   - id (uuid, PK)
   - follower_id (uuid, FK profiles) — the user who follows
   - following_id (uuid, FK profiles) — the user being followed
   - created_at (timestamptz)
   - UNIQUE(follower_id, following_id) to prevent duplicate follows

## Security (RLS)

- `profiles`: SELECT is public (anon+authenticated) so public cards load without login.
  INSERT/UPDATE/DELETE are owner-only (authenticated, auth.uid() = id).
- `skills`: SELECT public. INSERT/UPDATE/DELETE owner-only via profile ownership check.
- `social_links`: SELECT public. INSERT/UPDATE/DELETE owner-only via profile ownership check.
- `connections`: SELECT — authenticated users can see connections involving themselves
  (as follower or following). INSERT — authenticated, follower_id must be self.
  DELETE — authenticated, follower_id must be self.

## Notes
- Public SELECT uses USING (true) intentionally: business cards are public by design.
*/

-- profiles
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  full_name text NOT NULL DEFAULT '',
  headline text DEFAULT '',
  bio text DEFAULT '',
  email text DEFAULT '',
  phone text DEFAULT '',
  website text DEFAULT '',
  avatar_url text DEFAULT '',
  template_type text NOT NULL DEFAULT 'personal',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_profiles" ON profiles;
CREATE POLICY "public_read_profiles" ON profiles FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
  TO authenticated USING (auth.uid() = id);

-- skills
CREATE TABLE IF NOT EXISTS skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  skill_name text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE skills ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_skills" ON skills;
CREATE POLICY "public_read_skills" ON skills FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_skills" ON skills;
CREATE POLICY "insert_own_skills" ON skills FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = skills.profile_id AND p.id = auth.uid())
  );

DROP POLICY IF EXISTS "update_own_skills" ON skills;
CREATE POLICY "update_own_skills" ON skills FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = skills.profile_id AND p.id = auth.uid())
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = skills.profile_id AND p.id = auth.uid())
  );

DROP POLICY IF EXISTS "delete_own_skills" ON skills;
CREATE POLICY "delete_own_skills" ON skills FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = skills.profile_id AND p.id = auth.uid())
  );

-- social_links
CREATE TABLE IF NOT EXISTS social_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  platform text NOT NULL,
  url text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE (profile_id, platform)
);

ALTER TABLE social_links ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_social_links" ON social_links;
CREATE POLICY "public_read_social_links" ON social_links FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_social_links" ON social_links;
CREATE POLICY "insert_own_social_links" ON social_links FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = social_links.profile_id AND p.id = auth.uid())
  );

DROP POLICY IF EXISTS "update_own_social_links" ON social_links;
CREATE POLICY "update_own_social_links" ON social_links FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = social_links.profile_id AND p.id = auth.uid())
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = social_links.profile_id AND p.id = auth.uid())
  );

DROP POLICY IF EXISTS "delete_own_social_links" ON social_links;
CREATE POLICY "delete_own_social_links" ON social_links FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = social_links.profile_id AND p.id = auth.uid())
  );

-- connections
CREATE TABLE IF NOT EXISTS connections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  following_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE (follower_id, following_id),
  CHECK (follower_id <> following_id)
);

ALTER TABLE connections ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_connections" ON connections;
CREATE POLICY "select_own_connections" ON connections FOR SELECT
  TO authenticated USING (auth.uid() = follower_id OR auth.uid() = following_id);

DROP POLICY IF EXISTS "insert_own_connections" ON connections;
CREATE POLICY "insert_own_connections" ON connections FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = follower_id);

DROP POLICY IF EXISTS "delete_own_connections" ON connections;
CREATE POLICY "delete_own_connections" ON connections FOR DELETE
  TO authenticated USING (auth.uid() = follower_id);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_profiles_username ON profiles (username);
CREATE INDEX IF NOT EXISTS idx_skills_profile_id ON skills (profile_id);
CREATE INDEX IF NOT EXISTS idx_social_links_profile_id ON social_links (profile_id);
CREATE INDEX IF NOT EXISTS idx_connections_follower_id ON connections (follower_id);
CREATE INDEX IF NOT EXISTS idx_connections_following_id ON connections (following_id);
