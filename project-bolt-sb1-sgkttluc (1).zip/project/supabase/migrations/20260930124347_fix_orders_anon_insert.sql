/*
# Fix orders RLS: allow anon users to submit orders

The OrderPage is public — visitors don't need to be logged in to request an NFC card.
The existing insert policy was scoped `TO authenticated` only, causing RLS rejections
for unauthenticated users. This migration:
1. Drops the authenticated-only insert policy.
2. Creates a new insert policy allowing both anon and authenticated to insert orders
   (with user_id nullable, so anonymous orders work).
3. Adds an anon SELECT policy so unauthenticated users can see their own order
   confirmation if needed (scoped by matching phone/email is not possible in RLS
   without exposing data — instead we keep SELECT to authenticated + admin only).
*/

DROP POLICY IF EXISTS "orders_insert_own" ON public.orders;

CREATE POLICY "orders_insert_any" ON public.orders
  FOR INSERT TO anon, authenticated
  WITH CHECK (true);
