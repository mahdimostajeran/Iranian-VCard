import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    // جلوگیری از ری‌استارت خودکار با تغییر فایل‌های غیرضروری
    watch: {
      ignored: [
        '**/.env*',
        '**/node_modules/**',
        '**/dist/**',
        '**/.git/**',
        '**/*.md',
      ],
    },
    hmr: {
      // کاهش حساسیت HMR در Bolt.new
      overlay: false,
    },
  },
  // کاهش frequency of full reloads
  optimizeDeps: {
    include: ['react', 'react-dom', 'react-router-dom'],
  },
});