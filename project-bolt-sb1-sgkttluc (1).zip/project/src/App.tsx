import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/hooks/useAuth';
import { LandingPage } from '@/pages/LandingPage';
import { AuthPage } from '@/pages/AuthPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { PublicCardPage } from '@/pages/PublicCardPage';
import { PricingPage } from '@/pages/PricingPage';
import { AdminPage } from '@/pages/AdminPage';
import { OrderPage } from '@/pages/OrderPage';
import { PaymentCallbackPage } from '@/pages/PaymentCallbackPage';
import { AboutPage } from '@/pages/AboutPage';
import { Card3DPage } from '@/pages/Card3DPage';
import { B2BLandingPage } from '@/pages/B2BLandingPage';
import { EditCardPage } from '@/pages/EditCardPage';
import { QuickShareFab } from '@/components/QuickShareFab';
import type { ReactNode } from 'react';

function ProtectedRoute({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center gradient-mesh">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary-200 border-t-primary-600" />
      </div>
    );
  }
  if (!user) return <Navigate to="/auth" replace />;
  return <>{children}</>;
}

function AppRoutes() {
  return (
    <>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/auth" element={<AuthPage />} />
        <Route path="/login" element={<Navigate to="/auth" replace />} />
        <Route path="/signup" element={<Navigate to="/auth?mode=signup" replace />} />
        <Route path="/pricing" element={<PricingPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/order" element={<OrderPage />} />
        <Route path="/b2b" element={<B2BLandingPage />} />
        <Route path="/payment/callback" element={<PaymentCallbackPage />} />

        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <DashboardPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin"
          element={
            <ProtectedRoute>
              <AdminPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/card/edit/:cardId"
          element={
            <ProtectedRoute>
              <EditCardPage />
            </ProtectedRoute>
          }
        />

        <Route path="/card3d/:username" element={<Card3DPage />} />
        <Route path="/card3d" element={<Navigate to="/" replace />} />

        <Route path="/:username" element={<PublicCardPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>

      <QuickShareFab />
    </>
  );
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;