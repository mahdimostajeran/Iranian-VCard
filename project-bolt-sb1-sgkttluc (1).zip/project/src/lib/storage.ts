import imageCompression from 'browser-image-compression';
import { supabase } from '@/lib/supabase';

export async function uploadAvatar(file: File, userId: string): Promise<string> {
  const compressed = await imageCompression(file, {
    maxSizeMB: 0.5,
    maxWidthOrHeight: 512,
    useWebWorker: true,
    fileType: 'image/jpeg',
  });

  const path = `${userId}/avatar.jpg`;
  const { error: upErr } = await supabase.storage
    .from('avatars')
    .upload(path, compressed, { upsert: true });
  if (upErr) throw upErr;

  const { data } = supabase.storage.from('avatars').getPublicUrl(path);
  return `${data.publicUrl}?t=${Date.now()}`;
}

export async function uploadCoverImage(file: File, userId: string): Promise<string> {
  if (file.size > 2 * 1024 * 1024) throw new Error('حجم تصویر کاور نباید بیشتر از ۲ مگابایت باشد');
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
    throw new Error('فرمت کاور باید JPG یا PNG باشد');
  }

  const compressed = await imageCompression(file, {
    maxSizeMB: 1,
    maxWidthOrHeight: 1200,
    useWebWorker: true,
    fileType: 'image/jpeg',
  });

  const path = `${userId}/cover.jpg`;
  const { error } = await supabase.storage.from('covers').upload(path, compressed, { upsert: true });
  if (error) throw error;

  const { data } = supabase.storage.from('covers').getPublicUrl(path);
  return `${data.publicUrl}?t=${Date.now()}`;
}

export async function uploadAudio(file: File, userId: string): Promise<string> {
  if (file.size > 5 * 1024 * 1024) throw new Error('حجم فایل صوتی نباید بیشتر از ۵ مگابایت باشد');
  if (!['audio/mpeg', 'audio/mp3', 'audio/m4a', 'audio/x-m4a', 'audio/mp4'].includes(file.type)) {
    throw new Error('فرمت صوتی باید MP3 یا M4A باشد');
  }

  const ext = file.name.split('.').pop() || 'mp3';
  const path = `${userId}/intro.${ext}`;
  const { error } = await supabase.storage.from('audio').upload(path, file, { upsert: true });
  if (error) throw error;

  const { data } = supabase.storage.from('audio').getPublicUrl(path);
  return `${data.publicUrl}?t=${Date.now()}`;
}

export async function uploadVideo(file: File, userId: string): Promise<string> {
  if (file.size > 20 * 1024 * 1024) throw new Error('حجم ویدیو نباید بیشتر از ۲۰ مگابایت باشد');
  if (!['video/mp4'].includes(file.type)) {
    throw new Error('فرمت ویدیو باید MP4 باشد');
  }

  const path = `${userId}/intro.mp4`;
  const { error } = await supabase.storage.from('video').upload(path, file, { upsert: true });
  if (error) throw error;

  const { data } = supabase.storage.from('video').getPublicUrl(path);
  return `${data.publicUrl}?t=${Date.now()}`;
}

/**
 * Delete a file from a storage bucket.
 * Used for removing avatar, cover, audio, or video.
 */
export async function deleteFile(
  bucket: 'avatars' | 'covers' | 'audio' | 'video',
  userId: string,
  filename: string
): Promise<void> {
  const path = `${userId}/${filename}`;
  const { error } = await supabase.storage.from(bucket).remove([path]);
  if (error) throw error;
}