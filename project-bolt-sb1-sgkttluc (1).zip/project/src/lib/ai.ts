export interface AIGenerateResult {
  headline: string;
  bio: string;
  theme: string;
}

export async function generateCardContent(prompt: string): Promise<AIGenerateResult> {
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;

  if (!apiKey) {
    return mockAIGenerate(prompt);
  }

  const systemPrompt = `You are a professional copywriter for digital business cards. Based on the user's description, generate a compelling headline (تیتر جذاب) and a professional bio (بیوگرافی حرفه‌ای) in Persian. Return ONLY a JSON object with keys "headline" and "bio". Both should be in Persian. Keep the headline under 50 characters and the bio under 200 characters.`;

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: prompt },
      ],
      temperature: 0.7,
      max_tokens: 300,
    }),
  });

  if (!response.ok) {
    throw new Error(`خطا در ارتباط با سرویس هوش مصنوعی (${response.status})`);
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content ?? '';

  try {
    const parsed = JSON.parse(content);
    return {
      headline: parsed.headline || 'متخصص حرفه‌ای',
      bio: parsed.bio || '',
      theme: 'teal',
    };
  } catch {
    return mockAIGenerate(prompt);
  }
}

async function mockAIGenerate(prompt: string): Promise<AIGenerateResult> {
  await new Promise((resolve) => setTimeout(resolve, 2000));

  const lower = prompt.toLowerCase();
  let headline = 'متخصص حرفه‌ای';
  let bio = 'با تجربه و اشتیاق برای ارائه بهترین خدمات به مشتریان.';

  if (lower.includes('real estate') || lower.includes('املاک') || lower.includes('مشاور')) {
    headline = 'مشاور املاک حرفه‌ای';
    bio = 'با سال‌ها تجربه در بازار املاک، به شما کمک می‌کنم بهترین تصمیم را برای خرید و فروش ملک خود بگیرید.';
  } else if (lower.includes('developer') || lower.includes('برنامه') || lower.includes('توسعه')) {
    headline = 'توسعه‌دهنده نرم‌افزار';
    bio = 'علاقه‌مند به ساخت محصولات دیجیتال که زندگی مردم را بهتر می‌کنند. متخصص در React و TypeScript.';
  } else if (lower.includes('design') || lower.includes('طراح')) {
    headline = 'طراح محصول و رابط کاربری';
    bio = 'خلق تجربه‌های دیجیتال زیبا و کاربردی که کاربران عاشقشان می‌شوند.';
  } else if (lower.includes('marketing') || lower.includes('بازاریاب')) {
    headline = 'متخصص بازاریابی دیجیتال';
    bio = 'کمک به برندها برای رشد و دیده شدن در فضای دیجیتال با استراتژی‌های نوآورانه.';
  } else if (prompt.trim().length > 0) {
    headline = 'متخصص حرفه‌ای';
    bio = `بر اساس توضیحات شما: ${prompt.slice(0, 120)}${prompt.length > 120 ? '...' : ''}`;
  }

  return { headline, bio, theme: 'teal' };
}
