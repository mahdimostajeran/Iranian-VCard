import { supabase } from '@/lib/supabase';
import type {
  Profile,
  ProfileWithRelations,
  SocialLink,
  Skill,
  Platform,
  CustomField,
} from '@/types';

export async function getProfileByUsername(username: string): Promise<ProfileWithRelations | null> {
  const { data: profile, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('username', username)
    .maybeSingle();
  if (error) throw error;
  if (!profile) return null;

  const [{ data: skills }, { data: socialLinks }] = await Promise.all([
    supabase.from('skills').select('*').eq('profile_id', profile.id),
    supabase
      .from('social_links')
      .select('*')
      .eq('profile_id', profile.id)
      .order('sort_order', { ascending: true }),
  ]);

  return {
    ...profile,
    skills: (skills as Skill[]) ?? [],
    social_links: (socialLinks as SocialLink[]) ?? [],
  };
}

export async function getMyProfile(): Promise<ProfileWithRelations | null> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const { data: profile, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .maybeSingle();
  if (error) throw error;
  if (!profile) return null;

  const [{ data: skills }, { data: socialLinks }] = await Promise.all([
    supabase.from('skills').select('*').eq('profile_id', profile.id),
    supabase
      .from('social_links')
      .select('*')
      .eq('profile_id', profile.id)
      .order('sort_order', { ascending: true }),
  ]);

  return {
    ...profile,
    skills: (skills as Skill[]) ?? [],
    social_links: (socialLinks as SocialLink[]) ?? [],
  };
}

export async function upsertProfile(data: Partial<Profile>): Promise<Profile> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('Not authenticated');

  const { data: existing } = await supabase
    .from('profiles')
    .select('id')
    .eq('id', user.id)
    .maybeSingle();

  let result, error;

  if (existing) {
    const res = await supabase
      .from('profiles')
      .update({ ...data, updated_at: new Date().toISOString() })
      .eq('id', user.id)
      .select()
      .single();
    result = res.data;
    error = res.error;
  } else {
    const res = await supabase
      .from('profiles')
      .insert({ id: user.id, ...data })
      .select()
      .single();
    result = res.data;
    error = res.error;
  }

  if (error) {
    console.error('[Profiles] Operation FAILED:', error);
    throw error;
  }
  return result as Profile;
}

export async function checkUsernameAvailable(username: string): Promise<boolean> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  const { data } = await supabase
    .from('profiles')
    .select('id')
    .eq('username', username)
    .maybeSingle();
  if (!data) return true;
  return data.id === user?.id;
}

export async function updateSkills(profileId: string, skills: string[]): Promise<void> {
  await supabase.from('skills').delete().eq('profile_id', profileId);
  if (skills.length === 0) return;
  const rows = skills.map((s, i) => ({
    profile_id: profileId,
    skill_name: s,
    sort_order: i,
  }));
  const { error } = await supabase.from('skills').insert(rows);
  if (error) throw error;
}

/**
 * لینک‌های اجتماعی — نامحدود با sort_order
 */
export async function updateSocialLinks(
  profileId: string,
  links: { platform: Platform; url: string; custom_label?: string; custom_icon?: string }[]
): Promise<void> {
  await supabase.from('social_links').delete().eq('profile_id', profileId);
  const valid = links.filter((l) => l.url.trim());
  if (valid.length === 0) return;

  const rows = valid.map((l, i) => ({
    profile_id: profileId,
    platform: l.platform,
    url: l.url.trim(),
    custom_label: l.custom_label || '',
    custom_icon: l.custom_icon || '',
    sort_order: i,
  }));

  const { error } = await supabase.from('social_links').insert(rows);
  if (error) throw error;
}

export async function isFollowing(followerId: string, followingId: string): Promise<boolean> {
  const { data } = await supabase
    .from('connections')
    .select('id')
    .eq('follower_id', followerId)
    .eq('following_id', followingId)
    .maybeSingle();
  return !!data;
}

export async function toggleFollow(followingId: string, currentlyFollowing: boolean): Promise<void> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('Not authenticated');

  if (currentlyFollowing) {
    await supabase
      .from('connections')
      .delete()
      .eq('follower_id', user.id)
      .eq('following_id', followingId);
  } else {
    await supabase
      .from('connections')
      .insert({ follower_id: user.id, following_id: followingId });
  }
}

export async function getFollowers(profileId: string): Promise<Profile[]> {
  const { data, error } = await supabase
    .from('connections')
    .select('follower_id, profiles!connections_follower_id_fkey(*)')
    .eq('following_id', profileId);
  if (error) throw error;
  return (data ?? []).map((r: any) => r.profiles as Profile);
}

export async function getFollowing(profileId: string): Promise<Profile[]> {
  const { data, error } = await supabase
    .from('connections')
    .select('following_id, profiles!connections_following_id_fkey(*)')
    .eq('follower_id', profileId); // ← اصلاح شد
  if (error) throw error;
  return (data ?? []).map((r: any) => r.profiles as Profile);
}

export async function checkIfAdmin(): Promise<boolean> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;
    const { data } = await supabase
      .from('admins')
      .select('id')
      .eq('id', user.id)
      .maybeSingle();
    return !!data;
  } catch {
    return false;
  }
}