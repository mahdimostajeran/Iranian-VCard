import type { Profile, SocialLink } from '@/types';

/**
 * Fetch an image from a URL and convert it to a Base64 data URI.
 */
async function imageUrlToBase64(url: string): Promise<string | null> {
  try {
    const response = await fetch(url, { mode: 'cors' });
    if (!response.ok) return null;
    const blob = await response.blob();
    return await new Promise<string | null>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = () => resolve(null);
      reader.readAsDataURL(blob);
    });
  } catch (err) {
    console.warn('[vCard] Failed to embed image as Base64:', err);
    return null;
  }
}

/**
 * Compress/resize an image data URI to a smaller JPEG data URI.
 * Target: max 200x200 px, quality 0.8.
 */
async function compressImageDataUri(dataUri: string): Promise<string | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const MAX_SIZE = 200;
      let { width, height } = img;
      if (width > height && width > MAX_SIZE) {
        height = (height * MAX_SIZE) / width;
        width = MAX_SIZE;
      } else if (height > MAX_SIZE) {
        width = (width * MAX_SIZE) / height;
        height = MAX_SIZE;
      }
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return resolve(null);
      ctx.drawImage(img, 0, 0, width, height);
      try {
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      } catch {
        resolve(null);
      }
    };
    img.onerror = () => resolve(null);
    img.src = dataUri;
  });
}

function escapeVCardValue(value: string): string {
  return value
    .replace(/\\/g, '\\\\')
    .replace(/\n/g, '\\n')
    .replace(/,/g, '\\,')
    .replace(/;/g, '\\;');
}

/**
 * Fold a long line into multiple lines of max 75 chars.
 */
function foldLine(line: string, maxLength: number = 75): string {
  if (line.length <= maxLength) return line;

  const parts: string[] = [];
  let index = 0;

  parts.push(line.slice(0, maxLength));
  index = maxLength;

  while (index < line.length) {
    parts.push(' ' + line.slice(index, index + (maxLength - 1)));
    index += maxLength - 1;
  }

  return parts.join('\r\n');
}

/**
 * Build a vCard 3.0 string compatible with iOS, Android, and desktop.
 * 
 * iOS compat notes:
 * - Uses PHOTO;ENCODING=b;TYPE=JPEG for older iOS
 * - Uses PHOTO;MEDIATYPE=image/jpeg for newer iOS
 * - Base64 data must NOT contain newlines but MUST be folded with CRLF
 */
export async function buildVCard(
  profile: Profile,
  socialLinks: SocialLink[],
  cardUrl: string,
  embedPhoto: boolean = true
): Promise<string> {
  const lines: string[] = [];

  lines.push('BEGIN:VCARD');
  lines.push('VERSION:3.0');

  // Name
  const fullName = profile.full_name || profile.username || 'Contact';
  const nameParts = fullName.trim().split(/\s+/);
  const lastName = nameParts.length > 1 ? nameParts[nameParts.length - 1] : '';
  const firstName = nameParts.slice(0, -1).join(' ') || nameParts[0] || '';

  lines.push(`N:${escapeVCardValue(lastName)};${escapeVCardValue(firstName)};;;`);
  lines.push(`FN:${escapeVCardValue(fullName)}`);

  // Company / Org
  if (profile.company) {
    lines.push(`ORG:${escapeVCardValue(profile.company)}`);
  }

  // Title
  if (profile.headline) {
    lines.push(`TITLE:${escapeVCardValue(profile.headline)}`);
  }

  // NOTE: Bio + Online card note
  const noteParts: string[] = [];
  if (profile.bio) noteParts.push(profile.bio);
  noteParts.push('');
  noteParts.push('✨ این یک کارت ویزیت آنلاین است و همیشه در لینک زیر قابل دسترسی می‌باشد:');
  noteParts.push(cardUrl);

  lines.push(`NOTE:${escapeVCardValue(noteParts.join('\n'))}`);

  // Contact info
  if (profile.email) {
    lines.push(`EMAIL;TYPE=WORK:${escapeVCardValue(profile.email)}`);
  }
  if (profile.phone) {
    lines.push(`TEL;TYPE=CELL:${escapeVCardValue(profile.phone)}`);
  }
  if (profile.website) {
    lines.push(`URL:${escapeVCardValue(profile.website)}`);
  }

  // Social links
  socialLinks.forEach((link) => {
    if (link.url) {
      lines.push(
        `URL;TYPE=${link.platform.toUpperCase()}:${escapeVCardValue(link.url)}`
      );
    }
  });

  // Embed photo as Base64 (iOS-compatible)
  if (embedPhoto && profile.avatar_url) {
    try {
      const rawDataUri = await imageUrlToBase64(profile.avatar_url);

      if (rawDataUri) {
        const compressed = await compressImageDataUri(rawDataUri);
        const finalDataUri = compressed || rawDataUri;

        // Extract base64 without data URI prefix
        const base64Data = finalDataUri.replace(/^data:image\/\w+;base64,/, '');

        // Build the PHOTO line (iOS compatible)
        const photoLine = `PHOTO;ENCODING=b;TYPE=JPEG:${base64Data}`;
        lines.push(foldLine(photoLine, 75));
      }
    } catch (err) {
      console.warn('[vCard] Photo embedding failed:', err);
    }
  }

  lines.push('END:VCARD');

  return lines.join('\r\n');
}

/**
 * Download the vCard as a .vcf file.
 */
export async function downloadVCard(
  profile: Profile,
  socialLinks: SocialLink[],
  cardUrl: string
): Promise<void> {
  const vcf = await buildVCard(profile, socialLinks, cardUrl, true);
  const blob = new Blob([vcf], { type: 'text/vcard;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;

  const safeName = (profile.full_name || profile.username || 'contact')
    .trim()
    .replace(/\s+/g, '_');
  a.download = `${safeName}.vcf`;

  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function profileToVCardString(
  profile: Profile,
  socialLinks: SocialLink[]
): string {
  const lines: string[] = [];
  lines.push('BEGIN:VCARD');
  lines.push('VERSION:3.0');

  const fullName = profile.full_name || profile.username || 'Contact';
  const nameParts = fullName.trim().split(/\s+/);
  const lastName = nameParts.length > 1 ? nameParts[nameParts.length - 1] : '';
  const firstName = nameParts.slice(0, -1).join(' ') || nameParts[0] || '';

  lines.push(`N:${escapeVCardValue(lastName)};${escapeVCardValue(firstName)};;;`);
  lines.push(`FN:${escapeVCardValue(fullName)}`);
  if (profile.company) lines.push(`ORG:${escapeVCardValue(profile.company)}`);
  if (profile.headline) lines.push(`TITLE:${escapeVCardValue(profile.headline)}`);
  if (profile.bio) lines.push(`NOTE:${escapeVCardValue(profile.bio)}`);
  if (profile.email) lines.push(`EMAIL;TYPE=WORK:${escapeVCardValue(profile.email)}`);
  if (profile.phone) lines.push(`TEL;TYPE=CELL:${escapeVCardValue(profile.phone)}`);
  if (profile.website) lines.push(`URL:${escapeVCardValue(profile.website)}`);
  socialLinks.forEach((link) => {
    if (link.url)
      lines.push(
        `URL;TYPE=${link.platform.toUpperCase()}:${escapeVCardValue(link.url)}`
      );
  });

  lines.push('END:VCARD');
  return lines.join('\r\n');
}