import { supabase } from '@/lib/supabase';

export interface PremiumRequest {
  id: string;
  user_id: string;
  full_name: string;
  phone: string;
  telegram_username: string;
  receipt_note: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  admin_notes: string | null;
  created_at: string;
  reviewed_at: string | null;
}

export async function createPremiumRequest(data: {
  user_id: string;
  full_name: string;
  phone: string;
  telegram_username: string;
  receipt_note: string;
  amount: number;
}): Promise<void> {
  const { error } = await supabase.from('premium_requests').insert({
    user_id: data.user_id,
    full_name: data.full_name,
    phone: data.phone,
    telegram_username: data.telegram_username,
    receipt_note: data.receipt_note,
    amount: data.amount,
    status: 'pending',
  });
  if (error) throw error;
}

export async function getPremiumRequests(): Promise<PremiumRequest[]> {
  const { data, error } = await supabase
    .from('premium_requests')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function approvePremiumRequest(requestId: string, userId: string): Promise<void> {
  const { error: updateError } = await supabase
    .from('premium_requests')
    .update({ status: 'approved', reviewed_at: new Date().toISOString() })
    .eq('id', requestId);
  if (updateError) throw updateError;

  const { error: profileError } = await supabase
    .from('profiles')
    .update({ is_premium: true })
    .eq('id', userId);
  if (profileError) throw profileError;
}

export async function rejectPremiumRequest(requestId: string): Promise<void> {
  const { error } = await supabase
    .from('premium_requests')
    .update({ status: 'rejected', reviewed_at: new Date().toISOString() })
    .eq('id', requestId);
  if (error) throw error;
}