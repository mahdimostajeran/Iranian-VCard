import { supabase } from '@/lib/supabase';

export interface DailyViewData {
  date: string;
  views: number;
}

export interface AnalyticsData {
  totalViews: number;
  totalDownloads: number;
  todayViews: number;
  dailyViews: DailyViewData[];
}

export interface ContactSave {
  id: string;
  saved_by_name: string | null;
  saved_by_phone: string | null;
  saved_by_city: string | null;
  saved_by_device: string | null;
  created_at: string;
}

export interface PageViewDetail {
  id: string;
  viewer_id: string | null;
  viewer_city: string | null;
  viewer_device: string | null;
  viewer_referrer: string | null;
  created_at: string;
}

/**
 * لاگ کردن خطاها و رویدادها در جدول analytics_logs
 */
async function logAnalytics(
  eventType: string,
  profileId: string | null,
  metadata: Record<string, any> = {},
  errorMessage?: string
): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    await supabase.from('analytics_logs').insert({
      event_type: eventType,
      profile_id: profileId,
      user_id: user?.id ?? null,
      metadata,
      error_message: errorMessage ?? null,
    });
  } catch (err) {
    // Never throw from logging
    console.warn('[Analytics] Logging failed:', err);
  }
}

/**
 * بررسی ربات/کراولر بودن
 */
function isBot(): boolean {
  if (typeof navigator === 'undefined') return true;
  if (navigator.webdriver) return true;
  const ua = navigator.userAgent.toLowerCase();
  const botPatterns = ['bot', 'crawler', 'spider', 'crawl', 'slurp', 'facebookexternalhit'];
  return botPatterns.some((p) => ua.includes(p));
}

/**
 * تشخیص نوع دستگاه
 */
function getDeviceType(): string {
  if (typeof navigator === 'undefined') return 'ناشناخته';
  const ua = navigator.userAgent;
  if (/Mobi|Android/i.test(ua)) return 'موبایل';
  if (/Tablet|iPad/i.test(ua)) return 'تبلت';
  return 'دسکتاپ';
}

/**
 * تشخیص شهر (فعلاً null، بعداً با IP Geolocation)
 */
function getCity(): string | null {
  return null;
}

/**
 * ثبت بازدید صفحه (یک بار در هر session)
 */
export async function trackPageView(profileId: string): Promise<void> {
  try {
    if (typeof window === 'undefined') return;
    if (isBot()) {
      await logAnalytics('page_view', profileId, { skipped: 'bot' });
      return;
    }

    const sessionKey = `pv_${profileId}`;
    if (sessionStorage.getItem(sessionKey)) return;
    sessionStorage.setItem(sessionKey, '1');

    // ۱. ثبت در جدول اصلی
    const { error: viewError } = await supabase.from('page_views').insert({ profile_id: profileId });
    if (viewError) {
      sessionStorage.removeItem(sessionKey);
      await logAnalytics('page_view', profileId, {}, viewError.message);
      console.warn('[Analytics] Failed to track page view:', viewError.message);
      return;
    }

    // ۲. ثبت جزئیات
    const { data: { user } } = await supabase.auth.getUser();
    const { error: detailError } = await supabase.from('page_view_details').insert({
      profile_id: profileId,
      viewer_id: user?.id ?? null,
      viewer_city: getCity(),
      viewer_device: getDeviceType(),
      viewer_referrer: document.referrer || null,
    });

    if (detailError) {
      await logAnalytics('page_view_detail', profileId, {}, detailError.message);
    }

    await logAnalytics('page_view', profileId, {
      device: getDeviceType(),
      has_referrer: !!document.referrer,
    });
  } catch (err: any) {
    await logAnalytics('page_view', profileId, {}, err?.message || 'unknown');
    console.warn('[Analytics] trackPageView error:', err);
  }
}

/**
 * ثبت ذخیره‌سازی کارت (ذخیره‌سازی متقابل) — همیشه لاگ می‌شود
 */
export async function trackContactSave(
  cardOwnerId: string,
  userInfo?: {
    userId?: string;
    fullName?: string;
    phone?: string;
  }
): Promise<{ success: boolean; error?: string }> {
  try {
    if (typeof window === 'undefined') {
      return { success: false, error: 'no window' };
    }
    if (isBot()) {
      await logAnalytics('contact_save', cardOwnerId, { skipped: 'bot' });
      return { success: false, error: 'bot detected' };
    }

    const { error } = await supabase.from('contact_saves').insert({
      card_owner_id: cardOwnerId,
      saved_by_user_id: userInfo?.userId ?? null,
      saved_by_name: userInfo?.fullName ?? null,
      saved_by_phone: userInfo?.phone ?? null,
      saved_by_city: getCity(),
      saved_by_device: getDeviceType(),
      saved_by_user_agent: navigator.userAgent.slice(0, 200),
    });

    if (error) {
      await logAnalytics('contact_save', cardOwnerId, {}, error.message);
      console.warn('[Analytics] trackContactSave failed:', error.message);
      return { success: false, error: error.message };
    }

    await logAnalytics('contact_save', cardOwnerId, {
      device: getDeviceType(),
      has_user_id: !!userInfo?.userId,
    });

    return { success: true };
  } catch (err: any) {
    await logAnalytics('contact_save', cardOwnerId, {}, err?.message || 'unknown');
    console.warn('[Analytics] trackContactSave error:', err);
    return { success: false, error: err?.message };
  }
}

/**
 * افزایش شمارنده ذخیره vCard — با RPC اتمیک + لاگ
 */
export async function incrementVCardDownload(profileId: string): Promise<number> {
  try {
    // روش اتمیک با RPC
    const { data, error } = await supabase.rpc('increment_vcard_downloads', {
      profile_id_input: profileId,
    });

    if (error) {
      await logAnalytics('vcard_download', profileId, {}, error.message);
      console.warn('[Analytics] incrementVCardDownload RPC failed:', error.message);
      return 0;
    }

    await logAnalytics('vcard_download', profileId, { new_count: data });
    return typeof data === 'number' ? data : 0;
  } catch (err: any) {
    await logAnalytics('vcard_download', profileId, {}, err?.message || 'unknown');
    console.warn('[Analytics] incrementVCardDownload error:', err);
    return 0;
  }
}

/**
 * گرفتن آمار کلی (با لاگ خطا)
 */
export async function getAnalytics(profileId: string): Promise<AnalyticsData> {
  try {
    const { count: totalViews, error: viewsError } = await supabase
      .from('page_views')
      .select('*', { count: 'exact', head: true })
      .eq('profile_id', profileId);

    if (viewsError) {
      await logAnalytics('get_analytics', profileId, {}, viewsError.message);
    }

    const { data: profileData, error: profileError } = await supabase
      .from('profiles')
      .select('vcard_downloads')
      .eq('id', profileId)
      .single();

    if (profileError) {
      await logAnalytics('get_analytics', profileId, {}, profileError.message);
    }

    const totalDownloads = (profileData as any)?.vcard_downloads ?? 0;

    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const { count: todayViews } = await supabase
      .from('page_views')
      .select('*', { count: 'exact', head: true })
      .eq('profile_id', profileId)
      .gte('viewed_at', startOfToday.toISOString());

    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
    sevenDaysAgo.setHours(0, 0, 0, 0);

    const { data: rawViews } = await supabase
      .from('page_views')
      .select('viewed_at')
      .eq('profile_id', profileId)
      .gte('viewed_at', sevenDaysAgo.toISOString());

    const dailyMap: Record<string, number> = {};
    for (let i = 0; i < 7; i++) {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      const key = d.toISOString().split('T')[0];
      dailyMap[key] = 0;
    }

    (rawViews ?? []).forEach((row: any) => {
      const key = new Date(row.viewed_at).toISOString().split('T')[0];
      if (key in dailyMap) dailyMap[key]++;
    });

    const dailyViews: DailyViewData[] = Object.entries(dailyMap).map(([date, views]) => ({
      date,
      views,
    }));

    return {
      totalViews: totalViews ?? 0,
      totalDownloads,
      todayViews: todayViews ?? 0,
      dailyViews,
    };
  } catch (err: any) {
    await logAnalytics('get_analytics', profileId, {}, err?.message || 'unknown');
    return {
      totalViews: 0,
      totalDownloads: 0,
      todayViews: 0,
      dailyViews: [],
    };
  }
}

/**
 * گرفتن لیست مخاطبین
 */
export async function getMyContacts(
  ownerId: string,
  limit: number = 50
): Promise<ContactSave[]> {
  const { data, error } = await supabase
    .from('contact_saves')
    .select('id, saved_by_name, saved_by_phone, saved_by_city, saved_by_device, created_at')
    .eq('card_owner_id', ownerId)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) {
    await logAnalytics('get_contacts', ownerId, {}, error.message);
    throw error;
  }
  return (data as ContactSave[]) ?? [];
}

/**
 * گرفتن جزئیات بازدیدکنندگان
 */
export async function getPageViewDetails(
  profileId: string,
  limit: number = 50
): Promise<PageViewDetail[]> {
  const { data, error } = await supabase
    .from('page_view_details')
    .select('id, viewer_id, viewer_city, viewer_device, viewer_referrer, created_at')
    .eq('profile_id', profileId)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) {
    await logAnalytics('get_view_details', profileId, {}, error.message);
    throw error;
  }
  return (data as PageViewDetail[]) ?? [];
}

/**
 * گرفتن آمار کلی سایت (برای landing)
 */
export async function getGlobalStats(): Promise<{
  totalCards: number;
  totalViews: number;
  totalVCardSaves: number;
}> {
  try {
    const { count: totalCards } = await supabase
      .from('profiles')
      .select('*', { count: 'exact', head: true });

    const { count: totalViews } = await supabase
      .from('page_views')
      .select('*', { count: 'exact', head: true });

    const { data: profilesData } = await supabase
      .from('profiles')
      .select('vcard_downloads');

    const totalVCardSaves = (profilesData ?? []).reduce(
      (sum: number, p: any) => sum + (p.vcard_downloads || 0),
      0
    );

    return {
      totalCards: totalCards ?? 0,
      totalViews: totalViews ?? 0,
      totalVCardSaves,
    };
  } catch {
    return { totalCards: 0, totalViews: 0, totalVCardSaves: 0 };
  }
}