import { supabase } from '@/lib/supabase';
import type { Card, CardWithRelations, Skill, SocialLink } from '@/types';

export async function getMyCards(): Promise<Card[]> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];
  const { data, error } = await supabase
    .from('cards')
    .select('*')
    .eq('user_id', user.id)
    .order('is_primary', { ascending: false })
    .order('created_at', { ascending: true });
  if (error) throw error;
  return (data as Card[]) ?? [];
}

export async function getCardByUsername(
  username: string,
  options: { allowPrivate?: boolean } = {}
): Promise<CardWithRelations | null> {
  const { data: card, error } = await supabase
    .from('cards')
    .select('*')
    .eq('username', username)
    .maybeSingle();
  if (error) throw error;
  if (!card) return null;

  if (card.is_private) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user || user.id !== card.user_id) {
      if (!options.allowPrivate) return null;
    }
  }

  const [{ data: skills }, { data: socialLinks }] = await Promise.all([
    supabase.from('skills').select('*').eq('card_id', card.id).order('sort_order', { ascending: true }),
    supabase.from('social_links').select('*').eq('card_id', card.id).order('sort_order', { ascending: true }),
  ]);

  return {
    ...(card as Card),
    skills: (skills as Skill[]) ?? [],
    social_links: (socialLinks as SocialLink[]) ?? [],
  };
}

export async function createCard(data: Partial<Card>): Promise<Card> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Not authenticated');

  const existing = await getMyCards();
  const hasPremium = existing.some((c) => c.is_premium);

  if (!hasPremium && existing.length >= 1) {
    throw new Error('برای ساخت بیش از یک کارت، به نسخه ویژه ارتقا دهید');
  }
  if (hasPremium && existing.length >= 5) {
    throw new Error('حداکثر ۵ کارت برای هر کاربر ویژه مجاز است');
  }

  if (data.username) {
    const { data: existingCard } = await supabase
      .from('cards')
      .select('id')
      .eq('username', data.username)
      .maybeSingle();
    if (existingCard) throw new Error('این نام کاربری قبلاً استفاده شده است');
  }

  const isPrimary = existing.length === 0;

  const { data: created, error } = await supabase
    .from('cards')
    .insert({
      user_id: user.id,
      is_primary: isPrimary,
      is_private: data.is_private ?? false,
      is_premium: hasPremium,
      username: data.username,
      full_name: data.full_name || null,
      full_name_en: data.full_name_en || null,
      headline: data.headline || '',
      bio: data.bio || '',
      email: data.email || '',
      phone: data.phone || '',
      website: data.website || '',
      company: data.company || '',
      template_type: data.template_type || 'personal',
      card_theme: data.card_theme || 'teal',
      keywords: data.keywords || [],
      custom_fields: data.custom_fields || [],
    })
    .select()
    .single();

  if (error) throw error;
  return created as Card;
}

export async function updateCard(cardId: string, data: Partial<Card>): Promise<void> {
  const { error } = await supabase
    .from('cards')
    .update({ ...data, updated_at: new Date().toISOString() })
    .eq('id', cardId);
  if (error) throw error;
}

export async function deleteCard(cardId: string): Promise<void> {
  const { data: card } = await supabase
    .from('cards')
    .select('is_primary')
    .eq('id', cardId)
    .single();

  if (card?.is_primary) throw new Error('کارت اصلی قابل حذف نیست');

  const { error } = await supabase.from('cards').delete().eq('id', cardId);
  if (error) throw error;
}

export async function setPrimaryCard(cardId: string): Promise<void> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Not authenticated');

  await supabase.from('cards').update({ is_primary: false }).eq('user_id', user.id);
  const { error } = await supabase
    .from('cards')
    .update({ is_primary: true })
    .eq('id', cardId);
  if (error) throw error;
}

export async function updateCardSkills(cardId: string, skills: string[]): Promise<void> {
  await supabase.from('skills').delete().eq('card_id', cardId);
  if (skills.length === 0) return;

  const rows = skills.map((s, i) => ({
    card_id: cardId,
    skill_name: s,
    sort_order: i,
  }));

  const { error } = await supabase.from('skills').insert(rows);
  if (error) throw error;
}

export async function updateCardSocialLinks(
  cardId: string,
  links: { platform: string; url: string; custom_label?: string; custom_icon?: string }[]
): Promise<void> {
  await supabase.from('social_links').delete().eq('card_id', cardId);
  const valid = links.filter((l) => l.url.trim());
  if (valid.length === 0) return;

  const rows = valid.map((l, i) => ({
    card_id: cardId,
    platform: l.platform,
    url: l.url.trim(),
    custom_label: l.custom_label || '',
    custom_icon: l.custom_icon || '',
    sort_order: i,
  }));

  const { error } = await supabase.from('social_links').insert(rows);
  if (error) throw error;
}

export async function checkCardUsernameAvailable(
  username: string,
  excludeCardId?: string
): Promise<boolean> {
  const { data } = await supabase
    .from('cards')
    .select('id')
    .eq('username', username)
    .maybeSingle();

  if (!data) return true;
  if (excludeCardId && data.id === excludeCardId) return true;
  return false;
}

export async function getPrimaryCard(): Promise<Card | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data, error } = await supabase
    .from('cards')
    .select('*')
    .eq('user_id', user.id)
    .eq('is_primary', true)
    .maybeSingle();
  if (error) throw error;
  return data as Card | null;
}

export async function getRecentPublicCards(limit: number = 8): Promise<Card[]> {
  const { data, error } = await supabase
    .from('cards')
    .select('*')
    .eq('is_private', false)
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return (data as Card[]) ?? [];
}