export type TemplateType = 'personal' | 'corporate';

export type CardTheme =
  | 'teal'
  | 'midnight'
  | 'corporate'
  | 'minimal'
  | 'gradient'
  | 'glass';

export type Platform =
  | 'linkedin'
  | 'instagram'
  | 'telegram'
  | 'whatsapp'
  | 'twitter'
  | 'youtube'
  | 'facebook'
  | 'tiktok'
  | 'github'
  | 'email'
  | 'website'
  | 'eitaa'
  | 'bale'
  | 'rubika'
  | 'soroush'
  | 'igap'
  | 'custom';

/** فیلد سفارشی — قابل استفاده در profiles و cards */
export interface CustomField {
  label: string;
  value: string;
  icon?: string;
  is_public: boolean;
  priority: number;
}

/** پروفایل — هویت مشترک کاربر */
export interface Profile {
  id: string;
  username: string;
  full_name: string;
  full_name_en?: string;
  headline: string;
  bio: string;
  email: string;
  phone: string;
  website: string;
  company: string;
  avatar_url: string;
  cover_image_url: string;
  audio_intro_url: string;
  video_url: string;
  template_type: TemplateType;
  card_theme?: CardTheme;
  keywords?: string[];
  custom_fields?: CustomField[];
  is_premium: boolean;
  vcard_downloads: number;
  created_at: string;
}

/** کارت — هر کاربر می‌تواند چند کارت داشته باشد */
export interface Card {
  id: string;
  user_id: string;
  username: string;
  full_name: string | null;
  full_name_en: string | null;
  headline: string;
  bio: string;
  company: string;
  email: string;
  phone: string;
  website: string;
  avatar_url: string;
  cover_image_url: string;
  audio_intro_url: string;
  video_url: string;
  template_type: TemplateType;
  card_theme: CardTheme;
  is_premium: boolean;
  is_primary: boolean;
  is_private: boolean;
  keywords: string[];
  custom_fields: CustomField[];
  vcard_downloads: number;
  created_at: string;
  updated_at: string;
  // relations
  skills?: Skill[];
  social_links?: SocialLink[];
}

export interface Skill {
  id: string;
  profile_id?: string;
  card_id?: string;
  skill_name: string;
  sort_order?: number;
}

export interface SocialLink {
  id: string;
  profile_id?: string;
  card_id?: string;
  platform: Platform;
  url: string;
  custom_label?: string;
  custom_icon?: string;
  sort_order?: number;
}

/** Card با relations — برای صفحه‌ی عمومی */
export interface CardWithRelations extends Card {
  skills: Skill[];
  social_links: SocialLink[];
}

export interface ProfileWithRelations extends Profile {
  skills: Skill[];
  social_links: SocialLink[];
}

export interface Connection {
  id: string;
  follower_id: string;
  following_id: string;
  created_at: string;
}

export type OrderStatus = 'pending' | 'confirmed' | 'shipped' | 'cancelled';
export type CardType = 'digital' | 'hybrid_nfc';

export interface Order {
  id: string;
  user_id: string | null;
  full_name: string;
  phone: string;
  email: string | null;
  card_type: CardType;
  quantity: number;
  notes: string | null;
  status: OrderStatus;
  created_at: string;
}