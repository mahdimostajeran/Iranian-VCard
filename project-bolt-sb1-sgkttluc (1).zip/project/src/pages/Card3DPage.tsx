import { useEffect, useState, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import {
  ArrowLeft,
  AlertCircle,
  Sparkles,
  Download,
  Eye,
  TreePine,
  LayoutDashboard,
} from 'lucide-react';
import { getProfileByUsername } from '@/lib/profiles';
import { downloadVCard } from '@/lib/vcard';
import {
  trackPageView,
  incrementVCardDownload,
  getAnalytics,
  trackContactSave,
} from '@/lib/analytics';
import { useAuth } from '@/hooks/useAuth';
import { QRModal } from '@/components/QRModal';
import { Card3D } from '@/components/Card3D';
import type { ProfileWithRelations } from '@/types';

export function Card3DPage() {
  const { username } = useParams<{ username: string }>();
  const { user } = useAuth();
  const [profile, setProfile] = useState<ProfileWithRelations | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [qrOpen, setQrOpen] = useState(false);
  const [viewCount, setViewCount] = useState(0);
  const [downloadCount, setDownloadCount] = useState(0);

  const fetchedRef = useRef<string | null>(null);
  const trackedRef = useRef<boolean>(false);

  const cardUrl = `${window.location.origin}/${username ?? ''}`;

  useEffect(() => {
    if (!username) return;
    if (fetchedRef.current === username && profile) return;

    fetchedRef.current = username;
    setLoading(true);
    setNotFound(false);

    getProfileByUsername(username)
      .then(async (p) => {
        if (!p) {
          setNotFound(true);
        } else {
          setProfile(p);
          setDownloadCount(p.vcard_downloads ?? 0);

          const isOwner = user?.id === p.id;

          if (!isOwner && !trackedRef.current) {
            trackedRef.current = true;
            trackPageView(p.id);
          }

          if (isOwner) {
            try {
              const analytics = await getAnalytics(p.id);
              setViewCount(analytics.totalViews);
              setDownloadCount(analytics.totalDownloads);
            } catch {
              // ignore
            }
          }
        }
      })
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false));
  }, [username, user, profile]);

  const handleSaveContact = async () => {
    if (!profile) return;
    try {
      await downloadVCard(profile, profile.social_links, cardUrl);
      incrementVCardDownload(profile.id);
      setDownloadCount((c) => c + 1);

      await trackContactSave(profile.id, {
        userId: user?.id,
        fullName: user?.user_metadata?.full_name ?? undefined,
        phone: user?.user_metadata?.phone ?? undefined,
      });
    } catch (err) {
      console.error('[vCard] Failed to download:', err);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center gradient-mesh">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary-200 border-t-primary-600" />
      </div>
    );
  }

  if (notFound) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 gradient-mesh p-6 text-center">
        <AlertCircle className="h-16 w-16 text-primary-300" strokeWidth={1.5} />
        <h1 className="text-2xl font-bold text-gray-700">کارت پیدا نشد</h1>
        <p className="text-gray-500">کاربری با این نام وجود ندارد.</p>
        <Link
          to="/"
          className="mt-4 flex items-center gap-2 rounded-xl bg-primary-600 px-6 py-3 text-white shadow-lg transition-colors hover:bg-primary-700"
        >
          <ArrowLeft className="h-5 w-5" strokeWidth={1.5} />
          بازگشت به صفحه اصلی
        </Link>
      </div>
    );
  }

  if (!profile) return null;

  const isOwnCard = user?.id === profile.id;

  return (
    <div className="min-h-screen gradient-mesh">
      <Helmet>
        <title>{`${profile.full_name} - کارت ۳بعدی | کارتین`}</title>
        <meta name="description" content={`کارت ویزیت ۳بعدی ${profile.full_name}`} />
        <meta property="og:title" content={`${profile.full_name} - کارت ۳بعدی`} />
        <meta property="og:description" content={profile.bio || `کارت ویزیت ${profile.full_name}`} />
        <meta property="og:image" content={profile.avatar_url} />
      </Helmet>

      {isOwnCard && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed top-4 right-4 z-50 flex gap-2"
        >
          <Link
            to="/dashboard"
            className="flex items-center gap-2 rounded-2xl bg-white px-5 py-3 text-sm font-bold text-primary-700 shadow-[0_8px_24px_rgba(0,0,0,0.12)] transition-transform hover:scale-105"
          >
            <LayoutDashboard className="h-4 w-4" strokeWidth={2} />
            داشبورد
          </Link>
          <Link
            to="/"
            className="flex items-center gap-2 rounded-2xl bg-white px-5 py-3 text-sm font-bold text-gray-700 shadow-[0_8px_24px_rgba(0,0,0,0.12)] transition-transform hover:scale-105"
          >
            صفحه اصلی
          </Link>
        </motion.div>
      )}

      {!isOwnCard && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="fixed top-4 right-4 z-50"
        >
          <Link
            to={user ? '/dashboard' : '/auth?mode=signup'}
            className="flex items-center gap-2 rounded-2xl bg-gradient-to-l from-primary-600 to-accent-600 px-5 py-3 text-sm font-bold text-white shadow-[0_8px_24px_rgba(20,184,166,0.3)] transition-transform hover:scale-105"
          >
            <Sparkles className="h-4 w-4" strokeWidth={2} />
            {user ? 'داشبورد من' : 'ساخت کارت رایگان'}
          </Link>
        </motion.div>
      )}

      <main className="mx-auto max-w-4xl px-4 py-12 sm:px-6 sm:py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-10 text-center"
        >
          <span className="inline-flex items-center gap-2 rounded-full bg-primary-50 px-4 py-1.5 text-xs font-medium text-primary-700 ring-1 ring-primary-100">
            <Sparkles className="h-3.5 w-3.5" strokeWidth={1.5} />
            کارت ویزیت ۳بعدی
          </span>
          <h1 className="mt-4 text-3xl font-extrabold text-gray-800 sm:text-4xl">
            {profile.full_name}
          </h1>
          {profile.headline && (
            <p className="mt-2 text-base text-primary-600">{profile.headline}</p>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card3D
            profile={profile}
            onSaveContact={handleSaveContact}
            onShowQR={() => setQrOpen(true)}
          />
        </motion.div>

        {isOwnCard && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mt-12 space-y-4"
          >
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              <div className="rounded-2xl bg-gradient-to-br from-primary-50 to-primary-100/50 p-4 text-center">
                <Eye className="mx-auto h-5 w-5 text-primary-600" strokeWidth={1.5} />
                <p className="mt-2 text-2xl font-extrabold text-primary-700">{viewCount}</p>
                <p className="text-[11px] font-medium text-primary-600/80">بازدید کل</p>
              </div>
              <div className="rounded-2xl bg-gradient-to-br from-emerald-50 to-emerald-100/50 p-4 text-center">
                <Download className="mx-auto h-5 w-5 text-emerald-600" strokeWidth={1.5} />
                <p className="mt-2 text-2xl font-extrabold text-emerald-700">{downloadCount}</p>
                <p className="text-[11px] font-medium text-emerald-600/80">ذخیره در مخاطبین</p>
              </div>
              <div className="col-span-2 rounded-2xl bg-gradient-to-br from-amber-50 to-orange-100/50 p-4 text-center sm:col-span-1">
                <TreePine className="mx-auto h-5 w-5 text-amber-600" strokeWidth={1.5} />
                <p className="mt-2 text-2xl font-extrabold text-amber-700">
                  {(downloadCount * 2).toFixed(0)}
                </p>
                <p className="text-[11px] font-medium text-amber-600/80">گرم کاغذ صرفه‌جویی</p>
              </div>
            </div>
          </motion.div>
        )}

        <div className="mt-12 text-center">
          <Link
            to={`/${username}`}
            className="inline-flex items-center gap-2 text-sm font-medium text-gray-500 transition-colors hover:text-primary-600"
          >
            مشاهده نسخه کلاسیک کارت
            <ArrowLeft className="h-4 w-4" strokeWidth={1.5} />
          </Link>
        </div>
      </main>

      <QRModal open={qrOpen} onClose={() => setQrOpen(false)} url={cardUrl} />
    </div>
  );
}
