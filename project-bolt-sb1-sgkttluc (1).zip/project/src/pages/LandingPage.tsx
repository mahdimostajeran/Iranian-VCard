import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Sparkles,
  QrCode,
  Share2,
  ArrowLeft,
  Check,
  TreePine,
  BarChart3,
  Palette,
  Shield,
  Contact,
  Crown,
  HelpCircle,
  Building2,
  CreditCard,
  LayoutDashboard,
  User,
  Star,
  X as XIcon,
  Boxes,
  MousePointerClick,
  Eye,
  Users,
  Phone,
  Mail,
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { getMyProfile } from '@/lib/profiles';
import { Card3D } from '@/components/Card3D';

// داده نمونه برای کارت ۳بعدی نمایشی
const DEMO_PROFILE = {
  id: 'demo',
  username: 'ahmadi',
  full_name: 'مهندس علی احمدی',
  headline: 'مدیرعامل استارتاپ فناوری',
  bio: 'بنیان‌گذار و مدیرعامل شرکت داده‌پردازان هوشمند. متخصص در حوزه هوش مصنوعی و تحول دیجیتال با بیش از ۱۰ سال تجربه.',
  email: 'ali@dadeh-pardazan.ir',
  phone: '+98 912 345 6789',
  website: 'https://dadeh-pardazan.ir',
  company: 'شرکت داده‌پردازان هوشمند',
  avatar_url: '',
  cover_image_url: '',
  audio_intro_url: '',
  video_url: '',
  template_type: 'corporate' as const,
  is_premium: true,
  vcard_downloads: 1247,
  created_at: new Date().toISOString(),
  skills: [
    { id: '1', profile_id: 'demo', skill_name: 'هوش مصنوعی' },
    { id: '2', profile_id: 'demo', skill_name: 'تحول دیجیتال' },
    { id: '3', profile_id: 'demo', skill_name: 'مدیریت محصول' },
    { id: '4', profile_id: 'demo', skill_name: 'استراتژی' },
  ],
  social_links: [
    { id: '1', profile_id: 'demo', platform: 'linkedin' as const, url: 'https://linkedin.com' },
    { id: '2', profile_id: 'demo', platform: 'instagram' as const, url: 'https://instagram.com' },
    { id: '3', profile_id: 'demo', platform: 'telegram' as const, url: 'https://telegram.com' },
  ],
};

export function LandingPage() {
  const { user, loading } = useAuth();
  const [myUsername, setMyUsername] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setMyUsername(null);
      return;
    }
    getMyProfile()
      .then((p) => setMyUsername(p?.username ?? null))
      .catch(() => setMyUsername(null));
  }, [user]);

  const features = [
    {
      icon: Contact,
      title: 'کارت ویزیت دیجیتال',
      desc: 'پروفایل حرفه‌ای با عکس، بیوگرافی، مهارت‌ها و راه‌های تماس.',
    },
    {
      icon: Boxes,
      title: 'کارت ۳بعدی',
      desc: 'کارت ویزیت خود را در حالت ۳بعدی با قابلیت چرخش ۳۶۰ درجه ببینید.',
    },
    {
      icon: QrCode,
      title: 'کد QR اختصاصی',
      desc: 'با یک اسکن، مخاطبین شما مستقیماً به کارت ویزیت شما می‌رسند.',
    },
    {
      icon: BarChart3,
      title: 'آمار بازدید',
      desc: 'ببینید چند نفر کارت شما را دیده‌اند و چند نفر شما را ذخیره کرده‌اند.',
    },
    {
      icon: Users,
      title: 'مخاطبین من',
      desc: 'ببینید چه کسانی کارت شما را ذخیره کرده‌اند و با آن‌ها در تماس باشید.',
    },
    {
      icon: Shield,
      title: 'امنیت بالا',
      desc: 'اطلاعات شما با استانداردهای امنیتی روز محافظت می‌شود.',
    },
  ];

  const howItWorks = [
    {
      num: '۱',
      title: 'ثبت‌نام کنید',
      desc: 'در کمتر از ۳۰ ثانیه یک حساب کاربری بسازید.',
    },
    {
      num: '۲',
      title: 'کارت خود را بسازید',
      desc: 'عکس، بیوگرافی، مهارت‌ها و راه‌های تماس خود را وارد کنید.',
    },
    {
      num: '۳',
      title: 'لینک را به اشتراک بگذارید',
      desc: 'لینک اختصاصی یا QR Code خود را در همه‌جا استفاده کنید.',
    },
  ];

  const testimonials = [
    {
      name: 'نگار محمودی',
      role: 'مشاور املاک',
      text: 'توی نشست‌های ملکی، جای اینکه چند تا کارت بدم، فقط QR کدم رو نشون می‌دم. مشتری هم راحت‌تر پیگیر می‌شه.',
      rating: 5,
    },
    {
      name: 'سعید رستگار',
      role: 'مدیر فروش',
      text: 'برای تیم فروشمون کارت یکپارچه ساختیم. حالا همه اطلاعات هم‌شکل و حرفه‌ای دیده می‌شه.',
      rating: 5,
    },
    {
      name: 'مریم صبوری',
      role: 'متخصص تغذیه',
      text: 'مراجعینم همیشه شماره‌م رو گم می‌کردن. الان کارتم رو یه بار بهشون می‌دم، همیشه در دسترسشونه.',
      rating: 5,
    },
    {
      name: 'کیوان مظاهری',
      role: 'مشاور کسب‌وکار',
      text: 'برای معرفی خدماتم به مشتری‌ها، این کارت خیلی کمکم کرد. سریع‌تر اعتماد می‌سازن.',
      rating: 5,
    },
    {
      name: 'الهه کریمی',
      role: 'طراح داخلی',
      text: 'نمونه‌کارهام رو یکجا به مشتری می‌دم. دیگه لازم نیست چند لینک جدا بفرستم.',
      rating: 5,
    },
    {
      name: 'پیمان شریفی',
      role: 'مشاور بیمه',
      text: 'وقتی مشتری کارتم رو ذخیره می‌کنه، دیگه نگران گم شدن اطلاعاتم نیستم.',
      rating: 5,
    },
    {
      name: 'رعنا نادری',
      role: 'وکیل دادگستری',
      text: 'برای معرفی دفترم و راه‌های تماس، این کارت خیلی مناسبه. موکلین راحت‌تر باهامون ارتباط می‌گیرن.',
      rating: 5,
    },
    {
      name: 'بهراد کاویانی',
      role: 'مدیر محصول',
      text: 'کارتین باعث شده معرفی خودم سریع‌تر و حرفه‌ای‌تر بشه. کارت ۳بعدی‌اش هم عالیه.',
      rating: 5,
    },
    {
      name: 'سحر نجفی',
      role: 'روانشناس',
      text: 'برای مراجعینم این کارت خیلی کاربردیه. تماسشون رو راحت پیدا می‌کنن.',
      rating: 5,
    },
    {
      name: 'آرش بیگی',
      role: 'عکاس صنعتی',
      text: 'یه کارت حرفه‌ای که همه نمونه‌کارها رو یکجا داشته باشه، خیلی ارزشمنده.',
      rating: 5,
    },
    {
      name: 'مهسا رحیمی',
      role: 'دکتر داروساز',
      text: 'برای معرفی داروخونه و ساعت کاری، این کارت عالیه. مراجعین راحت پیدام می‌کنن.',
      rating: 5,
    },
    {
      name: 'مسعود فرهادی',
      role: 'مدیر آژانس مسافرتی',
      text: 'توی نمایشگاه‌های گردشگری خیلی به کارمون میاد. به جای چند تا کارت، یه QR کد و همه اطلاعات.',
      rating: 5,
    },
    {
      name: 'شبنم موسوی',
      role: 'مدرس زبان',
      text: 'برای معرفی کلاس‌هام به زبان‌آموزهای جدید، این کارت خیلی مناسبه. دیگه کارت چاپ نمی‌کنم.',
      rating: 5,
    },
    {
      name: 'کامران رستگار',
      role: 'مدیر تولید',
      text: 'برای تیم فروش شرکت چند کارت ساختیم. حالا برندمون یکپارچه‌تر دیده می‌شه.',
      rating: 5,
    },
    {
      name: 'نازنین پورکریمی',
      role: 'طراح گرافیک',
      text: 'ظاهر کارت و پروفایل دیجیتال خیلی تمیز و مدرن بود. از کارت ۳بعدی‌اش هم خیلی خوشم اومد.',
      rating: 5,
    },
    {
      name: 'شهاب مهدوی',
      role: 'مدیر بازاریابی',
      text: 'برای جلسات و کنفرانس‌ها، یه لینک دارم که همه‌جا کار می‌کنه. خیلی راحته.',
      rating: 5,
    },
  ];

  const planFeatures = [
    { label: 'نسخه فیزیکی', traditional: true, hybrid: true },
    { label: 'طراحی و دیزاین اختصاصی', traditional: true, hybrid: true },
    { label: 'قابلیت ویرایش اطلاعات', traditional: false, hybrid: true },
    { label: 'ذخیره در مخاطبین گوشی', traditional: false, hybrid: true },
    { label: 'نمایش در گوگل (SEO)', traditional: false, hybrid: true },
    { label: 'کارت ۳بعدی تعاملی', traditional: false, hybrid: true },
    { label: 'دریافت اطلاعات مشتری', traditional: false, hybrid: true },
    { label: 'استفاده از چند زبان', traditional: false, hybrid: true },
    { label: 'آمار بازدید و فعالیت', traditional: false, hybrid: true },
  ];

  const faqs = [
    {
      q: 'آیا استفاده از کارتین رایگان است؟',
      a: 'بله، ساخت کارت ویزیت دیجیتال کاملاً رایگان است. برای امکانات پیشرفته (مثل معرفی صوتی، ویدیویی، کارت ۳بعدی و صفحه‌ساز هوشمند) می‌توانید به پلن حرفه‌ای ارتقا دهید.',
    },
    {
      q: 'کارت ۳بعدی چیست و چه کاربردی دارد؟',
      a: 'کارت ۳بعدی یک نمایش تعاملی از کارت ویزیت شماست که با کلیک روی آن، ۳۶۰ درجه می‌چرخد و پشت و روی کارت را نشان می‌دهد. این ویژگی حس یک کارت ویزیت فیزیکی واقعی را به مخاطب منتقل می‌کند.',
    },
    {
      q: 'کارت ویزیت دیجیتال چطور کار می‌کند؟',
      a: 'شما یک پروفایل دیجیتال دارید که با لینک اختصاصی در دسترس است. می‌توانید لینک را در بیو اینستاگرام، تلگرام، واتساپ و... قرار دهید یا آن را با QR Code به اشتراک بگذارید.',
    },
    {
      q: 'آیا می‌توانم کارت ویزیت خود را در مخاطبین گوشی ذخیره کنم؟',
      a: 'بله، با یک کلیک روی دکمه «ذخیره در مخاطبین»، یک فایل vCard دانلود می‌شود که شامل تمام اطلاعات تماس و عکس شماست.',
    },
    {
      q: 'کارت هیبریدی چیست و چه تفاوتی با کارت ویزیت دیجیتال دارد؟',
      a: 'کارت هیبریدی ترکیبی از یک کارت فیزیکی با تراشه NFC و یک کارت ویزیت دیجیتال است. کافیست مخاطب گوشی خود را به کارت نزدیک کند تا صفحه دیجیتال شما باز شود.',
    },
  ];

  return (
    <div className="min-h-screen gradient-mesh">
      {/* Navbar */}
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5 sm:px-6">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 shadow-md">
            <Sparkles className="h-5 w-5 text-white" strokeWidth={1.5} />
          </div>
          <span className="text-lg font-extrabold text-gray-800">کارتین</span>
        </Link>
        <div className="flex items-center gap-2">
          {loading ? (
            <div className="h-9 w-20 animate-pulse rounded-xl bg-gray-100" />
          ) : user ? (
            <>
              <Link
                to="/dashboard"
                className="flex items-center gap-1.5 rounded-xl bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm transition-colors hover:bg-gray-50"
              >
                <LayoutDashboard className="h-4 w-4" strokeWidth={1.5} />
                <span className="hidden sm:inline">داشبورد</span>
              </Link>
              {myUsername && (
                <Link
                  to={`/${myUsername}`}
                  className="flex items-center gap-1.5 rounded-xl bg-primary-600 px-4 py-2 text-sm font-semibold text-white shadow-md transition-colors hover:bg-primary-700"
                >
                  <User className="h-4 w-4" strokeWidth={1.5} />
                  <span className="hidden sm:inline">کارت من</span>
                </Link>
              )}
            </>
          ) : (
            <>
              <Link
                to="/auth"
                className="rounded-xl px-4 py-2 text-sm font-medium text-gray-600 transition-colors hover:bg-white hover:text-primary-600"
              >
                ورود
              </Link>
              <motion.span whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
                <Link
                  to="/auth?mode=signup"
                  className="inline-block rounded-xl bg-primary-600 px-4 py-2 text-sm font-semibold text-white shadow-md transition-colors hover:bg-primary-700"
                >
                  شروع رایگان
                </Link>
              </motion.span>
            </>
          )}
        </div>
      </nav>

      {/* Hero */}
      <section className="mx-auto max-w-6xl px-4 pt-12 pb-20 text-center sm:px-6 sm:pt-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <span className="inline-flex items-center gap-2 rounded-full bg-primary-50 px-4 py-1.5 text-xs font-medium text-primary-700 ring-1 ring-primary-100">
            <Sparkles className="h-3.5 w-3.5" strokeWidth={1.5} />
            نسل جدید کارت ویزیت ایرانی
          </span>
          <h1 className="mx-auto mt-6 max-w-4xl text-4xl font-extrabold leading-tight text-gray-800 sm:text-5xl lg:text-6xl">
            هر ملاقات، یک فرصت برای
            <br />
            <span className="bg-gradient-to-l from-primary-600 to-accent-500 bg-clip-text text-transparent">
              جذب مشتری جدید
            </span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-gray-600 sm:text-lg">
            کارت ویزیت دیجیتال خود را در چند ثانیه بسازید، با یک لینک یا QR Code به اشتراک بگذارید،
            آمار بازدید خود را ببینید، و همیشه به‌روز بمانید. بدون کاغذ، بدون هزینه چاپ، بدون محدودیت.
          </p>
          <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <motion.span whileHover={{ scale: 1.03, y: -2 }} whileTap={{ scale: 0.97 }}>
              <Link
                to={user ? '/dashboard' : '/auth?mode=signup'}
                className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-l from-primary-600 to-primary-500 px-8 py-4 text-sm font-bold text-white shadow-[0_10px_30px_rgba(20,184,166,0.3)] transition-colors"
              >
                {user ? 'ورود به داشبورد' : 'ساخت کارت رایگان'}
                <ArrowLeft className="h-4 w-4" strokeWidth={2} />
              </Link>
            </motion.span>
            <motion.span whileHover={{ scale: 1.03, y: -2 }} whileTap={{ scale: 0.97 }}>
              <Link
                to="/order"
                className="inline-flex items-center gap-2 rounded-2xl bg-white px-8 py-4 text-sm font-bold text-gray-700 shadow-md transition-shadow hover:shadow-lg"
              >
                <CreditCard className="h-4 w-4 text-primary-600" strokeWidth={2} />
                سفارش کارت هیبریدی
              </Link>
            </motion.span>
          </div>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
            {['۱۰۰٪ رایگان', 'کارت ۳بعدی', 'ذخیره در مخاطبین', 'QR Code اختصاصی'].map((t) => (
              <div
                key={t}
                className="flex items-center gap-1.5 rounded-full bg-white px-3.5 py-1.5 text-xs font-medium text-gray-600 shadow-sm"
              >
                <Check className="h-3.5 w-3.5 text-primary-600" strokeWidth={2} />
                {t}
              </div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* ============ کارت ۳بعدی نمونه ============ */}
      <section className="mx-auto max-w-6xl px-4 pb-20 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 text-center"
        >
          <span className="inline-flex items-center gap-2 rounded-full bg-accent-50 px-4 py-1.5 text-xs font-medium text-accent-700 ring-1 ring-accent-100">
            <Boxes className="h-3.5 w-3.5" strokeWidth={1.5} />
            ویژگی جدید
          </span>
          <h2 className="mt-4 text-3xl font-extrabold text-gray-800 sm:text-4xl">
            کارت ویزیت <span className="bg-gradient-to-l from-primary-600 to-accent-500 bg-clip-text text-transparent">۳بعدی تعاملی</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-gray-600">
            کارت ویزیت شما مثل یک کارت فیزیکی واقعی، قابل چرخش و تعامل است. با یک کلیک، پشت و روی آن را ببینید.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="rounded-3xl bg-white p-6 shadow-[0_20px_60px_rgba(0,0,0,0.08)] sm:p-10"
        >
          <Card3D profile={DEMO_PROFILE as any} />

          {/* راهنمای کارت ۳بعدی */}
          <div className="mt-10 grid gap-4 sm:grid-cols-3">
            {[
              {
                icon: MousePointerClick,
                title: 'کلیک کنید',
                desc: 'با کلیک روی کارت، ۳۶۰ درجه می‌چرخد.',
              },
              {
                icon: Eye,
                title: 'پشت کارت را ببینید',
                desc: 'اطلاعات تکمیلی مثل مهارت‌ها و شبکه‌های اجتماعی.',
              },
              {
                icon: Phone,
                title: 'تماس مستقیم',
                desc: 'روی شماره و ایمیل کلیک کنید تا تماس بگیرید.',
              },
            ].map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1 + i * 0.1 }}
                  className="rounded-2xl bg-gray-50 p-5 text-center"
                >
                  <div className="mx-auto mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-primary-100 text-primary-600">
                    <Icon className="h-5 w-5" strokeWidth={1.5} />
                  </div>
                  <h3 className="text-sm font-bold text-gray-800">{item.title}</h3>
                  <p className="mt-1 text-xs leading-relaxed text-gray-500">{item.desc}</p>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      </section>

      {/* Stats */}
      <section className="mx-auto max-w-6xl px-4 pb-16 sm:px-6">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          {[
            { value: '۱۰۰٪', label: 'رایگان' },
            { value: '۲ دقیقه', label: 'زمان ساخت' },
            { value: '۳D', label: 'کارت ۳بعدی' },
            { value: '∞', label: 'قابلیت ویرایش' },
          ].map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="rounded-2xl bg-white p-5 text-center shadow-sm"
            >
              <p className="text-2xl font-extrabold text-primary-600">{stat.value}</p>
              <p className="mt-1 text-xs text-gray-500">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-6xl px-4 pb-20 sm:px-6">
        <div className="mb-12 text-center">
          <h2 className="text-2xl font-extrabold text-gray-800 sm:text-3xl">امکانات کارتین</h2>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-gray-500">
            هر چیزی که برای ساخت و مدیریت کارت ویزیت دیجیتال خود نیاز دارید.
          </p>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => {
            const Icon = f.icon;
            return (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="rounded-3xl bg-white p-6 shadow-[0_2px_12px_rgba(0,0,0,0.04)] transition-shadow hover:shadow-[0_8px_30px_rgba(0,0,0,0.08)]"
              >
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-50 text-primary-600">
                  <Icon className="h-6 w-6" strokeWidth={1.5} />
                </div>
                <h3 className="mb-1.5 text-base font-bold text-gray-800">{f.title}</h3>
                <p className="text-sm leading-relaxed text-gray-500">{f.desc}</p>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* How it works */}
      <section className="mx-auto max-w-6xl px-4 pb-20 sm:px-6">
        <div className="mb-12 text-center">
          <h2 className="text-2xl font-extrabold text-gray-800 sm:text-3xl">در ۳ قدم ساده</h2>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-gray-500">
            در کمتر از ۲ دقیقه کارت ویزیت دیجیتال خود را بسازید.
          </p>
        </div>
        <div className="grid gap-5 sm:grid-cols-3">
          {howItWorks.map((s, i) => (
            <motion.div
              key={s.num}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="rounded-3xl bg-white p-6 shadow-[0_2px_12px_rgba(0,0,0,0.04)]"
            >
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-primary-500 to-accent-500 text-xl font-extrabold text-white shadow-md">
                {s.num}
              </div>
              <h3 className="mb-1.5 text-base font-bold text-gray-800">{s.title}</h3>
              <p className="text-sm leading-relaxed text-gray-500">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Hybrid Card */}
      <section className="mx-auto max-w-6xl px-4 pb-20 sm:px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="grid overflow-hidden rounded-3xl bg-white shadow-[0_8px_30px_rgba(0,0,0,0.08)] sm:grid-cols-2"
        >
          <div className="bg-gradient-to-br from-slate-800 to-primary-800 p-8 text-white sm:p-12">
            <CreditCard className="h-10 w-10 text-primary-300" strokeWidth={1.5} />
            <h3 className="mt-6 text-2xl font-extrabold">کارت هیبریدی کارتین</h3>
            <p className="mt-3 text-sm leading-relaxed text-white/80">
              ترکیب یک کارت فیزیکی زیبا با تراشه NFC و یک کارت ویزیت دیجیتال هوشمند. کافیست مخاطب
              گوشی خود را به کارت شما نزدیک کند تا صفحه دیجیتال شما در مرورگر باز شود.
            </p>
            <Link
              to="/order"
              className="mt-6 inline-flex items-center gap-2 rounded-2xl bg-white px-6 py-3 text-sm font-bold text-primary-700 shadow-lg transition-transform hover:scale-105"
            >
              به زودی — ثبت درخواست
              <ArrowLeft className="h-4 w-4" strokeWidth={2} />
            </Link>
          </div>
          <div className="flex items-center justify-center bg-gradient-to-br from-primary-50 to-accent-50 p-8 sm:p-12">
            <div className="relative h-48 w-72 rounded-2xl bg-gradient-to-br from-primary-600 to-accent-600 shadow-2xl">
              <div className="absolute top-4 right-4 h-8 w-12 rounded bg-yellow-300/80" />
              <div className="absolute bottom-4 right-4 text-right text-white">
                <p className="text-[10px] opacity-80">کارت هیبریدی کارتین</p>
                <p className="mt-1 text-sm font-bold">نام شما</p>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Comparison Table */}
      <section className="mx-auto max-w-4xl px-4 pb-20 sm:px-6">
        <div className="mb-12 text-center">
          <h2 className="text-2xl font-extrabold text-gray-800 sm:text-3xl">
            کارت ویزیت سنتی یا کارت هیبریدی؟
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-gray-500">
            مقایسه‌ای صادقانه بین کارت ویزیت کاغذی و کارت هیبریدی کارتین.
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="overflow-hidden rounded-3xl bg-white shadow-[0_8px_30px_rgba(0,0,0,0.08)]"
        >
          <table className="w-full text-right">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50">
                <th className="px-5 py-4 text-xs font-bold text-gray-500">ویژگی</th>
                <th className="px-5 py-4 text-center text-xs font-bold text-gray-500">
                  کارت ویزیت سنتی
                </th>
                <th className="px-5 py-4 text-center text-xs font-bold text-primary-600">
                  کارت هیبریدی کارتین
                </th>
              </tr>
            </thead>
            <tbody>
              {planFeatures.map((row, i) => (
                <motion.tr
                  key={row.label}
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.03 }}
                  className="border-b border-gray-50 last:border-0"
                >
                  <td className="px-5 py-3.5 text-sm font-medium text-gray-700">{row.label}</td>
                  <td className="px-5 py-3.5 text-center">
                    {row.traditional ? (
                      <Check className="mx-auto h-4 w-4 text-gray-400" strokeWidth={2} />
                    ) : (
                      <XIcon className="mx-auto h-4 w-4 text-gray-300" strokeWidth={2} />
                    )}
                  </td>
                  <td className="px-5 py-3.5 text-center">
                    {row.hybrid ? (
                      <Check className="mx-auto h-4 w-4 text-primary-600" strokeWidth={2} />
                    ) : (
                      <XIcon className="mx-auto h-4 w-4 text-gray-300" strokeWidth={2} />
                    )}
                  </td>
                </motion.tr>
              ))}
              <tr className="bg-primary-50/50">
                <td className="px-5 py-4 text-sm font-bold text-gray-800">هزینه</td>
                <td className="px-5 py-4 text-center text-xs text-gray-500">
                  از ۱ میلیون تومان به بالا
                  <br />
                  <span className="text-[10px]">(بسته به تعداد و جنس)</span>
                </td>
                <td className="px-5 py-4 text-center text-xs font-bold text-primary-700">
                  به زودی اعلام می‌شود
                  <br />
                  <span className="text-[10px] font-normal">یک بار خرید، همیشه به‌روز</span>
                </td>
              </tr>
            </tbody>
          </table>
        </motion.div>

        <p className="mt-6 text-center text-xs leading-relaxed text-gray-400">
          💡 کارت ویزیت کاغذی از یک میلیون تومان به بالا هزینه دارد و ثابت می‌ماند؛ اما نسخه هیبریدی
          کارتین را یک بار بخرید و همیشه به‌روز بمانید ✨
        </p>
      </section>

      {/* Testimonials */}
      <section className="overflow-hidden pb-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="mb-12 text-center">
            <h2 className="text-2xl font-extrabold text-gray-800 sm:text-3xl">
              مشتریان درباره کارتین چه می‌گویند؟
            </h2>
            <div className="mt-3 flex items-center justify-center gap-1">
              {[1, 2, 3, 4, 5].map((i) => (
                <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />
              ))}
              <span className="mr-2 text-sm font-medium text-gray-600">
                ۴.۹ از ۵ — بیش از ۱۳۷ نظر
              </span>
            </div>
          </div>
        </div>

        <div className="marquee-single">
          <div className="marquee-single-track">
            {[...testimonials, ...testimonials].map((t, i) => (
              <TestimonialCard key={i} {...t} />
            ))}
          </div>
        </div>
      </section>

      {/* Gamification */}
      <section className="mx-auto max-w-6xl px-4 pb-20 sm:px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="overflow-hidden rounded-3xl bg-gradient-to-l from-emerald-500 to-teal-600 p-8 text-center shadow-2xl sm:p-12"
        >
          <div className="mb-6 inline-flex h-16 w-16 items-center justify-center rounded-3xl bg-white/20 backdrop-blur-sm">
            <TreePine className="h-8 w-8 text-white" strokeWidth={1.5} />
          </div>
          <h2 className="text-2xl font-extrabold text-white sm:text-3xl">
            با کارتین، ناجی درختان باشید 🌱
          </h2>
          <p className="mx-auto mt-3 max-w-lg text-sm leading-relaxed text-white/90">
            با هر بار ذخیره کارت ویزیت دیجیتال شما در مخاطبین، از هدر رفتن کاغذ جلوگیری می‌شود و به
            حفظ محیط زیست کمک می‌کنید.
          </p>
        </motion.div>
      </section>

      {/* Pricing */}
      <section className="mx-auto max-w-6xl px-4 pb-20 sm:px-6">
        <div className="mb-12 text-center">
          <h2 className="text-2xl font-extrabold text-gray-800 sm:text-3xl">پلن‌های قیمت‌گذاری</h2>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-gray-500">
            با نسخه رایگان شروع کنید و در صورت نیاز به امکانات بیشتر، ارتقا دهید.
          </p>
        </div>
        <div className="grid gap-5 lg:grid-cols-3">
          {/* Free */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="rounded-3xl bg-white p-8 shadow-[0_2px_12px_rgba(0,0,0,0.04)]"
          >
            <h3 className="text-lg font-extrabold text-gray-800">رایگان</h3>
            <p className="mt-1 text-sm text-gray-500">برای شروع و استفاده شخصی</p>
            <p className="mt-6 text-4xl font-extrabold text-gray-800">
              ۰<span className="text-base font-medium text-gray-400"> تومان</span>
            </p>
            <ul className="mt-6 space-y-3">
              {[
                'ساخت کارت ویزیت دیجیتال',
                'لینک اختصاصی',
                'QR Code',
                'ذخیره در مخاطبین (vCard)',
                'آمار بازدید پایه',
              ].map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm text-gray-600">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary-600" strokeWidth={2} />
                  {item}
                </li>
              ))}
            </ul>
            <Link
              to={user ? '/dashboard' : '/auth?mode=signup'}
              className="mt-8 block rounded-2xl bg-gray-100 py-3.5 text-center text-sm font-bold text-gray-700 transition-colors hover:bg-gray-200"
            >
              {user ? 'ورود به داشبورد' : 'شروع رایگان'}
            </Link>
          </motion.div>

          {/* Pro */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary-600 to-accent-600 p-8 text-white shadow-2xl lg:scale-105"
          >
            <span className="absolute top-4 left-4 rounded-full bg-white/20 px-3 py-1 text-[10px] font-bold backdrop-blur-sm">
              پیشنهاد ویژه
            </span>
            <div className="flex items-center gap-2">
              <Crown className="h-5 w-5" strokeWidth={1.5} />
              <h3 className="text-lg font-extrabold">حرفه‌ای</h3>
            </div>
            <p className="mt-1 text-sm text-white/80">برای فریلنسرها و متخصصین</p>
            <div className="mt-6">
              <p className="text-4xl font-extrabold">
                ۳۹۹<span className="text-base font-medium text-white/70"> هزار تومان / ماه</span>
              </p>
              <p className="mt-2 text-xs text-white/80">کمتر از قیمت یک مینی‌پیتزا در ماه! 🍕</p>
            </div>
            <ul className="mt-6 space-y-3">
              {[
                'تمام امکانات نسخه رایگان',
                'کارت ۳بعدی تعاملی',
                'آمار بازدید پیشرفته و نمودار',
                'صفحه‌ساز هوشمند (AI)',
                'معرفی صوتی و ویدیویی',
                'قالب‌های اختصاصی',
                'پشتیبانی اولویت‌دار',
              ].map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm">
                  <Check className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={2} />
                  {item}
                </li>
              ))}
            </ul>
            <Link
              to="/pricing"
              className="mt-8 block rounded-2xl bg-white py-3.5 text-center text-sm font-bold text-primary-700 transition-transform hover:scale-[1.02]"
            >
              ارتقا به نسخه حرفه‌ای
            </Link>
          </motion.div>

          {/* Enterprise */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="rounded-3xl bg-white p-8 shadow-[0_2px_12px_rgba(0,0,0,0.04)]"
          >
            <div className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-gray-700" strokeWidth={1.5} />
              <h3 className="text-lg font-extrabold text-gray-800">سازمانی</h3>
            </div>
            <p className="mt-1 text-sm text-gray-500">برای شرکت‌ها و تیم‌ها</p>
            <p className="mt-6 text-4xl font-extrabold text-gray-800">
              سفارشی<span className="text-base font-medium text-gray-400"> / توافقی</span>
            </p>
            <ul className="mt-6 space-y-3">
              {[
                'تمام امکانات نسخه حرفه‌ای',
                'کارت ویزیت اختصاصی برای هر کارمند',
                'پنل مدیریت سازمانی',
                'قالب اختصاصی با لوگوی شرکت',
                'آمار تیمی و گزارش‌گیری',
                'پشتیبانی اختصاصی',
              ].map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm text-gray-600">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary-600" strokeWidth={2} />
                  {item}
                </li>
              ))}
            </ul>
            <Link
              to="/pricing"
              className="mt-8 block rounded-2xl bg-gray-900 py-3.5 text-center text-sm font-bold text-white transition-colors hover:bg-gray-800"
            >
              درخواست مشاوره
            </Link>
          </motion.div>
        </div>

        <p className="mt-8 text-center text-xs text-gray-400">
          * قیمت‌گذاری کارت هیبریدی NFC به زودی اعلام می‌شود.
        </p>
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-3xl px-4 pb-20 sm:px-6">
        <div className="mb-12 text-center">
          <div className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-50 text-primary-600">
            <HelpCircle className="h-6 w-6" strokeWidth={1.5} />
          </div>
          <h2 className="text-2xl font-extrabold text-gray-800 sm:text-3xl">سوالات متداول</h2>
        </div>
        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <motion.div
              key={faq.q}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="rounded-2xl bg-white p-6 shadow-[0_2px_12px_rgba(0,0,0,0.04)]"
            >
              <h3 className="mb-2 text-sm font-bold text-gray-800">{faq.q}</h3>
              <p className="text-sm leading-relaxed text-gray-500">{faq.a}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Final CTA */}
      <section className="mx-auto max-w-4xl px-4 pb-24 sm:px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="overflow-hidden rounded-3xl bg-gradient-to-l from-primary-600 to-accent-600 p-10 text-center shadow-2xl sm:p-16"
        >
          <h2 className="text-2xl font-extrabold text-white sm:text-4xl">همین حالا شروع کنید</h2>
          <p className="mx-auto mt-4 max-w-md text-sm leading-relaxed text-white/80">
            ساخت کارت ویزیت دیجیتال کاملاً رایگان است. فقط کافیست ثبت‌نام کنید و کارت خود را بسازید.
          </p>
          <Link
            to={user ? '/dashboard' : '/auth?mode=signup'}
            className="mt-8 inline-flex items-center gap-2 rounded-2xl bg-white px-8 py-4 text-sm font-bold text-primary-700 shadow-lg transition-transform hover:scale-105"
          >
            {user ? 'ورود به داشبورد' : 'ساخت کارت رایگان'}
            <ArrowLeft className="h-4 w-4" strokeWidth={2} />
          </Link>
        </motion.div>
      </section>

      <footer className="border-t border-gray-100 py-8 text-center">
        <div className="mx-auto max-w-6xl px-4">
          <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-accent-500">
                <Sparkles className="h-4 w-4 text-white" strokeWidth={1.5} />
              </div>
              <span className="text-sm font-bold text-gray-700">کارتین</span>
            </div>
            <div className="flex gap-6 text-xs text-gray-400">
              <Link to="/pricing" className="transition-colors hover:text-primary-600">
                قیمت‌گذاری
              </Link>
              <Link to="/order" className="transition-colors hover:text-primary-600">
                کارت هیبریدی
              </Link>
              <Link to="/about" className="transition-colors hover:text-primary-600">
                درباره ما
              </Link>
              <Link to="/auth" className="transition-colors hover:text-primary-600">
                ورود
              </Link>
            </div>
            <p className="text-xs text-gray-400">ساخته شده با ❤️ برای ایران</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

/* ─────────────────────────────────────────────
   Testimonial Card
────────────────────────────────────────────── */
function TestimonialCard({
  name,
  role,
  text,
  rating,
}: {
  name: string;
  role: string;
  text: string;
  rating: number;
}) {
  return (
    <div className="flex w-[300px] shrink-0 flex-col rounded-2xl bg-white p-5 shadow-[0_2px_16px_rgba(0,0,0,0.06)] transition-shadow hover:shadow-[0_12px_40px_rgba(0,0,0,0.12)] sm:w-[340px]">
      <div className="mb-2.5 flex gap-0.5">
        {Array.from({ length: rating }).map((_, s) => (
          <Star key={s} className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
        ))}
      </div>
      <p className="flex-1 text-[13px] leading-relaxed text-gray-600">"{text}"</p>
      <div className="mt-4 flex items-center gap-2.5 border-t border-gray-50 pt-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-primary-500 to-accent-500 text-xs font-bold text-white shadow-sm">
          {name.charAt(0)}
        </div>
        <div>
          <p className="text-[13px] font-bold text-gray-800">{name}</p>
          <p className="text-[11px] text-gray-400">{role}</p>
        </div>
      </div>
    </div>
  );
}