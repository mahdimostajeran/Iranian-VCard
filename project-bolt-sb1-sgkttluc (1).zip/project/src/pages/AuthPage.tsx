import { useState } from 'react';
import { useNavigate, Link, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, Lock, ArrowLeft, AlertCircle, UserCircle, Sparkles, X, CheckCircle2 } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/lib/supabase';

export function AuthPage() {
  const [searchParams] = useSearchParams();
  const isSignup = searchParams.get('mode') === 'signup';
  const { signIn, signUp } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Forget password modal
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotSuccess, setForgotSuccess] = useState(false);
  const [forgotError, setForgotError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (isSignup) {
        await signUp(email, password);
      } else {
        await signIn(email, password);
      }
      navigate('/dashboard');
    } catch (err: any) {
      // تشخیص نوع خطا
      const msg = String(err?.message || err || '').toLowerCase();
      const isNetwork = msg.includes('fetch') || msg.includes('network') || msg.includes('connection') || err?.name === 'TypeError';
      const isInvalid = msg.includes('invalid') || msg.includes('credentials') || msg.includes('password');
      const isConfirm = msg.includes('email not confirmed') || msg.includes('not confirmed');

      if (isNetwork) {
        setError('اتصال به سرور برقرار نشد. لطفاً اینترنت خود را بررسی کنید یا VPN را روشن/خاموش کنید.');
      } else if (isConfirm) {
        setError('ایمیل شما تأیید نشده است. لطفاً ایمیل خود را بررسی کنید.');
      } else if (isInvalid) {
        setError('ایمیل یا رمز عبور اشتباه است. اگر رمز را فراموش کرده‌اید، روی «فراموشی رمز» کلیک کنید.');
      } else if (isSignup) {
        setError('ثبت‌نام ناموفق بود. ممکن است این ایمیل قبلاً استفاده شده باشد.');
      } else {
        setError('خطای ناشناخته. لطفاً دوباره تلاش کنید.');
      }
      console.error('[Auth] error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail.trim()) return;
    setForgotLoading(true);
    setForgotError('');
    setForgotSuccess(false);
    try {
      const { error: resetError } = await supabase.auth.resetPasswordForEmail(
        forgotEmail.trim(),
        {
          redirectTo: `${window.location.origin}/auth?mode=reset`,
        }
      );
      if (resetError) throw resetError;
      setForgotSuccess(true);
    } catch (err: any) {
      const msg = String(err?.message || '').toLowerCase();
      if (msg.includes('fetch') || msg.includes('network') || err?.name === 'TypeError') {
        setForgotError('اتصال به سرور برقرار نشد. لطفاً اینترنت خود را بررسی کنید.');
      } else {
        setForgotError('خطا در ارسال ایمیل بازیابی. لطفاً دوباره تلاش کنید.');
      }
      console.error('[Auth] forgot error:', err);
    } finally {
      setForgotLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center gradient-mesh p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md"
      >
        <div className="rounded-3xl bg-white p-8 shadow-[0_10px_40px_rgba(0,0,0,0.08)] sm:p-10">
          {/* Logo */}
          <div className="mb-8 text-center">
            <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary-500 to-accent-500 shadow-lg">
              <UserCircle className="h-9 w-9 text-white" strokeWidth={1.5} />
            </div>
            <h1 className="text-2xl font-extrabold text-gray-800">
              {isSignup ? 'ساخت حساب کاربری' : 'ورود به حساب'}
            </h1>
            <p className="mt-1 text-sm text-gray-500">
              {isSignup ? 'کارت ویزیت دیجیتال خود را بسازید' : 'به کارت ویزیت دیجیتال خوش آمدید'}
            </p>
          </div>

          {error && (
            <div className="mb-4 flex items-start gap-2 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-600">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.5} />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-gray-700">ایمیل</label>
              <div className="relative">
                <Mail className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" strokeWidth={1.5} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  dir="ltr"
                  placeholder="you@example.com"
                  className="w-full rounded-xl border border-gray-200 bg-gray-50 py-3 pr-11 pl-4 text-sm text-gray-800 transition-colors focus:border-primary-400 focus:bg-white focus:ring-2 focus:ring-primary-100"
                />
              </div>
            </div>

            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label className="block text-sm font-medium text-gray-700">رمز عبور</label>
                {!isSignup && (
                  <button
                    type="button"
                    onClick={() => {
                      setForgotEmail(email);
                      setForgotOpen(true);
                      setForgotSuccess(false);
                      setForgotError('');
                    }}
                    className="text-xs font-medium text-primary-600 hover:text-primary-700"
                  >
                    فراموشی رمز؟
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" strokeWidth={1.5} />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                  dir="ltr"
                  placeholder="••••••••"
                  className="w-full rounded-xl border border-gray-200 bg-gray-50 py-3 pr-11 pl-4 text-sm text-gray-800 transition-colors focus:border-primary-400 focus:bg-white focus:ring-2 focus:ring-primary-100"
                />
              </div>
            </div>

            <motion.button
              type="submit"
              disabled={loading}
              whileHover={{ scale: 1.01, y: -2 }}
              whileTap={{ scale: 0.98 }}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary-600 py-3 text-sm font-semibold text-white shadow-md transition-colors hover:bg-primary-700 disabled:opacity-50"
            >
              {loading ? (
                <div className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white" />
              ) : (
                <>
                  {isSignup ? 'ثبت‌نام' : 'ورود'}
                  <ArrowLeft className="h-4 w-4" strokeWidth={1.5} />
                </>
              )}
            </motion.button>
          </form>

          <div className="mt-6 text-center text-sm text-gray-500">
            {isSignup ? 'حساب دارید؟' : 'حساب ندارید؟'}{' '}
            <Link
              to={isSignup ? '/auth' : '/auth?mode=signup'}
              className="font-semibold text-primary-600 hover:text-primary-700"
            >
              {isSignup ? 'ورود کنید' : 'ثبت‌نام کنید'}
            </Link>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-center gap-2 text-xs text-gray-400">
          <Sparkles className="h-3.5 w-3.5" strokeWidth={1.5} />
          <span>کارت ویزیت دیجیتال ایران</span>
        </div>
      </motion.div>

      {/* Forgot Password Modal */}
      <AnimatePresence>
        {forgotOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
          >
            <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={() => setForgotOpen(false)} />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative z-10 w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl"
            >
              <button
                onClick={() => setForgotOpen(false)}
                className="absolute top-4 left-4 rounded-full p-2 text-gray-400 hover:bg-gray-100"
              >
                <X className="h-5 w-5" />
              </button>

              {forgotSuccess ? (
                <div className="py-4 text-center">
                  <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-50">
                    <CheckCircle2 className="h-7 w-7 text-emerald-600" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-800">ایمیل ارسال شد</h3>
                  <p className="mt-2 text-sm text-gray-500">
                    لطفاً ایمیل خود را بررسی کنید و روی لینک بازیابی رمز کلیک کنید.
                  </p>
                  <button
                    onClick={() => setForgotOpen(false)}
                    className="mt-5 w-full rounded-xl bg-primary-600 py-2.5 text-sm font-bold text-white hover:bg-primary-700"
                  >
                    متوجه شدم
                  </button>
                </div>
              ) : (
                <>
                  <h3 className="mb-2 text-lg font-bold text-gray-800">بازیابی رمز عبور</h3>
                  <p className="mb-4 text-xs text-gray-500">
                    ایمیل خود را وارد کنید تا لینک بازیابی برایتان ارسال شود.
                  </p>
                  <form onSubmit={handleForgotPassword} className="space-y-3">
                    <div className="relative">
                      <Mail className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
                      <input
                        type="email"
                        value={forgotEmail}
                        onChange={(e) => setForgotEmail(e.target.value)}
                        required
                        dir="ltr"
                        placeholder="you@example.com"
                        className="w-full rounded-xl border border-gray-200 bg-gray-50 py-3 pr-11 pl-4 text-sm focus:border-primary-400 focus:bg-white"
                      />
                    </div>
                    {forgotError && (
                      <p className="rounded-lg bg-red-50 px-3 py-2 text-xs text-red-600">{forgotError}</p>
                    )}
                    <button
                      type="submit"
                      disabled={forgotLoading}
                      className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary-600 py-3 text-sm font-bold text-white hover:bg-primary-700 disabled:opacity-50"
                    >
                      {forgotLoading ? (
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                      ) : (
                        'ارسال لینک بازیابی'
                      )}
                    </button>
                  </form>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}