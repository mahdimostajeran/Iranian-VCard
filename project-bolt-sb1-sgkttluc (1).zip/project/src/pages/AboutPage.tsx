import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Sparkles, Heart, Target, Users, Send, Mail, ArrowLeft } from 'lucide-react';

export function AboutPage() {
  return (
    <div className="min-h-screen gradient-mesh">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5 sm:px-6">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 shadow-md">
            <Sparkles className="h-5 w-5 text-white" strokeWidth={1.5} />
          </div>
          <span className="text-lg font-extrabold text-gray-800">کارتین</span>
        </Link>
        <Link
          to="/"
          className="flex items-center gap-1.5 rounded-xl px-4 py-2 text-sm font-medium text-gray-600 transition-colors hover:bg-white hover:text-primary-600"
        >
          <ArrowLeft className="h-4 w-4" strokeWidth={1.5} />
          بازگشت
        </Link>
      </nav>

      <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6 sm:py-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full bg-primary-50 px-4 py-1.5 text-xs font-medium text-primary-700 ring-1 ring-primary-100">
            <Heart className="h-3.5 w-3.5" strokeWidth={1.5} />
            درباره ما
          </span>
          <h1 className="mt-6 text-3xl font-extrabold text-gray-800 sm:text-4xl">
            داستان{' '}
            <span className="bg-gradient-to-l from-primary-600 to-accent-500 bg-clip-text text-transparent">
              کارتین
            </span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-gray-600">
            ما یک تیم کوچک اما پرانرژی هستیم که باور داریم ارتباطات انسانی نباید پیچیده باشد. هدف ما
            این است که هر فرد، فارغ از شغل و جایگاه، بتواند در چند ثانیه یک کارت ویزیت حرفه‌ای و
            ماندگار داشته باشد — بدون کاغذ، بدون هزینه چاپ، و بدون محدودیت.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mt-16 grid gap-5 sm:grid-cols-3"
        >
          {[
            {
              icon: Target,
              title: 'مأموریت ما',
              desc: 'توانمندسازی هر فرد برای داشتن یک هویت دیجیتال حرفه‌ای و در دسترس.',
            },
            {
              icon: Users,
              title: 'تیم ما',
              desc: 'گروهی از طراحان، توسعه‌دهندگان و کارآفرینان که عاشق ساختن محصولات کاربردی هستند.',
            },
            {
              icon: Heart,
              title: 'ارزش‌های ما',
              desc: 'شفافیت، سادگی، احترام به محیط زیست، و تمرکز بر تجربه کاربری.',
            },
          ].map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + i * 0.1 }}
                className="rounded-3xl bg-white p-6 text-center shadow-sm"
              >
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-50 text-primary-600">
                  <Icon className="h-6 w-6" strokeWidth={1.5} />
                </div>
                <h3 className="text-base font-bold text-gray-800">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-gray-500">{item.desc}</p>
              </motion.div>
            );
          })}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-16 rounded-3xl bg-gradient-to-l from-primary-600 to-accent-600 p-8 text-center text-white shadow-2xl sm:p-12"
        >
          <h2 className="text-2xl font-extrabold sm:text-3xl">با ما در ارتباط باشید</h2>
          <p className="mx-auto mt-4 max-w-md text-sm leading-relaxed text-white/90">
            اگر پیشنهاد، انتقاد یا ایده‌ای دارید، خوشحال می‌شویم بشنویم. تیم ما همیشه پاسخگو است.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <a
              href="https://t.me/mahdimostajeran"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-2xl bg-white/15 px-6 py-3 text-sm font-bold text-white backdrop-blur-sm transition-colors hover:bg-white/25"
            >
              <Send className="h-4 w-4" strokeWidth={2} />
              تلگرام
            </a>
            <a
              href="mailto:info@kartin.ir"
              className="inline-flex items-center gap-2 rounded-2xl bg-white px-6 py-3 text-sm font-bold text-primary-700 transition-transform hover:scale-105"
            >
              <Mail className="h-4 w-4" strokeWidth={2} />
              ایمیل
            </a>
          </div>
        </motion.div>
      </div>
    </div>
  );
}