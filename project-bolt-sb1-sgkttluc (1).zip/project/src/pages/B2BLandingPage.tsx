import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Sparkles,
  ArrowLeft,
  Check,
  Building2,
  CreditCard,
  Percent,
  Gift,
  Users,
  Briefcase,
  TrendingUp,
  QrCode,
  Send,
  Phone,
  Mail,
  MapPin,
  Store,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface B2BFormData {
  business_name: string;
  business_type: string;
  city: string;
  phone: string;
  email: string;
  team_size: string;
  notes: string;
}

const BUSINESS_TYPES = [
  { value: 'tech_office', label: 'دفتر فنی / مهندسی' },
  { value: 'agency', label: 'آژانس مسافرتی' },
  { value: 'real_estate', label: 'مشاور املاک' },
  { value: 'insurance', label: 'بیمه' },
  { value: 'medical', label: 'کلینیک / پزشکی' },
  { value: 'legal', label: 'دفتر حقوقی' },
  { value: 'marketing', label: 'بازاریابی / تبلیغات' },
  { value: 'other', label: 'سایر' },
];

export function B2BLandingPage() {
  const [formData, setFormData] = useState<B2BFormData>({
    business_name: '',
    business_type: '',
    city: '',
    phone: '',
    email: '',
    team_size: '',
    notes: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      const { error: insertError } = await supabase.from('b2b_requests').insert({
        business_name: formData.business_name,
        business_type: formData.business_type,
        city: formData.city,
        phone: formData.phone,
        email: formData.email || null,
        team_size: parseInt(formData.team_size) || null,
        notes: formData.notes || null,
        status: 'pending',
      });
      if (insertError) throw insertError;
      setSubmitted(true);
    } catch (err: any) {
      console.error('[B2B] Submit failed:', err);
      setError('خطا در ثبت درخواست. لطفاً دوباره تلاش کنید.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen gradient-mesh">
      {/* Navbar */}
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5 sm:px-6">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 shadow-md">
            <Sparkles className="h-5 w-5 text-white" strokeWidth={1.5} />
          </div>
          <span className="text-lg font-extrabold text-gray-800">کارتین</span>
        </Link>
        <div className="flex items-center gap-2">
          <Link
            to="/"
            className="flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm font-medium text-gray-600 transition-colors hover:bg-white hover:text-primary-600"
          >
            <ArrowLeft className="h-4 w-4" strokeWidth={1.5} />
            <span className="hidden sm:inline">بازگشت</span>
          </Link>
          <Link
            to="/auth?mode=signup"
            className="rounded-xl bg-primary-600 px-4 py-2 text-sm font-semibold text-white shadow-md transition-colors hover:bg-primary-700"
          >
            شروع رایگان
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="mx-auto max-w-5xl px-4 pt-12 pb-16 text-center sm:px-6 sm:pt-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <span className="inline-flex items-center gap-2 rounded-full bg-accent-50 px-4 py-1.5 text-xs font-medium text-accent-700 ring-1 ring-accent-100">
            <Building2 className="h-3.5 w-3.5" strokeWidth={1.5} />
            برنامه همکاری با کسب‌وکارها
          </span>
          <h1 className="mx-auto mt-6 max-w-3xl text-3xl font-extrabold leading-tight text-gray-800 sm:text-4xl lg:text-5xl">
            هر کارتی که روی میز شماست،
            <br />
            <span className="bg-gradient-to-l from-primary-600 to-accent-500 bg-clip-text text-transparent">
              درآمد شماست
            </span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-gray-600">
            با معرفی کارتین به مشتریان خود، ۲۰٪ از درآمد آن‌ها را دریافت کنید.
            کارت ویزیت دیجیتال رایگان برای تیم شما + استند NFC اختصاصی روی میز پذیرش.
          </p>
          <a
            href="#form"
            className="mt-8 inline-flex items-center gap-2 rounded-2xl bg-gradient-to-l from-primary-600 to-primary-500 px-8 py-4 text-sm font-bold text-white shadow-[0_10px_30px_rgba(20,184,166,0.3)] transition-transform hover:scale-105"
          >
            <Briefcase className="h-4 w-4" strokeWidth={2} />
            درخواست همکاری
          </a>
        </motion.div>
      </section>

      {/* سه مزیت اصلی */}
      <section className="mx-auto max-w-5xl px-4 pb-16 sm:px-6">
        <div className="grid gap-5 sm:grid-cols-3">
          {[
            {
              icon: Gift,
              title: 'کارتین رایگان برای تیم',
              desc: 'تا ۱۰ نفر از اعضای تیم شما کارت ویزیت دیجیتال رایگان دریافت می‌کنند.',
              color: 'from-primary-500 to-primary-600',
            },
            {
              icon: QrCode,
              title: 'استند NFC اختصاصی',
              desc: 'استند زیبای رومیزی با تراشه NFC و QR برای معرفی سریع به مشتریان.',
              color: 'from-accent-500 to-accent-600',
            },
            {
              icon: Percent,
              title: '۲۰٪ کمیسیون',
              desc: 'از هر مشتری که معرفی می‌کنید، ۲۰٪ از درآمدش برای همیشه سهم شماست.',
              color: 'from-emerald-500 to-emerald-600',
            },
          ].map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + i * 0.1 }}
                className="rounded-3xl bg-white p-6 shadow-[0_2px_12px_rgba(0,0,0,0.04)]"
              >
                <div className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br ${item.color} shadow-md`}>
                  <Icon className="h-6 w-6 text-white" strokeWidth={1.5} />
                </div>
                <h3 className="mb-2 text-base font-bold text-gray-800">{item.title}</h3>
                <p className="text-sm leading-relaxed text-gray-500">{item.desc}</p>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* برای چه کسانی */}
      <section className="mx-auto max-w-5xl px-4 pb-16 sm:px-6">
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-extrabold text-gray-800 sm:text-3xl">
            مناسب برای چه کسب‌وکارهایی؟
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-sm text-gray-500">
            هر جایی که مشتری به شما مراجعه می‌کند و می‌خواهد راه ارتباطی داشته باشد.
          </p>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: Building2, label: 'دفاتر فنی و مهندسی' },
            { icon: Store, label: 'مشاوران املاک' },
            { icon: Briefcase, label: 'آژانس‌های مسافرتی' },
            { icon: Users, label: 'کلینیک و پزشکان' },
          ].map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="flex flex-col items-center gap-2 rounded-2xl bg-white p-5 text-center shadow-sm"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-50 text-primary-600">
                  <Icon className="h-5 w-5" strokeWidth={1.5} />
                </div>
                <p className="text-sm font-medium text-gray-700">{item.label}</p>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* فرم درخواست */}
      <section id="form" className="mx-auto max-w-2xl px-4 pb-20 sm:px-6">
        <div className="rounded-3xl bg-white p-6 shadow-[0_10px_40px_rgba(0,0,0,0.08)] sm:p-10">
          {submitted ? (
            <div className="py-8 text-center">
              <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50">
                <Check className="h-8 w-8 text-emerald-600" strokeWidth={2} />
              </div>
              <h2 className="text-xl font-extrabold text-gray-800">درخواست شما ثبت شد!</h2>
              <p className="mx-auto mt-3 max-w-sm text-sm leading-relaxed text-gray-500">
                کارشناسان ما در کمتر از ۴۸ ساعت با شما تماس می‌گیرند و جزئیات همکاری را اعلام می‌کنند.
              </p>
              <Link
                to="/"
                className="mt-8 inline-flex items-center gap-2 rounded-2xl bg-primary-600 px-6 py-3 text-sm font-bold text-white shadow-md transition-colors hover:bg-primary-700"
              >
                بازگشت به خانه
                <ArrowLeft className="h-4 w-4" strokeWidth={2} />
              </Link>
            </div>
          ) : (
            <>
              <div className="mb-6 text-center">
                <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-primary-500 to-accent-500 shadow-md">
                  <TrendingUp className="h-6 w-6 text-white" strokeWidth={1.5} />
                </div>
                <h2 className="text-xl font-extrabold text-gray-800">درخواست همکاری</h2>
                <p className="mt-2 text-sm text-gray-500">
                  اطلاعات کسب‌وکار خود را وارد کنید
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">
                    نام کسب‌وکار *
                  </label>
                  <div className="relative">
                    <Building2 className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" strokeWidth={1.5} />
                    <input
                      type="text"
                      required
                      value={formData.business_name}
                      onChange={(e) => setFormData({ ...formData, business_name: e.target.value })}
                      className="w-full rounded-xl border border-gray-100 bg-gray-50 py-3 pr-10 pl-4 text-sm transition-all focus:border-primary-300 focus:bg-white focus:shadow-[0_0_0_3px_rgba(20,184,166,0.1)]"
                      placeholder="مثلاً: دفتر مهندسی پارس"
                    />
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">
                    نوع کسب‌وکار *
                  </label>
                  <select
                    required
                    value={formData.business_type}
                    onChange={(e) => setFormData({ ...formData, business_type: e.target.value })}
                    className="w-full rounded-xl border border-gray-100 bg-gray-50 px-4 py-3 text-sm transition-all focus:border-primary-300 focus:bg-white"
                  >
                    <option value="">انتخاب کنید...</option>
                    {BUSINESS_TYPES.map((t) => (
                      <option key={t.value} value={t.value}>{t.label}</option>
                    ))}
                  </select>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="mb-1.5 block text-xs font-medium text-gray-600">
                      شهر *
                    </label>
                    <div className="relative">
                      <MapPin className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" strokeWidth={1.5} />
                      <input
                        type="text"
                        required
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        className="w-full rounded-xl border border-gray-100 bg-gray-50 py-3 pr-10 pl-4 text-sm transition-all focus:border-primary-300 focus:bg-white"
                        placeholder="تهران"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs font-medium text-gray-600">
                      تعداد نفرات تیم
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={formData.team_size}
                      onChange={(e) => setFormData({ ...formData, team_size: e.target.value })}
                      className="w-full rounded-xl border border-gray-100 bg-gray-50 px-4 py-3 text-sm transition-all focus:border-primary-300 focus:bg-white"
                      placeholder="۵"
                    />
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">
                    شماره تماس *
                  </label>
                  <div className="relative">
                    <Phone className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" strokeWidth={1.5} />
                    <input
                      type="tel"
                      required
                      dir="ltr"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full rounded-xl border border-gray-100 bg-gray-50 py-3 pr-10 pl-4 text-left text-sm transition-all focus:border-primary-300 focus:bg-white"
                      placeholder="0912..."
                    />
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">
                    ایمیل (اختیاری)
                  </label>
                  <div className="relative">
                    <Mail className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" strokeWidth={1.5} />
                    <input
                      type="email"
                      dir="ltr"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full rounded-xl border border-gray-100 bg-gray-50 py-3 pr-10 pl-4 text-left text-sm transition-all focus:border-primary-300 focus:bg-white"
                      placeholder="you@example.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-medium text-gray-600">
                    توضیحات (اختیاری)
                  </label>
                  <textarea
                    rows={3}
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    className="w-full resize-none rounded-xl border border-gray-100 bg-gray-50 px-4 py-3 text-sm transition-all focus:border-primary-300 focus:bg-white"
                    placeholder="هر توضیح دیگری که فکر می‌کنید مفید است..."
                  />
                </div>

                {error && (
                  <div className="rounded-xl bg-red-50 px-4 py-3 text-xs text-red-600">{error}</div>
                )}

                <button
                  type="submit"
                  disabled={submitting}
                  className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-primary-600 to-primary-500 py-4 text-sm font-bold text-white shadow-[0_8px_24px_rgba(20,184,166,0.25)] transition-all hover:shadow-[0_12px_30px_rgba(20,184,166,0.35)] disabled:opacity-50"
                >
                  {submitting ? (
                    <div className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                  ) : (
                    <>
                      <Send className="h-4 w-4" strokeWidth={2} />
                      ارسال درخواست
                    </>
                  )}
                </button>

                <p className="text-center text-[11px] leading-relaxed text-gray-400">
                  با ارسال این فرم، تیم ما در کمتر از ۴۸ ساعت با شما تماس می‌گیرد.
                </p>
              </form>
            </>
          )}
        </div>
      </section>

      {/* FAQ کوتاه */}
      <section className="mx-auto max-w-3xl px-4 pb-20 sm:px-6">
        <h2 className="mb-8 text-center text-2xl font-extrabold text-gray-800">
          سوالات متداول
        </h2>
        <div className="space-y-3">
          {[
            {
              q: 'کمیسیون چطور محاسبه می‌شود؟',
              a: 'از هر پرداختی که مشتری معرفی‌شده شما انجام دهد، ۲۰٪ به حساب شما واریز می‌شود. پرداخت‌ها ماهانه تسویه می‌شوند.',
            },
            {
              q: 'استند NFC چه کاربردی دارد؟',
              a: 'مشتری گوشی خود را به استند نزدیک می‌کند و بلافاصله کارت ویزیت دیجیتال شما باز می‌شود. همچنین QR Code برای دستگاه‌های قدیمی‌تر دارد.',
            },
            {
              q: 'هزینه‌ای برای همکاری وجود دارد؟',
              a: 'خیر، کاملاً رایگان است. حتی کارت ویزیت دیجیتال برای تیم شما رایگان است.',
            },
          ].map((faq, i) => (
            <motion.div
              key={faq.q}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="rounded-2xl bg-white p-5 shadow-sm"
            >
              <h3 className="mb-2 text-sm font-bold text-gray-800">{faq.q}</h3>
              <p className="text-sm leading-relaxed text-gray-500">{faq.a}</p>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}