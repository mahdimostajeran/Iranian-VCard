import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle2, XCircle, ArrowLeft } from 'lucide-react';

export function PaymentCallbackPage() {
  const [searchParams] = useSearchParams();
  const [status, setStatus] = useState<'loading' | 'success' | 'failed'>('loading');
  const [message, setMessage] = useState('در حال بررسی پرداخت...');

  useEffect(() => {
    const authority = searchParams.get('Authority');
    const paymentStatus = searchParams.get('Status');

    if (!authority) {
      setStatus('failed');
      setMessage('اطلاعات پرداخت ناقص است.');
      return;
    }

    if (paymentStatus === 'OK') {
      setStatus('success');
      setMessage('پرداخت با موفقیت انجام شد. حساب شما به زودی ارتقا می‌یابد.');
    } else {
      setStatus('failed');
      setMessage('پرداخت ناموفق بود یا لغو شد.');
    }
  }, [searchParams]);

  return (
    <div className="flex min-h-screen items-center justify-center gradient-mesh p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md rounded-3xl bg-white p-8 text-center shadow-[0_10px_40px_rgba(0,0,0,0.08)]"
      >
        {status === 'loading' && (
          <div className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-primary-200 border-t-primary-600" />
        )}
        {status === 'success' && (
          <CheckCircle2 className="mx-auto h-16 w-16 text-emerald-500" strokeWidth={1.5} />
        )}
        {status === 'failed' && (
          <XCircle className="mx-auto h-16 w-16 text-red-500" strokeWidth={1.5} />
        )}

        <h1 className="mt-6 text-xl font-extrabold text-gray-800">
          {status === 'success' ? 'پرداخت موفق' : status === 'failed' ? 'پرداخت ناموفق' : 'در حال پردازش'}
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-gray-500">{message}</p>

        <Link
          to="/"
          className="mt-8 inline-flex items-center gap-2 rounded-2xl bg-primary-600 px-6 py-3 text-sm font-bold text-white shadow-md transition-colors hover:bg-primary-700"
        >
          بازگشت به خانه
          <ArrowLeft className="h-4 w-4" strokeWidth={2} />
        </Link>
      </motion.div>
    </div>
  );
}