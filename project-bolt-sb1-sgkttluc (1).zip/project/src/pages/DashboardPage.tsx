import { useEffect, useState, useCallback } from 'react';
import { useNavigate, Link, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  LayoutDashboard,
  User,
  BarChart3,
  Sparkles,
  LogOut,
  Home,
  ExternalLink,
  ShieldCheck,
  Users,
  Boxes,
  Copy,
  Check,
  CreditCard,
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { getMyProfile, checkIfAdmin } from '@/lib/profiles';
import { EditCardTab } from '@/components/EditCardTab';
import { ContactsTab } from '@/components/ContactsTab';
import { AnalyticsTab } from '@/components/AnalyticsTab';
import { AIBuilderTab } from '@/components/AIBuilderTab';
import { MyCardsTab } from '@/components/MyCardsTab';
import type { ProfileWithRelations } from '@/types';

type TabKey = 'edit' | 'cards' | 'contacts' | 'analytics' | 'ai';

export function DashboardPage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { user, loading: authLoading, signOut } = useAuth();
  const [profile, setProfile] = useState<ProfileWithRelations | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [copied3D, setCopied3D] = useState(false);

  const initialTab = (searchParams.get('tab') as TabKey) || 'edit';
  const [activeTab, setActiveTab] = useState<TabKey>(initialTab);

  const refetchProfile = useCallback(() => {
    if (!user) return;
    getMyProfile().then(setProfile).catch(() => {});
  }, [user]);

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      navigate('/auth', { replace: true });
      return;
    }
    Promise.all([
      getMyProfile().then(setProfile),
      checkIfAdmin().then(setIsAdmin),
    ])
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [user, authLoading, navigate]);

  useEffect(() => {
    setSearchParams({ tab: activeTab }, { replace: true });
  }, [activeTab, setSearchParams]);

  const handleSignOut = async () => {
    await signOut();
    navigate('/', { replace: true });
  };

  const card3DUrl = profile?.username
    ? `${window.location.origin}/card3d/${profile.username}`
    : '';

  const handleCopy3DLink = async () => {
    if (!card3DUrl) return;
    try {
      await navigator.clipboard.writeText(card3DUrl);
      setCopied3D(true);
      setTimeout(() => setCopied3D(false), 2000);
    } catch {
      const input = document.createElement('input');
      input.value = card3DUrl;
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      document.body.removeChild(input);
      setCopied3D(true);
      setTimeout(() => setCopied3D(false), 2000);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="flex min-h-screen items-center justify-center gradient-mesh">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary-200 border-t-primary-600" />
      </div>
    );
  }

  if (!user) return null;

  const tabs: { key: TabKey; label: string; icon: any }[] = [
    { key: 'edit', label: 'ویرایش کارت', icon: User },
    { key: 'cards', label: 'کارت‌های من', icon: CreditCard },
    { key: 'contacts', label: 'مخاطبین من', icon: Users },
    { key: 'analytics', label: 'آمار بازدید', icon: BarChart3 },
    { key: 'ai', label: 'صفحه‌ساز هوشمند', icon: Sparkles },
  ];

  return (
    <div className="min-h-screen gradient-mesh">
      {/* Header */}
      <header className="sticky top-0 z-40 glass border-b border-gray-100">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 shadow-md">
              <LayoutDashboard className="h-5 w-5 text-white" strokeWidth={1.5} />
            </div>
            <span className="hidden text-sm font-bold text-gray-800 sm:inline">داشبورد</span>
          </Link>

          <div className="flex items-center gap-2">
            {isAdmin && (
              <Link
                to="/admin"
                className="flex items-center gap-1.5 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 px-3.5 py-2 text-xs font-bold text-white shadow-md transition-transform hover:scale-105"
              >
                <ShieldCheck className="h-3.5 w-3.5" strokeWidth={2} />
                <span className="hidden sm:inline">پنل ادمین</span>
              </Link>
            )}
            {profile?.username && (
              <Link
                to={`/${profile.username}`}
                className="hidden items-center gap-1.5 rounded-xl bg-white px-3.5 py-2 text-xs font-medium text-gray-700 shadow-sm transition-colors hover:bg-gray-50 sm:flex"
              >
                <ExternalLink className="h-3.5 w-3.5" strokeWidth={1.5} />
                مشاهده کارت من
              </Link>
            )}
            <Link
              to="/"
              className="flex items-center gap-1.5 rounded-xl bg-white px-3.5 py-2 text-xs font-medium text-gray-700 shadow-sm transition-colors hover:bg-gray-50"
            >
              <Home className="h-3.5 w-3.5" strokeWidth={1.5} />
              <span className="hidden sm:inline">صفحه اصلی</span>
            </Link>
            <button
              onClick={handleSignOut}
              className="flex items-center gap-1.5 rounded-xl bg-red-50 px-3.5 py-2 text-xs font-medium text-red-600 transition-colors hover:bg-red-100"
            >
              <LogOut className="h-3.5 w-3.5" strokeWidth={1.5} />
              <span className="hidden sm:inline">خروج</span>
            </button>
          </div>
        </div>
      </header>

      {/* 3D Card Link Banner */}
      {profile?.username && (
        <div className="mx-auto max-w-5xl px-4 pt-6 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="overflow-hidden rounded-2xl bg-gradient-to-l from-primary-600 via-primary-700 to-accent-700 p-5 shadow-[0_8px_30px_rgba(20,184,166,0.25)] sm:p-6"
          >
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/15 backdrop-blur-sm">
                  <Boxes className="h-6 w-6 text-white" strokeWidth={1.5} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-extrabold text-white">کارت ویزیت ۳بعدی</h3>
                    <span className="rounded-full bg-white/20 px-2 py-0.5 text-[9px] font-bold text-white backdrop-blur-sm">
                      جدید
                    </span>
                  </div>
                  <p className="mt-1 text-[11px] leading-relaxed text-white/80">
                    کارت ویزیت شما را در حالت ۳بعدی با قابلیت چرخش ۳۶۰ درجه ببینید و به اشتراک بگذارید.
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleCopy3DLink}
                  className="flex items-center gap-1.5 rounded-xl bg-white/15 px-4 py-2.5 text-xs font-bold text-white backdrop-blur-sm transition-colors hover:bg-white/25"
                >
                  {copied3D ? (
                    <>
                      <Check className="h-3.5 w-3.5" strokeWidth={2} />
                      کپی شد
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" strokeWidth={2} />
                      کپی لینک
                    </>
                  )}
                </button>
                <Link
                  to={`/card3d/${profile.username}`}
                  className="flex items-center gap-1.5 rounded-xl bg-white px-4 py-2.5 text-xs font-bold text-primary-700 shadow-md transition-transform hover:scale-105"
                >
                  <Boxes className="h-3.5 w-3.5" strokeWidth={2} />
                  مشاهده کارت ۳بعدی
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Tabs */}
      <div className="mx-auto max-w-5xl px-4 pt-6 sm:px-6">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <motion.button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.97 }}
                className={`flex shrink-0 items-center gap-2 rounded-2xl px-4 py-3 text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-primary-600 text-white shadow-md'
                    : 'bg-white text-gray-600 shadow-sm hover:bg-gray-50'
                }`}
              >
                <Icon className="h-4 w-4" strokeWidth={1.5} />
                {tab.label}
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6 sm:py-8">
        {activeTab === 'edit' && profile && (
          <EditCardTab profile={profile} onProfileUpdate={refetchProfile} />
        )}
        {activeTab === 'cards' && <MyCardsTab />}
        {activeTab === 'contacts' && profile && <ContactsTab profile={profile} />}
        {activeTab === 'analytics' && profile && (
          <AnalyticsTab profileId={profile.id} isPremium={profile.is_premium} />
        )}
        {activeTab === 'ai' && profile && (
          <AIBuilderTab profile={profile} onProfileUpdate={refetchProfile} />
        )}
        {!profile && activeTab !== 'cards' && (
          <div className="rounded-2xl bg-white p-8 text-center shadow-sm">
            <p className="text-sm text-gray-500">پروفایلی یافت نشد.</p>
          </div>
        )}
      </main>
    </div>
  );
}