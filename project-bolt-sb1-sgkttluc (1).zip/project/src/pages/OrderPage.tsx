import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CreditCard, ArrowLeft, Check, Sparkles, Bell } from 'lucide-react';
import { supabase } from '@/lib/supabase';

export function OrderPage() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    full_name: '',
    phone: '',
    email: '',
    quantity: 1,
    notes: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const { error: insertError } = await supabase.from('orders').insert({
        full_name: formData.full_name,
        phone: formData.phone,
        email: formData.email || null,
        card_type: 'hybrid_nfc',
        quantity: formData.quantity,
        notes: formData.notes || null,
        status: 'pending',
      });

      if (insertError) throw insertError;
      setSubmitted(true);
    } catch (err: any) {
      console.error('[Order] Failed:', err);
      setError('خطا در ثبت سفارش. لطفاً دوباره تلاش کنید.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen gradient-mesh">
      <nav className="mx-auto flex max-w-5xl items-center justify-between px-4 py-5 sm:px-6">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 shadow-md">
            <Sparkles className="h-5 w-5 text-white" strokeWidth={1.5} />
          </div>
          <span className="text-lg font-extrabold text-gray-800">کارتین</span>
        </Link>
        <Link
          to="/"
          className="flex items-center gap-1.5 rounded-xl px-4 py-2 text-sm font-medium text-gray-600 transition-colors hover:bg-white hover:text-primary-600"
        >
          <ArrowLeft className="h-4 w-4" strokeWidth={1.5} />
          بازگشت
        </Link>
      </nav>

      <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6 sm:py-16">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 text-center"
        >
          <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-slate-800 to-primary-800 shadow-lg">
            <CreditCard className="h-8 w-8 text-primary-300" strokeWidth={1.5} />
          </div>
          <h1 className="text-3xl font-extrabold text-gray-800 sm:text-4xl">
            کارت ویزیت هیبریدی
          </h1>
          <p className="mx-auto mt-4 max-w-lg text-sm leading-relaxed text-gray-500">
            ترکیبی از یک کارت فیزیکی زیبا با تراشه NFC و یک کارت ویزیت دیجیتال هوشمند.
            با نزدیک کردن گوشی، صفحه دیجیتال شما در مرورگر باز می‌شود.
          </p>
          <div className="mt-4 inline-flex items-center gap-2 rounded-full bg-amber-50 px-4 py-1.5 text-xs font-medium text-amber-700 ring-1 ring-amber-100">
            <Bell className="h-3.5 w-3.5" strokeWidth={1.5} />
            به زودی — قیمت‌گذاری در حال نهایی شدن است
          </div>
        </motion.div>

        {/* Form / Success */}
        {submitted ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="rounded-3xl bg-white p-8 text-center shadow-[0_10px_40px_rgba(0,0,0,0.08)] sm:p-12"
          >
            <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50">
              <Check className="h-8 w-8 text-emerald-600" strokeWidth={2} />
            </div>
            <h2 className="text-xl font-extrabold text-gray-800">درخواست شما ثبت شد!</h2>
            <p className="mx-auto mt-3 max-w-sm text-sm leading-relaxed text-gray-500">
              کارشناسان ما به زودی با شما تماس می‌گیرند و قیمت و جزئیات نهایی را اعلام می‌کنند.
            </p>
            <Link
              to="/"
              className="mt-8 inline-flex items-center gap-2 rounded-2xl bg-primary-600 px-6 py-3 text-sm font-bold text-white shadow-md transition-colors hover:bg-primary-700"
            >
              بازگشت به خانه
              <ArrowLeft className="h-4 w-4" strokeWidth={2} />
            </Link>
          </motion.div>
        ) : (
          <motion.form
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            onSubmit={handleSubmit}
            className="space-y-5 rounded-3xl bg-white p-6 shadow-[0_10px_40px_rgba(0,0,0,0.08)] sm:p-8"
          >
            <div>
              <label className="mb-1.5 block text-xs font-medium text-gray-600">
                نام و نام خانوادگی *
              </label>
              <input
                type="text"
                required
                value={formData.full_name}
                onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                className="w-full rounded-xl border border-gray-100 bg-gray-50 px-4 py-3 text-sm text-gray-800 transition-all focus:border-primary-300 focus:bg-white focus:shadow-[0_0_0_3px_rgba(20,184,166,0.1)]"
                placeholder="نام شما"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-medium text-gray-600">شماره تماس *</label>
              <input
                type="tel"
                required
                dir="ltr"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full rounded-xl border border-gray-100 bg-gray-50 px-4 py-3 text-left text-sm text-gray-800 transition-all focus:border-primary-300 focus:bg-white focus:shadow-[0_0_0_3px_rgba(20,184,166,0.1)]"
                placeholder="+98 912 000 0000"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-medium text-gray-600">
                ایمیل (اختیاری)
              </label>
              <input
                type="email"
                dir="ltr"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full rounded-xl border border-gray-100 bg-gray-50 px-4 py-3 text-left text-sm text-gray-800 transition-all focus:border-primary-300 focus:bg-white focus:shadow-[0_0_0_3px_rgba(20,184,166,0.1)]"
                placeholder="you@example.com"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-medium text-gray-600">تعداد *</label>
              <input
                type="number"
                required
                min={1}
                max={1000}
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) || 1 })}
                className="w-full rounded-xl border border-gray-100 bg-gray-50 px-4 py-3 text-sm text-gray-800 transition-all focus:border-primary-300 focus:bg-white focus:shadow-[0_0_0_3px_rgba(20,184,166,0.1)]"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-medium text-gray-600">
                توضیحات (اختیاری)
              </label>
              <textarea
                rows={3}
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full resize-none rounded-xl border border-gray-100 bg-gray-50 px-4 py-3 text-sm text-gray-800 transition-all focus:border-primary-300 focus:bg-white focus:shadow-[0_0_0_3px_rgba(20,184,166,0.1)]"
                placeholder="درخواست طراحی خاص، لوگو، رنگ و..."
              />
            </div>

            {error && (
              <div className="rounded-xl bg-red-50 px-4 py-3 text-xs text-red-600">{error}</div>
            )}

            <motion.button
              type="submit"
              disabled={loading}
              whileHover={{ scale: 1.02, y: -2 }}
              whileTap={{ scale: 0.98 }}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-primary-600 to-primary-500 py-4 text-sm font-bold text-white shadow-[0_8px_24px_rgba(20,184,166,0.25)] transition-all hover:shadow-[0_12px_30px_rgba(20,184,166,0.35)] disabled:opacity-50"
            >
              {loading ? (
                <div className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white" />
              ) : (
                <>
                  ثبت درخواست
                  <ArrowLeft className="h-4 w-4" strokeWidth={2} />
                </>
              )}
            </motion.button>

            <p className="text-center text-[11px] leading-relaxed text-gray-400">
              پس از ثبت، کارشناسان ما برای اعلام قیمت و جزئیات با شما تماس می‌گیرند.
            </p>
          </motion.form>
        )}
      </div>
    </div>
  );
}