import { useEffect, useState, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion, AnimatePresence } from 'framer-motion';
import {
  QrCode,
  Contact,
  Share2,
  ArrowLeft,
  AlertCircle,
  Mail,
  Phone,
  Globe,
  LayoutDashboard,
  TreePine,
  Eye,
  Download,
  Sparkles,
  Check,
  X,
  Boxes,
  Maximize2,
} from 'lucide-react';
import { getProfileByUsername } from '@/lib/profiles';
import { downloadVCard } from '@/lib/vcard';
import {
  trackPageView,
  incrementVCardDownload,
  getAnalytics,
  trackContactSave,
} from '@/lib/analytics';
import { useAuth } from '@/hooks/useAuth';
import { QRModal } from '@/components/QRModal';
import { ContactButton, DirectContactButton } from '@/components/ContactButton';
import { Card3D } from '@/components/Card3D';
import type { ProfileWithRelations, SocialLink } from '@/types';

export function PublicCardPage() {
  const { username } = useParams<{ username: string }>();
  const { user } = useAuth();
  const [profile, setProfile] = useState<ProfileWithRelations | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [qrOpen, setQrOpen] = useState(false);
  const [viewCount, setViewCount] = useState(0);
  const [downloadCount, setDownloadCount] = useState(0);
  const [showSignupPopup, setShowSignupPopup] = useState(false);

  const fetchedUsernameRef = useRef<string | null>(null);
  const trackedRef = useRef<boolean>(false);

  const cardUrl = `${window.location.origin}/${username ?? ''}`;

  useEffect(() => {
    if (!username) return;
    if (fetchedUsernameRef.current === username && profile) return;

    fetchedUsernameRef.current = username;
    setLoading(true);
    setNotFound(false);

    getProfileByUsername(username)
      .then(async (p) => {
        if (!p) {
          setNotFound(true);
        } else {
          setProfile(p);
          setDownloadCount(p.vcard_downloads ?? 0);

          const isOwner = user?.id === p.id;

          if (!isOwner && !trackedRef.current) {
            trackedRef.current = true;
            trackPageView(p.id);
          }

          if (isOwner) {
            try {
              const analytics = await getAnalytics(p.id);
              setViewCount(analytics.totalViews);
              setDownloadCount(analytics.totalDownloads);
            } catch {
              // ignore
            }
          }
        }
      })
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false));
  }, [username, user, profile]);

  const handleSaveContact = async () => {
    if (!profile) return;
    try {
      await downloadVCard(profile, profile.social_links, cardUrl);
      incrementVCardDownload(profile.id);
      setDownloadCount((c) => c + 1);

      await trackContactSave(profile.id, {
        userId: user?.id,
        fullName: user?.user_metadata?.full_name ?? undefined,
        phone: user?.user_metadata?.phone ?? undefined,
      });

      if (!user) {
        setTimeout(() => setShowSignupPopup(true), 600);
      }
    } catch (err) {
      console.error('[vCard] Failed to download:', err);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      await navigator.share({
        title: profile?.full_name ?? 'کارت ویزیت',
        text: `کارت ویزیت ${profile?.full_name}`,
        url: cardUrl,
      });
    } else {
      navigator.clipboard.writeText(cardUrl);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center gradient-mesh">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary-200 border-t-primary-600" />
      </div>
    );
  }

  if (notFound) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 gradient-mesh p-6 text-center">
        <AlertCircle className="h-16 w-16 text-primary-300" strokeWidth={1.5} />
        <h1 className="text-2xl font-bold text-gray-700">کارت پیدا نشد</h1>
        <p className="text-gray-500">کاربری با این نام وجود ندارد.</p>
        <Link
          to="/"
          className="mt-4 flex items-center gap-2 rounded-xl bg-primary-600 px-6 py-3 text-white shadow-lg transition-colors hover:bg-primary-700"
        >
          <ArrowLeft className="h-5 w-5" strokeWidth={1.5} />
          بازگشت به صفحه اصلی
        </Link>
      </div>
    );
  }

  if (!profile) return null;

  const isOwnCard = user?.id === profile.id;
  const isCorporate = profile.template_type === 'corporate';

  const pageTitle = `${profile.full_name}${profile.headline ? ` - ${profile.headline}` : ''} | کارت ویزیت دیجیتال`;
  const pageDescription = profile.bio || `کارت ویزیت دیجیتال ${profile.full_name}`;
  const canonicalUrl = window.location.href;

  const paperSavedGrams = downloadCount * 2;
  const co2SavedGrams = downloadCount * 5;

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': isCorporate ? 'Organization' : 'Person',
    name: profile.full_name,
    jobTitle: profile.headline || undefined,
    description: profile.bio || undefined,
    image: profile.avatar_url || undefined,
    url: canonicalUrl,
    email: profile.email || undefined,
    telephone: profile.phone || undefined,
    ...(profile.website
      ? { sameAs: [profile.website, ...profile.social_links.map((l: SocialLink) => l.url)] }
      : {}),
  };

  return (
    <div className="min-h-screen gradient-mesh">
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        <link rel="canonical" href={canonicalUrl} />
        <meta property="og:title" content={profile.full_name} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:image" content={profile.avatar_url} />
        <meta property="og:type" content="profile" />
        <meta property="og:url" content={canonicalUrl} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={profile.full_name} />
        <meta name="twitter:description" content={pageDescription} />
        <meta name="twitter:image" content={profile.avatar_url} />
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
      </Helmet>

      {/* Owner toolbar */}
      {isOwnCard && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed top-4 right-4 z-50 flex gap-2"
        >
          <Link
            to="/dashboard"
            className="flex items-center gap-2 rounded-2xl bg-white px-5 py-3 text-sm font-bold text-primary-700 shadow-[0_8px_24px_rgba(0,0,0,0.12)] transition-transform hover:scale-105"
          >
            <LayoutDashboard className="h-4 w-4" strokeWidth={2} />
            داشبورد
          </Link>
          <Link
            to="/"
            className="flex items-center gap-2 rounded-2xl bg-white px-5 py-3 text-sm font-bold text-gray-700 shadow-[0_8px_24px_rgba(0,0,0,0.12)] transition-transform hover:scale-105"
          >
            صفحه اصلی
          </Link>
        </motion.div>
      )}

      {/* Visitor toolbar */}
      {!isOwnCard && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="fixed top-4 right-4 z-50"
        >
          <Link
            to={user ? '/dashboard' : '/auth?mode=signup'}
            className="flex items-center gap-2 rounded-2xl bg-gradient-to-l from-primary-600 to-accent-600 px-5 py-3 text-sm font-bold text-white shadow-[0_8px_24px_rgba(20,184,166,0.3)] transition-transform hover:scale-105"
          >
            <Sparkles className="h-4 w-4" strokeWidth={2} />
            {user ? 'داشبورد من' : 'ساخت کارت رایگان'}
          </Link>
        </motion.div>
      )}

      {/* Hero banner */}
      <div
        className={`relative z-0 h-52 w-full sm:h-64 ${
          profile.cover_image_url
            ? ''
            : isCorporate
              ? 'bg-gradient-to-l from-slate-700 via-slate-800 to-primary-800'
              : 'bg-gradient-to-l from-primary-500 via-primary-600 to-accent-600'
        }`}
      >
        {profile.cover_image_url ? (
          <>
            <img
              src={profile.cover_image_url}
              alt="cover"
              className="h-full w-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/40 to-transparent" />
          </>
        ) : (
          <div
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage:
                'radial-gradient(circle at 30% 50%, white 1px, transparent 1px)',
              backgroundSize: '24px 24px',
            }}
          />
        )}
      </div>

      {/* Card content */}
      <div className="relative z-20 mx-auto -mt-16 w-full max-w-md px-4 pb-44 sm:max-w-2xl sm:pb-40">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          className="relative z-20 rounded-3xl bg-white p-6 shadow-[0_10px_40px_rgba(0,0,0,0.08)] sm:p-10"
        >
          {/* ====== کارت ۳بعدی در بالای صفحه ====== */}
          <div className="mb-8">
            <Card3D
              profile={profile}
              onSaveContact={handleSaveContact}
              onShowQR={() => setQrOpen(true)}
            />
            <div className="mt-4 text-center">
              <Link
                to={`/card3d/${username}`}
                className="inline-flex items-center gap-1.5 rounded-xl bg-primary-50 px-4 py-2 text-xs font-bold text-primary-700 transition-colors hover:bg-primary-100"
              >
                <Maximize2 className="h-3.5 w-3.5" strokeWidth={2} />
                مشاهده کارت ۳بعدی به صورت تمام صفحه
              </Link>
            </div>
          </div>

          {/* Divider */}
          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-100" />
            </div>
            <div className="relative flex justify-center">
              <span className="bg-white px-3 text-[10px] font-bold text-gray-400">
                اطلاعات تکمیلی
              </span>
            </div>
          </div>

          {/* Bio */}
          {profile.bio && (
            <p className="text-center text-sm leading-relaxed text-gray-500">{profile.bio}</p>
          )}

          {/* Audio */}
          {profile.audio_intro_url && (
            <div className="mt-5">
              <audio
                controls
                src={profile.audio_intro_url}
                className="w-full"
                style={{ accentColor: '#14b8a6' }}
              />
            </div>
          )}

          {/* Skills */}
          {profile.skills.length > 0 && (
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              {profile.skills.map((skill) => (
                <span
                  key={skill.id}
                  className="rounded-full bg-primary-50 px-3.5 py-1.5 text-xs font-medium text-primary-700"
                >
                  {skill.skill_name}
                </span>
              ))}
            </div>
          )}

          {/* Contact grid */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            {profile.email && (
              <DirectContactButton icon={Mail} label="ایمیل" href={`mailto:${profile.email}`} />
            )}
            {profile.phone && (
              <DirectContactButton icon={Phone} label="تلفن" href={`tel:${profile.phone}`} />
            )}
            {profile.website && (
              <DirectContactButton
                icon={Globe}
                label="وب‌سایت"
                href={
                  profile.website.startsWith('http')
                    ? profile.website
                    : `https://${profile.website}`
                }
              />
            )}
            {profile.social_links.map((link) => (
              <ContactButton key={link.id} platform={link.platform} url={link.url} />
            ))}
          </div>

          {/* Video */}
          {profile.video_url && (
            <div className="mt-6">
              <video
                controls
                src={profile.video_url}
                className="w-full rounded-2xl"
                style={{ maxHeight: '240px' }}
              />
            </div>
          )}

          {/* Action buttons */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <motion.button
              onClick={handleSaveContact}
              whileHover={{ y: -2, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex items-center gap-2 rounded-xl bg-primary-600 px-5 py-2.5 text-sm font-medium text-white shadow-md transition-colors hover:bg-primary-700"
            >
              <Contact className="h-4 w-4" strokeWidth={1.5} />
              ذخیره در مخاطبین
            </motion.button>
            <motion.div whileHover={{ y: -2, scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Link
                to={`/card3d/${username}`}
                className="flex items-center gap-2 rounded-xl bg-gradient-to-l from-accent-600 to-primary-600 px-5 py-2.5 text-sm font-medium text-white shadow-md transition-opacity hover:opacity-90"
              >
                <Boxes className="h-4 w-4" strokeWidth={1.5} />
                کارت ۳بعدی
              </Link>
            </motion.div>
            <motion.button
              onClick={() => setQrOpen(true)}
              whileHover={{ y: -2, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex items-center gap-2 rounded-xl bg-white px-5 py-2.5 text-sm font-medium text-gray-700 shadow-sm transition-shadow hover:shadow-md"
            >
              <QrCode className="h-4 w-4" strokeWidth={1.5} />
              کد QR
            </motion.button>
            <motion.button
              onClick={handleShare}
              whileHover={{ y: -2, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex items-center gap-2 rounded-xl bg-white px-5 py-2.5 text-sm font-medium text-gray-700 shadow-sm transition-shadow hover:shadow-md"
            >
              <Share2 className="h-4 w-4" strokeWidth={1.5} />
              اشتراک‌گذاری
            </motion.button>
          </div>

          {/* Owner-only: Mini Analytics + Gamification */}
          {isOwnCard && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
              className="mt-8 space-y-3"
            >
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-2xl bg-gradient-to-br from-primary-50 to-primary-100/50 p-4 text-center">
                  <Eye className="mx-auto h-5 w-5 text-primary-600" strokeWidth={1.5} />
                  <p className="mt-2 text-2xl font-extrabold text-primary-700">{viewCount}</p>
                  <p className="text-[11px] font-medium text-primary-600/80">بازدید کل</p>
                </div>
                <div className="rounded-2xl bg-gradient-to-br from-emerald-50 to-emerald-100/50 p-4 text-center">
                  <Download className="mx-auto h-5 w-5 text-emerald-600" strokeWidth={1.5} />
                  <p className="mt-2 text-2xl font-extrabold text-emerald-700">{downloadCount}</p>
                  <p className="text-[11px] font-medium text-emerald-600/80">ذخیره در مخاطبین</p>
                </div>
              </div>

              <div className="rounded-2xl bg-gradient-to-l from-emerald-500 to-teal-500 p-4 text-white shadow-[0_8px_24px_rgba(16,185,129,0.2)]">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/20 backdrop-blur-sm">
                    <TreePine className="h-5 w-5" strokeWidth={1.5} />
                  </div>
                  <div className="flex-1 text-right">
                    <p className="text-xs font-bold">شما یک قهرمان طبیعت هستید 🌱</p>
                    <p className="mt-0.5 text-[10px] opacity-90">
                      با {downloadCount} ذخیره، از چاپ {downloadCount} کارت کاغذی جلوگیری کردید.
                    </p>
                  </div>
                </div>
                <div className="mt-3 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 rounded-lg bg-white/15 px-3 py-1.5 backdrop-blur-sm">
                    <span className="text-sm font-extrabold">{paperSavedGrams}</span>
                    <span className="text-[10px] opacity-90">گرم کاغذ</span>
                  </div>
                  <div className="flex items-center gap-1.5 rounded-lg bg-white/15 px-3 py-1.5 backdrop-blur-sm">
                    <span className="text-sm font-extrabold">{co2SavedGrams}</span>
                    <span className="text-[10px] opacity-90">گرم CO₂</span>
                  </div>
                  <Link
                    to="/dashboard?tab=analytics"
                    className="flex items-center gap-1 rounded-lg bg-white/20 px-3 py-1.5 text-[10px] font-bold backdrop-blur-sm transition-colors hover:bg-white/30"
                  >
                    تحلیل کامل
                    <ArrowLeft className="h-3 w-3" strokeWidth={2} />
                  </Link>
                </div>
              </div>
            </motion.div>
          )}

          {/* Visitor CTA */}
          {!user && !isOwnCard && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="mt-8 overflow-hidden rounded-2xl bg-gradient-to-l from-primary-600 to-accent-600 p-5 text-center text-white shadow-lg"
            >
              <Sparkles className="mx-auto h-6 w-6" strokeWidth={1.5} />
              <p className="mt-3 text-sm font-bold">همین کارت ویزیت را برای خودت بساز!</p>
              <p className="mt-1 text-[11px] leading-relaxed opacity-90">
                کاملاً رایگان، در کمتر از ۲ دقیقه. لینک اختصاصی و QR Code خودت را داشته باش.
              </p>
              <Link
                to="/auth?mode=signup"
                className="mt-4 inline-flex items-center gap-2 rounded-xl bg-white px-5 py-2.5 text-xs font-bold text-primary-700 shadow-md transition-transform hover:scale-105"
              >
                ساخت کارت رایگان
                <ArrowLeft className="h-3.5 w-3.5" strokeWidth={2} />
              </Link>
            </motion.div>
          )}
        </motion.div>
      </div>

      {/* Sticky bottom bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40">
        <div className="glass mx-auto max-w-md border-t border-gray-100 px-4 py-3 sm:max-w-2xl">
          {!user && !isOwnCard ? (
            <div className="flex items-center gap-2">
              <motion.button
                onClick={handleSaveContact}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-primary-600 py-3 text-sm font-medium text-white shadow-md transition-colors hover:bg-primary-700"
              >
                <Contact className="h-4 w-4" strokeWidth={1.5} />
                ذخیره در مخاطبین
              </motion.button>
              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} className="flex-1">
                <Link
                  to="/auth?mode=signup"
                  className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 py-3 text-sm font-bold text-white shadow-md transition-transform"
                >
                  <Sparkles className="h-4 w-4" strokeWidth={2} />
                  ساخت کارت رایگان
                </Link>
              </motion.div>
            </div>
          ) : (
            <div className="flex items-center justify-between gap-3">
              <motion.button
                onClick={handleSaveContact}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-primary-600 py-3 text-sm font-medium text-white shadow-md transition-colors hover:bg-primary-700"
              >
                <Contact className="h-4 w-4" strokeWidth={1.5} />
                ذخیره در مخاطبین
              </motion.button>
              <motion.button
                onClick={() => setQrOpen(true)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center justify-center gap-2 rounded-xl bg-white px-4 py-3 text-sm font-medium text-gray-700 shadow-sm transition-shadow hover:shadow-md"
              >
                <QrCode className="h-5 w-5" strokeWidth={1.5} />
              </motion.button>
            </div>
          )}
        </div>
      </div>

      <QRModal open={qrOpen} onClose={() => setQrOpen(false)} url={cardUrl} />

      {/* Signup Popup */}
      <AnimatePresence>
        {showSignupPopup && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            onClick={() => setShowSignupPopup(false)}
          >
            <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              transition={{ type: 'spring', stiffness: 300, damping: 25 }}
              onClick={(e) => e.stopPropagation()}
              className="relative z-10 w-full max-w-sm overflow-hidden rounded-3xl bg-white shadow-[0_20px_60px_rgba(0,0,0,0.15)]"
            >
              <button
                onClick={() => setShowSignupPopup(false)}
                className="absolute top-4 left-4 z-20 rounded-full bg-white/20 p-2 text-white backdrop-blur-sm transition-colors hover:bg-white/30"
                aria-label="بستن"
              >
                <X className="h-4 w-4" strokeWidth={2} />
              </button>

              <div className="bg-gradient-to-l from-primary-600 to-accent-600 p-6 text-center text-white">
                <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-sm">
                  <Sparkles className="h-7 w-7" strokeWidth={1.5} />
                </div>
                <h3 className="text-lg font-extrabold">کارت ذخیره شد! 🎉</h3>
                <p className="mt-1 text-xs opacity-90">
                  الان نوبت شماست که کارت ویزیت خودتان را بسازید
                </p>
              </div>

              <div className="p-6">
                <div className="space-y-3">
                  {[
                    'کاملاً رایگان و بدون محدودیت',
                    'لینک اختصاصی + QR Code',
                    'آماده در کمتر از ۲ دقیقه',
                    'اشتراک‌گذاری با یک کلیک',
                  ].map((item, i) => (
                    <motion.div
                      key={item}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.15 + i * 0.08 }}
                      className="flex items-center gap-2.5 text-sm text-gray-600"
                    >
                      <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-100">
                        <Check className="h-3 w-3 text-emerald-600" strokeWidth={3} />
                      </div>
                      {item}
                    </motion.div>
                  ))}
                </div>

                <Link
                  to="/auth?mode=signup"
                  className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-primary-600 to-accent-600 py-3.5 text-sm font-bold text-white shadow-md transition-transform hover:scale-[1.02]"
                >
                  ساخت کارت رایگان
                  <ArrowLeft className="h-4 w-4" strokeWidth={2} />
                </Link>

                <button
                  onClick={() => setShowSignupPopup(false)}
                  className="mt-3 w-full text-center text-xs text-gray-400 transition-colors hover:text-gray-600"
                >
                  بعداً
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}