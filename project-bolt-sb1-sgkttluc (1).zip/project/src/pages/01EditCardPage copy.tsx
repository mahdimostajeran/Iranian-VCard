import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight,
  Save,
  Check,
  User,
  Briefcase,
  Building2,
  Mail,
  Phone,
  Globe,
  ImageIcon,
  Image as ImageIcon2,
  Music,
  Video,
  Trash2,
  Crown,
  Lock,
  Globe2,
  Tag,
  Plus,
  X,
  Share2,
  Palette,
  AlertCircle,
} from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuth } from '@/hooks/useAuth';
import {
  getCardByUsername,
  updateCard,
  checkCardUsernameAvailable,
  updateCardSkills,
  updateCardSocialLinks,
} from '@/lib/cards';
import {
  uploadAvatar,
  uploadCoverImage,
  uploadAudio,
  uploadVideo,
  deleteFile,
} from '@/lib/storage';
import type {
  CardWithRelations,
  TemplateType,
  Platform,
  CardTheme,
  CustomField,
} from '@/types';
import { CustomFieldsTab } from '@/components/CustomFieldsTab';

const schema = z.object({
  username: z.string().min(3, 'نام کاربری حداقل ۳ کاراکتر'),
  full_name: z.string().min(1, 'نام الزامی است'),
  full_name_en: z.string().optional(),
  headline: z.string().optional(),
  company: z.string().optional(),
  bio: z.string().max(300, 'بیوگرافی حداکثر ۳۰۰ کاراکتر').optional(),
  email: z.string().email('ایمیل نامعتبر').optional().or(z.literal('')),
  phone: z.string().optional(),
  website: z.string().optional(),
  template_type: z.enum(['personal', 'corporate']),
  is_private: z.boolean(),
});

type FormData = z.infer<typeof schema>;

const THEMES: Record<CardTheme, { label: string; front: string }> = {
  teal: { label: 'فیروزه‌ای', front: 'from-primary-600 via-primary-700 to-accent-700' },
  midnight: { label: 'نیمه‌شب', front: 'from-slate-900 via-slate-800 to-amber-900' },
  corporate: { label: 'شرکتی', front: 'from-slate-800 via-slate-900 to-primary-900' },
  minimal: { label: 'مینیمال', front: 'from-white via-gray-50 to-gray-100' },
  gradient: { label: 'گرادیان', front: 'from-purple-600 via-pink-600 to-rose-500' },
  glass: { label: 'شیشه‌ای', front: 'from-slate-700 via-slate-900 to-black' },
};

const FREE_SOCIAL_PLATFORMS: { value: Platform; label: string }[] = [
  { value: 'linkedin', label: 'لینکدین' },
  { value: 'instagram', label: 'اینستاگرام' },
  { value: 'telegram', label: 'تلگرام' },
  { value: 'whatsapp', label: 'واتساپ' },
];

const PREMIUM_SOCIAL_PLATFORMS: { value: Platform; label: string }[] = [
  { value: 'twitter', label: 'توییتر (X)' },
  { value: 'youtube', label: 'یوتیوب' },
  { value: 'facebook', label: 'فیسبوک' },
  { value: 'tiktok', label: 'تیک‌تاک' },
  { value: 'github', label: 'گیت‌هاب' },
];

const IRANIAN_SOCIAL_PLATFORMS: { value: Platform; label: string }[] = [
  { value: 'eitaa', label: 'ایتا' },
  { value: 'bale', label: 'بله' },
  { value: 'rubika', label: 'روبیکا' },
  { value: 'soroush', label: 'سروش' },
  { value: 'igap', label: 'آی‌گپ' },
];

interface CustomLink {
  label: string;
  url: string;
}

export function EditCardPage() {
  const { cardId } = useParams<{ cardId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [card, setCard] = useState<CardWithRelations | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [usernameError, setUsernameError] = useState('');
  const [mediaError, setMediaError] = useState('');
  const [uploading, setUploading] = useState<string | null>(null);

  const [avatarUrl, setAvatarUrl] = useState('');
  const [coverUrl, setCoverUrl] = useState('');
  const [audioUrl, setAudioUrl] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [selectedTheme, setSelectedTheme] = useState<CardTheme>('teal');
  const [skills, setSkills] = useState<string[]>([]);
  const [skillInput, setSkillInput] = useState('');
  const [keywords, setKeywords] = useState<string[]>([]);
  const [keywordInput, setKeywordInput] = useState('');
  const [socialLinks, setSocialLinks] = useState<{ platform: Platform; url: string }[]>([]);
  const [customLinks, setCustomLinks] = useState<CustomLink[]>([]);
  const [customFields, setCustomFields] = useState<CustomField[]>([]);

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    watch,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      username: '',
      full_name: '',
      full_name_en: '',
      headline: '',
      company: '',
      bio: '',
      email: '',
      phone: '',
      website: '',
      template_type: 'personal',
      is_private: false,
    },
  });

  const templateType = watch('template_type');
  const isPrivate = watch('is_private');

  useEffect(() => {
    if (!cardId) return;
    setLoading(true);
    (async () => {
      try {
        const c = await getCardByUsername(cardId, { allowPrivate: true });
        if (!c || c.user_id !== user?.id) {
          setNotFound(true);
          return;
        }
        setCard(c);
        setAvatarUrl(c.avatar_url || '');
        setCoverUrl(c.cover_image_url || '');
        setAudioUrl(c.audio_intro_url || '');
        setVideoUrl(c.video_url || '');
        setSelectedTheme((c.card_theme as CardTheme) || 'teal');
        setSkills((c.skills || []).map((s) => s.skill_name));
        setKeywords(c.keywords || []);
        setCustomFields(c.custom_fields || []);

        const known = [
          ...FREE_SOCIAL_PLATFORMS,
          ...PREMIUM_SOCIAL_PLATFORMS,
          ...IRANIAN_SOCIAL_PLATFORMS,
        ];
        setSocialLinks(
          (c.social_links || [])
            .filter((l) => known.some((k) => k.value === l.platform))
            .map((l) => ({ platform: l.platform as Platform, url: l.url }))
        );
        setCustomLinks(
          (c.social_links || [])
            .filter((l) => l.platform === 'custom')
            .map((l) => ({ label: l.custom_label || '', url: l.url }))
        );

        reset({
          username: c.username,
          full_name: c.full_name || '',
          full_name_en: c.full_name_en || '',
          headline: c.headline || '',
          company: c.company || '',
          bio: c.bio || '',
          email: c.email || '',
          phone: c.phone || '',
          website: c.website || '',
          template_type: (c.template_type as TemplateType) || 'personal',
          is_private: c.is_private,
        });
      } catch {
        setNotFound(true);
      } finally {
        setLoading(false);
      }
    })();
  }, [cardId, user, reset]);

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setUploading('avatar');
    setMediaError('');
    try {
      const url = await uploadAvatar(file, user.id);
      setAvatarUrl(url);
      await updateCard(card!.id, { avatar_url: url });
    } catch (err: any) {
      setMediaError(err.message || 'خطا در آپلود');
    } finally {
      setUploading(null);
    }
  };

  const handleRemoveAvatar = async () => {
    if (!user || !card) return;
    if (!confirm('حذف عکس پروفایل؟')) return;
    try {
      await deleteFile('avatars', user.id, 'avatar.jpg');
      setAvatarUrl('');
      await updateCard(card.id, { avatar_url: '' });
    } catch (err: any) {
      setMediaError(err.message || 'خطا در حذف');
    }
  };

  const handleCoverChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setUploading('cover');
    setMediaError('');
    try {
      const url = await uploadCoverImage(file, user.id);
      setCoverUrl(url);
      await updateCard(card!.id, { cover_image_url: url });
    } catch (err: any) {
      setMediaError(err.message || 'خطا در آپلود');
    } finally {
      setUploading(null);
    }
  };

  const handleRemoveCover = async () => {
    if (!user || !card) return;
    if (!confirm('حذف کاور؟')) return;
    try {
      await deleteFile('covers', user.id, 'cover.jpg');
      setCoverUrl('');
      await updateCard(card.id, { cover_image_url: '' });
    } catch (err: any) {
      setMediaError(err.message || 'خطا در حذف');
    }
  };

  const handleAudioChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setUploading('audio');
    setMediaError('');
    try {
      const url = await uploadAudio(file, user.id);
      setAudioUrl(url);
      await updateCard(card!.id, { audio_intro_url: url });
    } catch (err: any) {
      setMediaError(err.message || 'خطا در آپلود');
    } finally {
      setUploading(null);
    }
  };

  const handleVideoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setUploading('video');
    setMediaError('');
    try {
      const url = await uploadVideo(file, user.id);
      setVideoUrl(url);
      await updateCard(card!.id, { video_url: url });
    } catch (err: any) {
      setMediaError(err.message || 'خطا در آپلود');
    } finally {
      setUploading(null);
    }
  };

  const addSkill = () => {
    const s = skillInput.trim();
    if (s && !skills.includes(s)) {
      setSkills([...skills, s]);
      setSkillInput('');
    }
  };

  const addKeyword = () => {
    const k = keywordInput.trim();
    if (k && !keywords.includes(k)) {
      setKeywords([...keywords, k]);
      setKeywordInput('');
    }
  };

  const updateSocialUrl = (platform: Platform, url: string) => {
    setSocialLinks((prev) => {
      const existing = prev.find((l) => l.platform === platform);
      if (existing) {
        return prev.map((l) => (l.platform === platform ? { ...l, url } : l));
      }
      return [...prev, { platform, url }];
    });
  };

  const getSocialUrl = (platform: Platform) =>
    socialLinks.find((l) => l.platform === platform)?.url ?? '';

  const onSubmit = async (data: FormData) => {
    if (!user || !card) return;
    setSaving(true);
    setUsernameError('');
    try {
      const available = await checkCardUsernameAvailable(data.username, card.id);
      if (!available) {
        setUsernameError('این نام کاربری قبلاً گرفته شده است');
        setSaving(false);
        return;
      }

      await updateCard(card.id, {
        username: data.username,
        full_name: data.full_name,
        full_name_en: data.full_name_en || '',
        headline: data.headline ?? '',
        company: data.company ?? '',
        bio: data.bio ?? '',
        email: data.email ?? '',
        phone: data.phone ?? '',
        website: data.website ?? '',
        template_type: data.template_type,
        card_theme: selectedTheme,
        is_private: data.is_private,
        keywords,
        custom_fields: customFields,
      } as any);

      await updateCardSkills(card.id, skills);

      const allLinks = [
        ...socialLinks.filter((l) => l.url.trim()),
        ...customLinks
          .filter((l) => l.url.trim())
          .map((l) => ({ platform: 'custom' as Platform, url: l.url, custom_label: l.label })),
      ];
      await updateCardSocialLinks(card.id, allLinks);

      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center gradient-mesh">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary-200 border-t-primary-600" />
      </div>
    );
  }

  if (notFound || !card) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 gradient-mesh p-6 text-center">
        <AlertCircle className="h-16 w-16 text-primary-300" />
        <h1 className="text-2xl font-bold text-gray-700">کارت پیدا نشد</h1>
        <Link
          to="/dashboard?tab=cards"
          className="mt-4 flex items-center gap-2 rounded-xl bg-primary-600 px-6 py-3 text-white shadow-lg transition-colors hover:bg-primary-700"
        >
          <ArrowRight className="h-5 w-5" />
          بازگشت به کارت‌های من
        </Link>
      </div>
    );
  }

  const inputClass =
    'w-full rounded-xl border border-gray-100 bg-gray-50 px-4 py-2.5 text-sm text-gray-800 transition-all focus:border-primary-300 focus:bg-white focus:shadow-[0_0_0_3px_rgba(20,184,166,0.1)]';
  const cardClass = 'rounded-2xl bg-white p-6 shadow-[0_2px_12px_rgba(0,0,0,0.04)] sm:p-8';
  const sectionTitle = 'mb-5 flex items-center gap-2 text-sm font-semibold text-gray-700';
  const iconProps = { className: 'h-4 w-4 text-primary-600', strokeWidth: 1.5 } as const;

  return (
    <div className="min-h-screen gradient-mesh">
      {/* Header */}
      <header className="sticky top-0 z-40 glass border-b border-gray-100">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-4 py-3 sm:px-6">
          <Link
            to="/dashboard?tab=cards"
            className="flex items-center gap-2 rounded-xl bg-white px-3.5 py-2 text-xs font-medium text-gray-700 shadow-sm hover:bg-gray-50"
          >
            <ArrowRight className="h-3.5 w-3.5" />
            بازگشت
          </Link>
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500">ویرایش کارت</span>
            {card.is_primary && (
              <span className="rounded-full bg-primary-100 px-2 py-0.5 text-[10px] font-bold text-primary-700">
                اصلی
              </span>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Visibility toggle */}
          <div className={cardClass}>
            <h3 className={sectionTitle}>
              {isPrivate ? <Lock {...iconProps} /> : <Globe2 {...iconProps} />}
              نمایش کارت
            </h3>
            <button
              type="button"
              onClick={() => setValue('is_private', !isPrivate)}
              className={`flex w-full items-center justify-between rounded-xl border-2 p-4 text-right transition-all ${
                isPrivate
                  ? 'border-slate-300 bg-slate-50'
                  : 'border-emerald-300 bg-emerald-50'
              }`}
            >
              <div>
                <p className="text-sm font-bold text-gray-800">
                  {isPrivate ? '🔒 کارت خصوصی' : '🌐 کارت عمومی'}
                </p>
                <p className="mt-1 text-xs text-gray-500">
                  {isPrivate
                    ? 'فقط با لینک مستقیم قابل دسترسی است و در لیست‌های عمومی نمایش داده نمی‌شود.'
                    : 'همه می‌توانند آن را ببینند و در جستجوها نمایش داده می‌شود.'}
                </p>
              </div>
              <div
                className={`flex h-6 w-11 shrink-0 items-center rounded-full p-0.5 transition-colors ${
                  isPrivate ? 'bg-slate-400' : 'bg-emerald-500'
                }`}
              >
                <div
                  className={`h-5 w-5 rounded-full bg-white shadow transition-transform ${
                    isPrivate ? 'translate-x-0' : 'translate-x-5'
                  }`}
                />
              </div>
            </button>
          </div>

          {/* Theme */}
          <div className={cardClass}>
            <h3 className={sectionTitle}>
              <Palette {...iconProps} />
              قالب کارت
            </h3>
            <div className="grid grid-cols-3 gap-3">
              {(Object.keys(THEMES) as CardTheme[]).map((theme) => (
                <button
                  key={theme}
                  type="button"
                  onClick={() => setSelectedTheme(theme)}
                  className={`relative aspect-[1.6/1] overflow-hidden rounded-xl border-2 transition-all ${
                    selectedTheme === theme
                      ? 'border-primary-500 shadow-lg'
                      : 'border-transparent hover:border-gray-200'
                  }`}
                >
                  <div className={`h-full w-full bg-gradient-to-br ${THEMES[theme].front}`} />
                  <span className="absolute bottom-1 right-1 rounded bg-white/90 px-1.5 py-0.5 text-[9px] font-bold text-gray-700">
                    {THEMES[theme].label}
                  </span>
                  {selectedTheme === theme && (
                    <Check className="absolute inset-0 m-auto h-6 w-6 text-white drop-shadow-lg" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Avatar */}
          <div className={cardClass}>
            <h3 className={sectionTitle}>
              <ImageIcon {...iconProps} />
              عکس پروفایل
            </h3>
            <div className="flex items-center gap-4">
              <div className="relative">
                {avatarUrl ? (
                  <img
                    src={avatarUrl}
                    alt="avatar"
                    className="h-20 w-20 rounded-full object-cover ring-2 ring-primary-200"
                  />
                ) : (
                  <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary-50 text-2xl font-bold text-primary-600 ring-2 ring-primary-200">
                    {(card.full_name || card.username).charAt(0)}
                  </div>
                )}
                {uploading === 'avatar' && (
                  <div className="absolute inset-0 flex items-center justify-center rounded-full bg-white/70">
                    <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary-300 border-t-primary-600" />
                  </div>
                )}
              </div>
              <div className="flex flex-col gap-2">
                <label className="cursor-pointer rounded-xl bg-gray-100 px-4 py-2.5 text-center text-sm font-medium text-gray-700 hover:bg-gray-200">
                  {avatarUrl ? 'تغییر' : 'آپلود'}
                  <input type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
                </label>
                {avatarUrl && (
                  <button
                    type="button"
                    onClick={handleRemoveAvatar}
                    className="flex items-center justify-center gap-1.5 rounded-xl bg-red-50 px-4 py-2.5 text-sm font-medium text-red-600 hover:bg-red-100"
                  >
                    <Trash2 className="h-4 w-4" />
                    حذف
                  </button>
                )}
              </div>
            </div>
          </div>

          {mediaError && (
            <div className="rounded-xl bg-red-50 px-4 py-3 text-xs text-red-600">{mediaError}</div>
          )}

          {/* Cover */}
          <div className={cardClass}>
            <h3 className={sectionTitle}>
              <ImageIcon2 {...iconProps} />
              تصویر کاور
            </h3>
            {coverUrl && (
              <div className="relative mb-3 overflow-hidden rounded-xl">
                <img src={coverUrl} alt="cover" className="h-32 w-full object-cover" />
                {uploading === 'cover' && (
                  <div className="absolute inset-0 flex items-center justify-center bg-white/70">
                    <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary-300 border-t-primary-600" />
                  </div>
                )}
              </div>
            )}
            <div className="flex gap-2">
              <label className="cursor-pointer rounded-xl bg-gray-100 px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-200">
                {coverUrl ? 'تغییر کاور' : 'آپلود کاور'}
                <input type="file" accept="image/jpeg,image/png" onChange={handleCoverChange} className="hidden" />
              </label>
              {coverUrl && (
                <button
                  type="button"
                  onClick={handleRemoveCover}
                  className="flex items-center gap-1.5 rounded-xl bg-red-50 px-4 py-2.5 text-sm font-medium text-red-600 hover:bg-red-100"
                >
                  <Trash2 className="h-4 w-4" />
                  حذف
                </button>
              )}
            </div>
          </div>

          {/* Basic info */}
          <div className={cardClass}>
            <h3 className={sectionTitle}>
              <User {...iconProps} />
              اطلاعات شخصی
            </h3>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-gray-600">
                  نام کاربری (URL)
                </label>
                <div className="relative flex">
                  <span className="flex items-center rounded-r-xl border border-l-0 border-gray-200 bg-gray-100 px-3 text-xs text-gray-400" dir="ltr">
                    /
                  </span>
                  <input
                    {...register('username')}
                    dir="ltr"
                    className={`${inputClass} rounded-l-xl rounded-r-none`}
                  />
                </div>
                {usernameError && <p className="mt-1 text-xs text-red-500">{usernameError}</p>}
                {errors.username && <p className="mt-1 text-xs text-red-500">{errors.username.message}</p>}
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-gray-600">
                  نام و نام خانوادگی (فارسی)
                </label>
                <input {...register('full_name')} className={inputClass} placeholder="نام شما" />
                {errors.full_name && <p className="mt-1 text-xs text-red-500">{errors.full_name.message}</p>}
              </div>
              <div className="sm:col-span-2">
                <label className="mb-1.5 block text-xs font-medium text-gray-600">
                  نام انگلیسی (برای جستجو در مخاطبین)
                </label>
                <input
                  {...register('full_name_en')}
                  dir="ltr"
                  className={`${inputClass} text-left`}
                  placeholder="Ali Ahmadi"
                />
                <p className="mt-1 text-[10px] text-gray-400">
                  این نام در فایل vCard ذخیره می‌شود تا مخاطبین شما را با جستجوی فارسی یا انگلیسی پیدا کنند.
                </p>
              </div>
              <div className="sm:col-span-2">
                <label className="mb-1.5 block text-xs font-medium text-gray-600">عنوان شغلی</label>
                <div className="relative">
                  <Briefcase className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" strokeWidth={1.5} />
                  <input {...register('headline')} className={`${inputClass} pr-10`} placeholder="طراح محصول ارشد" />
                </div>
              </div>
              <div className="sm:col-span-2">
                <label className="mb-1.5 block text-xs font-medium text-gray-600">نام شرکت</label>
                <div className="relative">
                  <Building2 className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" strokeWidth={1.5} />
                  <input {...register('company')} className={`${inputClass} pr-10`} placeholder="شرکت شما" />
                </div>
              </div>
              <div className="sm:col-span-2">
                <label className="mb-1.5 block text-xs font-medium text-gray-600">بیوگرافی</label>
                <textarea {...register('bio')} rows={3} className={`${inputClass} resize-none`} />
                {errors.bio && <p className="mt-1 text-xs text-red-500">{errors.bio.message}</p>}
              </div>
            </div>
          </div>

          {/* Contact info */}
          <div className={cardClass}>
            <h3 className={sectionTitle}>
              <Mail {...iconProps} />
              اطلاعات تماس
            </h3>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-gray-600">ایمیل</label>
                <div className="relative">
                  <Mail className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" strokeWidth={1.5} />
                  <input {...register('email')} dir="ltr" className={`${inputClass} pr-10 text-left`} placeholder="you@example.com" />
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-gray-600">تلفن</label>
                <div className="relative">
                  <Phone className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" strokeWidth={1.5} />
                  <input {...register('phone')} dir="ltr" className={`${inputClass} pr-10 text-left`} placeholder="+98..." />
                </div>
              </div>
              <div className="sm:col-span-2">
                <label className="mb-1.5 block text-xs font-medium text-gray-600">وب‌سایت</label>
                <div className="relative">
                  <Globe className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" strokeWidth={1.5} />
                  <input {...register('website')} dir="ltr" className={`${inputClass} pr-10 text-left`} placeholder="https://..." />
                </div>
              </div>
            </div>
          </div>

          {/* Keywords */}
          <div className={cardClass}>
            <h3 className={sectionTitle}>
              <Tag {...iconProps} />
              کلیدواژه‌های جستجو
            </h3>
            <p className="mb-3 text-xs text-gray-500">
              مخاطبین با جستجوی این کلمات شما را در مخاطبین گوشی پیدا می‌کنند.
            </p>
            <div className="flex gap-2">
              <input
                value={keywordInput}
                onChange={(e) => setKeywordInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addKeyword();
                  }
                }}
                className={inputClass}
                placeholder="مثلاً: مشاور، املاک، تهران"
              />
              <button
                type="button"
                onClick={addKeyword}
                className="rounded-xl bg-primary-600 px-4 text-sm text-white hover:bg-primary-700"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
            {keywords.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {keywords.map((k) => (
                  <span
                    key={k}
                    className="flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-1 text-xs text-amber-700"
                  >
                    {k}
                    <button type="button" onClick={() => setKeywords(keywords.filter((x) => x !== k))}>
                      <X className="h-3 w-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Skills */}
          <div className={cardClass}>
            <h3 className={sectionTitle}>
              <Tag {...iconProps} />
              مهارت‌ها
            </h3>
            <div className="flex gap-2">
              <input
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addSkill();
                  }
                }}
                className={inputClass}
                placeholder="افزودن مهارت..."
              />
              <button
                type="button"
                onClick={addSkill}
                className="rounded-xl bg-primary-600 px-4 text-sm text-white hover:bg-primary-700"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
            {skills.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {skills.map((s) => (
                  <span
                    key={s}
                    className="flex items-center gap-1.5 rounded-full bg-primary-50 px-3 py-1.5 text-xs font-medium text-primary-700 ring-1 ring-primary-100"
                  >
                    {s}
                    <button type="button" onClick={() => setSkills(skills.filter((x) => x !== s))}>
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Social links */}
          <div className={cardClass}>
            <h3 className={sectionTitle}>
              <Share2 {...iconProps} />
              شبکه‌های اجتماعی
            </h3>
            <div className="space-y-5">
              <div>
                <p className="mb-2 text-xs font-bold text-gray-500">📱 شبکه‌های عمومی</p>
                <div className="grid gap-3 sm:grid-cols-2">
                  {FREE_SOCIAL_PLATFORMS.map((p) => (
                    <div key={p.value}>
                      <label className="mb-1 block text-xs text-gray-600">{p.label}</label>
                      <input
                        dir="ltr"
                        value={getSocialUrl(p.value)}
                        onChange={(e) => updateSocialUrl(p.value, e.target.value)}
                        className={`${inputClass} text-left`}
                        placeholder={`https://${p.value}.com/...`}
                      />
                    </div>
                  ))}
                </div>
              </div>

              {card.is_premium && (
                <>
                  <div>
                    <p className="mb-2 text-xs font-bold text-gray-500">⭐ شبکه‌های ویژه</p>
                    <div className="grid gap-3 sm:grid-cols-2">
                      {PREMIUM_SOCIAL_PLATFORMS.map((p) => (
                        <div key={p.value}>
                          <label className="mb-1 block text-xs text-gray-600">{p.label}</label>
                          <input
                            dir="ltr"
                            value={getSocialUrl(p.value)}
                            onChange={(e) => updateSocialUrl(p.value, e.target.value)}
                            className={`${inputClass} text-left`}
                            placeholder={`https://${p.value}.com/...`}
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="mb-2 text-xs font-bold text-gray-500">🇮🇷 شبکه‌های داخلی</p>
                    <div className="grid gap-3 sm:grid-cols-2">
                      {IRANIAN_SOCIAL_PLATFORMS.map((p) => (
                        <div key={p.value}>
                          <label className="mb-1 block text-xs text-gray-600">{p.label}</label>
                          <input
                            dir="ltr"
                            value={getSocialUrl(p.value)}
                            onChange={(e) => updateSocialUrl(p.value, e.target.value)}
                            className={`${inputClass} text-left`}
                            placeholder={`https://${p.value}.ir/...`}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}

              {/* Custom links - نامحدود */}
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <p className="text-xs font-bold text-gray-500">🔗 لینک‌های دلخواه (نامحدود)</p>
                  <button
                    type="button"
                    onClick={() => setCustomLinks([...customLinks, { label: '', url: '' }])}
                    className="flex items-center gap-1 rounded-lg bg-primary-50 px-2.5 py-1 text-[10px] font-bold text-primary-700 hover:bg-primary-100"
                  >
                    <Plus className="h-3 w-3" />
                    افزودن
                  </button>
                </div>
                {customLinks.length === 0 ? (
                  <p className="rounded-xl bg-gray-50 p-4 text-center text-xs text-gray-400">
                    لینک دلخواهی اضافه نشده. (مثلاً: کانال، وبلاگ، پورتفولیو)
                  </p>
                ) : (
                  <div className="space-y-2">
                    {customLinks.map((link, i) => (
                      <div key={i} className="flex gap-2">
                        <input
                          value={link.label}
                          onChange={(e) =>
                            setCustomLinks(
                              customLinks.map((l, idx) =>
                                idx === i ? { ...l, label: e.target.value } : l
                              )
                            )
                          }
                          className={`${inputClass} w-32`}
                          placeholder="برچسب"
                        />
                        <input
                          value={link.url}
                          onChange={(e) =>
                            setCustomLinks(
                              customLinks.map((l, idx) =>
                                idx === i ? { ...l, url: e.target.value } : l
                              )
                            )
                          }
                          dir="ltr"
                          className={`${inputClass} flex-1 text-left`}
                          placeholder="https://..."
                        />
                        <button
                          type="button"
                          onClick={() => setCustomLinks(customLinks.filter((_, idx) => idx !== i))}
                          className="rounded-lg bg-red-50 px-2.5 text-red-600 hover:bg-red-100"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {!card.is_premium && (
              <div className="mt-4 rounded-2xl bg-amber-50 p-4 ring-1 ring-amber-100">
                <p className="text-xs text-gray-700">
                  🔒 برای فعال‌سازی شبکه‌های ویژه و داخلی به نسخه ویژه ارتقا دهید.
                </p>
                <Link
                  to="/pricing"
                  className="mt-2 inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 px-3 py-1.5 text-xs font-bold text-white"
                >
                  <Crown className="h-3 w-3" />
                  ارتقا
                </Link>
              </div>
            )}
          </div>

          {/* Custom fields (embedded) */}
          <CustomFieldsTab
            initialFields={customFields}
            onSave={() => {
              // Reload from server
            }}
          />

          {/* Audio/Video — premium */}
          {card.is_premium && (
            <div className={cardClass}>
              <h3 className={sectionTitle}>
                <Music {...iconProps} />
                معرفی صوتی / ویدیویی
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="mb-1 block text-xs text-gray-600">معرفی صوتی (MP3)</label>
                  {audioUrl && <audio controls src={audioUrl} className="mb-2 w-full" />}
                  <label className="inline-block cursor-pointer rounded-xl bg-gray-100 px-4 py-2 text-xs font-medium text-gray-700 hover:bg-gray-200">
                    {audioUrl ? 'تغییر صوت' : 'آپلود صوت'}
                    <input type="file" accept="audio/*" onChange={handleAudioChange} className="hidden" />
                  </label>
                  {uploading === 'audio' && <span className="mr-2 text-xs text-gray-400">در حال آپلود...</span>}
                </div>
                <div>
                  <label className="mb-1 block text-xs text-gray-600">معرفی ویدیویی (MP4)</label>
                  {videoUrl && <video controls src={videoUrl} className="mb-2 w-full rounded-xl" />}
                  <label className="inline-block cursor-pointer rounded-xl bg-gray-100 px-4 py-2 text-xs font-medium text-gray-700 hover:bg-gray-200">
                    {videoUrl ? 'تغییر ویدیو' : 'آپلود ویدیو'}
                    <input type="file" accept="video/mp4" onChange={handleVideoChange} className="hidden" />
                  </label>
                  {uploading === 'video' && <span className="mr-2 text-xs text-gray-400">در حال آپلود...</span>}
                </div>
              </div>
            </div>
          )}

          {/* Template */}
          <div className={cardClass}>
            <h3 className={sectionTitle}>نوع قالب</h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setValue('template_type', 'personal')}
                className={`rounded-xl border-2 p-4 text-right transition-all ${
                  templateType === 'personal'
                    ? 'border-primary-500 bg-primary-50'
                    : 'border-gray-100 hover:border-gray-200'
                }`}
              >
                <span className="font-medium text-gray-800">شخصی</span>
              </button>
              <button
                type="button"
                onClick={() => setValue('template_type', 'corporate')}
                className={`rounded-xl border-2 p-4 text-right transition-all ${
                  templateType === 'corporate'
                    ? 'border-primary-500 bg-primary-50'
                    : 'border-gray-100 hover:border-gray-200'
                }`}
              >
                <span className="font-medium text-gray-800">شرکتی</span>
              </button>
            </div>
          </div>

          {/* Save */}
          <div className="sticky bottom-4">
            <motion.button
              type="submit"
              disabled={saving}
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.98 }}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary-600 py-4 text-sm font-bold text-white shadow-[0_8px_24px_rgba(20,184,166,0.25)] hover:bg-primary-700 disabled:opacity-50"
            >
              {saved ? (
                <>
                  <Check className="h-5 w-5" />
                  ذخیره شد!
                </>
              ) : saving ? (
                <div className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white" />
              ) : (
                <>
                  <Save className="h-5 w-5" />
                  ذخیره تغییرات
                </>
              )}
            </motion.button>
          </div>
        </form>
      </main>
    </div>
  );
}