import { useEffect, useState, useCallback } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Shield,
  Package,
  Users,
  CheckCircle2,
  Truck,
  XCircle,
  Clock,
  Crown,
  ArrowRight,
  LogOut,
  RefreshCw,
  Send,
  Phone,
  Mail,
  Check,
  Home,
  LayoutDashboard,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { useIsAdmin } from '@/hooks/useIsAdmin';
import {
  getPremiumRequests,
  approvePremiumRequest,
  rejectPremiumRequest,
  type PremiumRequest,
} from '@/lib/premium';
import type { Order, OrderStatus, Profile } from '@/types';

type Tab = 'orders' | 'users' | 'premium';

const STATUS_LABELS: Record<OrderStatus, string> = {
  pending: 'در انتظار',
  confirmed: 'تایید شده',
  shipped: 'ارسال شده',
  cancelled: 'لغو شده',
};

const STATUS_STYLES: Record<OrderStatus, string> = {
  pending: 'bg-amber-50 text-amber-700 border-amber-200',
  confirmed: 'bg-blue-50 text-blue-700 border-blue-200',
  shipped: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  cancelled: 'bg-red-50 text-red-700 border-red-200',
};

const CARD_TYPE_LABELS: Record<string, string> = {
  digital: 'دیجیتال',
  hybrid_nfc: 'NFC هیبریدی',
};

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString('fa-IR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return iso;
  }
}

export function AdminPage() {
  const { user, signOut } = useAuth();
  const { isAdmin, loading } = useIsAdmin();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [premiumRequests, setPremiumRequests] = useState<PremiumRequest[]>([]);
  const [dataLoading, setDataLoading] = useState(false);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const fetchAll = useCallback(async () => {
    setDataLoading(true);
    try {
      const [ordersRes, profilesRes, premiumData] = await Promise.all([
        supabase.from('orders').select('*').order('created_at', { ascending: false }),
        supabase.from('profiles').select('*').order('created_at', { ascending: false }),
        getPremiumRequests().catch(() => []),
      ]);
      if (ordersRes.error) console.error('[Admin] orders:', ordersRes.error);
      else setOrders((ordersRes.data as Order[]) ?? []);

      if (profilesRes.error) console.error('[Admin] profiles:', profilesRes.error);
      else setProfiles((profilesRes.data as Profile[]) ?? []);

      setPremiumRequests(premiumData);
    } finally {
      setDataLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!loading && isAdmin) {
      fetchAll();
    }
  }, [loading, isAdmin, fetchAll]);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const updateOrderStatus = async (orderId: string, status: OrderStatus) => {
    setUpdatingId(orderId);
    const { error } = await supabase
      .from('orders')
      .update({ status })
      .eq('id', orderId);
    if (error) {
      console.error('[Admin] update order error:', error);
      alert('خطا در به‌روزرسانی وضعیت سفارش');
    } else {
      setOrders((prev) =>
        prev.map((o) => (o.id === orderId ? { ...o, status } : o))
      );
    }
    setUpdatingId(null);
  };

  const togglePremium = async (profileId: string, current: boolean) => {
    setUpdatingId(profileId);
    const { error } = await supabase
      .from('profiles')
      .update({ is_premium: !current })
      .eq('id', profileId);
    if (error) {
      console.error('[Admin] toggle premium error:', error);
      alert('خطا در تغییر وضعیت ویژه');
    } else {
      setProfiles((prev) =>
        prev.map((p) =>
          p.id === profileId ? { ...p, is_premium: !current } : p
        )
      );
    }
    setUpdatingId(null);
  };

  const handleApprovePremium = async (req: PremiumRequest) => {
    setUpdatingId(req.id);
    try {
      await approvePremiumRequest(req.id, req.user_id);
      setPremiumRequests((prev) =>
        prev.map((r) => (r.id === req.id ? { ...r, status: 'approved' } : r))
      );
      setProfiles((prev) =>
        prev.map((p) => (p.id === req.user_id ? { ...p, is_premium: true } : p))
      );
    } catch (err) {
      console.error('[Admin] approve premium error:', err);
      alert('خطا در تأیید درخواست ویژه');
    } finally {
      setUpdatingId(null);
    }
  };

  const handleRejectPremium = async (req: PremiumRequest) => {
    setUpdatingId(req.id);
    try {
      await rejectPremiumRequest(req.id);
      setPremiumRequests((prev) =>
        prev.map((r) => (r.id === req.id ? { ...r, status: 'rejected' } : r))
      );
    } catch (err) {
      console.error('[Admin] reject premium error:', err);
      alert('خطا در رد درخواست');
    } finally {
      setUpdatingId(null);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center gradient-mesh">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary-200 border-t-primary-600" />
      </div>
    );
  }

  if (!user || !isAdmin) {
    return (
      <div className="flex min-h-screen items-center justify-center gradient-mesh px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md rounded-3xl bg-white p-8 text-center shadow-xl"
        >
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-red-50">
            <Shield className="h-8 w-8 text-red-500" strokeWidth={1.5} />
          </div>
          <h1 className="mb-2 text-xl font-bold text-gray-800">دسترسی غیرمجاز</h1>
          <p className="mb-6 text-sm text-gray-500">
            شما اجازه دسترسی به این بخش را ندارید.
          </p>
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-2 rounded-xl bg-primary-600 px-5 py-2.5 text-sm font-medium text-white shadow-md transition-colors hover:bg-primary-700"
          >
            بازگشت به صفحه اصلی
            <ArrowRight className="h-4 w-4" strokeWidth={1.5} />
          </button>
        </motion.div>
      </div>
    );
  }

  const pendingPremiumCount = premiumRequests.filter((r) => r.status === 'pending').length;

  const navItems: { id: Tab; label: string; icon: typeof Package; count?: number }[] = [
    { id: 'orders', label: 'سفارشات', icon: Package, count: orders.length },
    { id: 'premium', label: 'درخواست‌های ویژه', icon: Crown, count: pendingPremiumCount },
    { id: 'users', label: 'کاربران', icon: Users, count: profiles.length },
  ];

  return (
    <div className="min-h-screen gradient-mesh">
      {/* Header */}
      <header className="sticky top-0 z-30 glass border-b border-gray-100">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary-600 to-primary-800 shadow-md">
              <Shield className="h-5 w-5 text-white" strokeWidth={1.5} />
            </div>
            <div>
              <h1 className="text-sm font-bold text-gray-800">پنل مدیریت</h1>
              <p className="text-xs text-gray-500">Admin Dashboard</p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {/* دکمه بازگشت به داشبورد */}
            <Link
              to="/dashboard"
              className="flex items-center gap-1.5 rounded-xl bg-white px-3 py-2 text-xs font-medium text-gray-700 shadow-sm transition-shadow hover:shadow-md"
            >
              <LayoutDashboard className="h-3.5 w-3.5" strokeWidth={1.5} />
              <span className="hidden sm:inline">داشبورد</span>
            </Link>

            {/* دکمه بازگشت به صفحه اصلی */}
            <Link
              to="/"
              className="flex items-center gap-1.5 rounded-xl bg-white px-3 py-2 text-xs font-medium text-gray-700 shadow-sm transition-shadow hover:shadow-md"
            >
              <Home className="h-3.5 w-3.5" strokeWidth={1.5} />
              <span className="hidden sm:inline">صفحه اصلی</span>
            </Link>

            {/* دکمه به‌روزرسانی */}
            <motion.button
              onClick={fetchAll}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="flex items-center gap-1.5 rounded-xl bg-white px-3 py-2 text-xs font-medium text-gray-700 shadow-sm transition-shadow hover:shadow-md"
            >
              <RefreshCw className="h-3.5 w-3.5" strokeWidth={1.5} />
              <span className="hidden sm:inline">به‌روزرسانی</span>
            </motion.button>

            {/* دکمه خروج */}
            <motion.button
              onClick={handleSignOut}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="flex items-center gap-1.5 rounded-xl bg-white px-3 py-2 text-xs font-medium text-red-500 shadow-sm transition-colors hover:bg-red-50"
            >
              <LogOut className="h-3.5 w-3.5" strokeWidth={1.5} />
              <span className="hidden sm:inline">خروج</span>
            </motion.button>
          </div>
        </div>

        {/* Tabs */}
        <div className="mx-auto max-w-6xl px-4 pb-3">
          <div className="flex gap-2 overflow-x-auto">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <motion.button
                  key={item.id}
                  onClick={() => setTab(item.id)}
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.97 }}
                  className={`flex flex-1 shrink-0 items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-medium transition-all ${
                    tab === item.id
                      ? 'bg-primary-600 text-white shadow-md'
                      : 'bg-white text-gray-500 shadow-sm'
                  }`}
                >
                  <Icon className="h-4 w-4" strokeWidth={1.5} />
                  <span className="whitespace-nowrap">{item.label}</span>
                  {item.count !== undefined && item.count > 0 && (
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs ${
                        tab === item.id
                          ? 'bg-white/20 text-white'
                          : 'bg-gray-100 text-gray-500'
                      }`}
                    >
                      {item.count}
                    </span>
                  )}
                </motion.button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="mx-auto max-w-6xl px-4 py-6 pb-28 md:pb-6">
        {dataLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary-200 border-t-primary-600" />
          </div>
        ) : (
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {tab === 'orders' && (
              <OrdersTable
                orders={orders}
                onStatusChange={updateOrderStatus}
                updatingId={updatingId}
              />
            )}
            {tab === 'premium' && (
              <PremiumRequestsTable
                requests={premiumRequests}
                onApprove={handleApprovePremium}
                onReject={handleRejectPremium}
                updatingId={updatingId}
              />
            )}
            {tab === 'users' && (
              <UsersTable
                profiles={profiles}
                onTogglePremium={togglePremium}
                updatingId={updatingId}
              />
            )}
          </motion.div>
        )}
      </main>
    </div>
  );
}

/* ============================================
   Orders Table
   ============================================ */
function OrdersTable({
  orders,
  onStatusChange,
  updatingId,
}: {
  orders: Order[];
  onStatusChange: (id: string, status: OrderStatus) => void;
  updatingId: string | null;
}) {
  if (orders.length === 0) {
    return (
      <div className="rounded-2xl bg-white p-12 text-center shadow-sm">
        <Package className="mx-auto mb-3 h-12 w-12 text-gray-300" strokeWidth={1} />
        <p className="text-sm text-gray-400">هنوز سفارشی ثبت نشده است</p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-2xl bg-white shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full text-right text-sm">
          <thead>
            <tr className="border-b border-gray-100 bg-gray-50/50">
              <th className="px-4 py-3 font-medium text-gray-500">نام</th>
              <th className="px-4 py-3 font-medium text-gray-500">تلفن</th>
              <th className="px-4 py-3 font-medium text-gray-500">نوع کارت</th>
              <th className="px-4 py-3 font-medium text-gray-500">تعداد</th>
              <th className="px-4 py-3 font-medium text-gray-500">وضعیت</th>
              <th className="px-4 py-3 font-medium text-gray-500">تاریخ</th>
              <th className="px-4 py-3 font-medium text-gray-500">عملیات</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr
                key={order.id}
                className="border-b border-gray-50 transition-colors hover:bg-gray-50/30"
              >
                <td className="px-4 py-3">
                  <div className="font-medium text-gray-800">{order.full_name}</div>
                  {order.email && (
                    <div className="text-xs text-gray-400">{order.email}</div>
                  )}
                </td>
                <td className="px-4 py-3 text-gray-600" dir="ltr">{order.phone}</td>
                <td className="px-4 py-3">
                  <span className="rounded-lg bg-primary-50 px-2 py-1 text-xs font-medium text-primary-700">
                    {CARD_TYPE_LABELS[order.card_type] ?? order.card_type}
                  </span>
                </td>
                <td className="px-4 py-3 text-gray-600">{order.quantity}</td>
                <td className="px-4 py-3">
                  <span
                    className={`inline-flex items-center gap-1 rounded-lg border px-2 py-1 text-xs font-medium ${STATUS_STYLES[order.status]}`}
                  >
                    {STATUS_LABELS[order.status]}
                  </span>
                </td>
                <td className="px-4 py-3 text-xs text-gray-400">
                  {formatDate(order.created_at)}
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1.5">
                    {order.status !== 'confirmed' && (
                      <button
                        onClick={() => onStatusChange(order.id, 'confirmed')}
                        disabled={updatingId === order.id}
                        className="flex items-center gap-1 rounded-lg bg-blue-50 px-2.5 py-1.5 text-xs font-medium text-blue-600 transition-colors hover:bg-blue-100 disabled:opacity-50"
                        title="تایید"
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" strokeWidth={1.5} />
                      </button>
                    )}
                    {order.status !== 'shipped' && (
                      <button
                        onClick={() => onStatusChange(order.id, 'shipped')}
                        disabled={updatingId === order.id}
                        className="flex items-center gap-1 rounded-lg bg-emerald-50 px-2.5 py-1.5 text-xs font-medium text-emerald-600 transition-colors hover:bg-emerald-100 disabled:opacity-50"
                        title="ارسال"
                      >
                        <Truck className="h-3.5 w-3.5" strokeWidth={1.5} />
                      </button>
                    )}
                    {order.status !== 'cancelled' && (
                      <button
                        onClick={() => onStatusChange(order.id, 'cancelled')}
                        disabled={updatingId === order.id}
                        className="flex items-center gap-1 rounded-lg bg-red-50 px-2.5 py-1.5 text-xs font-medium text-red-600 transition-colors hover:bg-red-100 disabled:opacity-50"
                        title="لغو"
                      >
                        <XCircle className="h-3.5 w-3.5" strokeWidth={1.5} />
                      </button>
                    )}
                    {order.status !== 'pending' && (
                      <button
                        onClick={() => onStatusChange(order.id, 'pending')}
                        disabled={updatingId === order.id}
                        className="flex items-center gap-1 rounded-lg bg-amber-50 px-2.5 py-1.5 text-xs font-medium text-amber-600 transition-colors hover:bg-amber-100 disabled:opacity-50"
                        title="در انتظار"
                      >
                        <Clock className="h-3.5 w-3.5" strokeWidth={1.5} />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ============================================
   Premium Requests Table
   ============================================ */
function PremiumRequestsTable({
  requests,
  onApprove,
  onReject,
  updatingId,
}: {
  requests: PremiumRequest[];
  onApprove: (req: PremiumRequest) => void;
  onReject: (req: PremiumRequest) => void;
  updatingId: string | null;
}) {
  if (requests.length === 0) {
    return (
      <div className="rounded-2xl bg-white p-12 text-center shadow-sm">
        <Crown className="mx-auto mb-3 h-12 w-12 text-gray-300" strokeWidth={1} />
        <p className="text-sm text-gray-400">هیچ درخواست ویژه‌ای ثبت نشده است</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {requests.map((req) => (
        <div key={req.id} className="rounded-2xl bg-white p-5 shadow-sm">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p className="font-bold text-gray-800">{req.full_name || '—'}</p>
                <span
                  className={`rounded-full px-3 py-0.5 text-[10px] font-bold ${
                    req.status === 'pending'
                      ? 'bg-amber-100 text-amber-700'
                      : req.status === 'approved'
                        ? 'bg-emerald-100 text-emerald-700'
                        : 'bg-red-100 text-red-700'
                  }`}
                >
                  {req.status === 'pending'
                    ? 'در انتظار تأیید'
                    : req.status === 'approved'
                      ? 'تأیید شده'
                      : 'رد شده'}
                </span>
              </div>
              <div className="mt-2 flex flex-wrap gap-3 text-xs text-gray-500">
                {req.phone && (
                  <span className="flex items-center gap-1">
                    <Phone className="h-3 w-3" />
                    <span dir="ltr">{req.phone}</span>
                  </span>
                )}
                {req.telegram_username && (
                  <span className="flex items-center gap-1">
                    <Send className="h-3 w-3" />
                    <span dir="ltr">{req.telegram_username}</span>
                  </span>
                )}
                <span className="font-bold text-emerald-600">
                  {req.amount.toLocaleString('fa-IR')} تومان
                </span>
                <span className="text-gray-400">{formatDate(req.created_at)}</span>
              </div>
              {req.receipt_note && (
                <p className="mt-2 rounded-lg bg-gray-50 px-3 py-2 text-xs text-gray-600">
                  <span className="font-bold">پیگیری: </span>
                  {req.receipt_note}
                </p>
              )}
            </div>
            {req.status === 'pending' && (
              <div className="flex gap-2">
                <button
                  onClick={() => onApprove(req)}
                  disabled={updatingId === req.id}
                  className="flex items-center gap-1.5 rounded-xl bg-emerald-500 px-4 py-2 text-xs font-bold text-white transition-colors hover:bg-emerald-600 disabled:opacity-50"
                >
                  <Check className="h-3.5 w-3.5" strokeWidth={2} />
                  تأیید و ارتقا
                </button>
                <button
                  onClick={() => onReject(req)}
                  disabled={updatingId === req.id}
                  className="flex items-center gap-1.5 rounded-xl bg-red-50 px-3 py-2 text-xs font-bold text-red-600 transition-colors hover:bg-red-100 disabled:opacity-50"
                >
                  <XCircle className="h-3.5 w-3.5" strokeWidth={2} />
                </button>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ============================================
   Users Table
   ============================================ */
function UsersTable({
  profiles,
  onTogglePremium,
  updatingId,
}: {
  profiles: Profile[];
  onTogglePremium: (id: string, current: boolean) => void;
  updatingId: string | null;
}) {
  if (profiles.length === 0) {
    return (
      <div className="rounded-2xl bg-white p-12 text-center shadow-sm">
        <Users className="mx-auto mb-3 h-12 w-12 text-gray-300" strokeWidth={1} />
        <p className="text-sm text-gray-400">هنوز کاربری ثبت نشده است</p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-2xl bg-white shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full text-right text-sm">
          <thead>
            <tr className="border-b border-gray-100 bg-gray-50/50">
              <th className="px-4 py-3 font-medium text-gray-500">نام</th>
              <th className="px-4 py-3 font-medium text-gray-500">نام کاربری</th>
              <th className="px-4 py-3 font-medium text-gray-500">ایمیل</th>
              <th className="px-4 py-3 font-medium text-gray-500">تلفن</th>
              <th className="px-4 py-3 font-medium text-gray-500">وضعیت</th>
              <th className="px-4 py-3 font-medium text-gray-500">عملیات</th>
            </tr>
          </thead>
          <tbody>
            {profiles.map((profile) => (
              <tr
                key={profile.id}
                className="border-b border-gray-50 transition-colors hover:bg-gray-50/30"
              >
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    {profile.avatar_url ? (
                      <img
                        src={profile.avatar_url}
                        alt={profile.full_name}
                        className="h-8 w-8 rounded-full object-cover"
                      />
                    ) : (
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-50 text-xs font-medium text-primary-600">
                        {profile.full_name?.charAt(0) ?? '?'}
                      </div>
                    )}
                    <span className="font-medium text-gray-800">
                      {profile.full_name || '—'}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-3 text-gray-600">@{profile.username}</td>
                <td className="px-4 py-3 text-gray-500" dir="ltr">
                  {profile.email || '—'}
                </td>
                <td className="px-4 py-3 text-gray-500" dir="ltr">
                  {profile.phone || '—'}
                </td>
                <td className="px-4 py-3">
                  {profile.is_premium ? (
                    <span className="inline-flex items-center gap-1 rounded-lg bg-amber-50 px-2 py-1 text-xs font-medium text-amber-700">
                      <Crown className="h-3.5 w-3.5" strokeWidth={1.5} />
                      ویژه
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 rounded-lg bg-gray-50 px-2 py-1 text-xs font-medium text-gray-500">
                      عادی
                    </span>
                  )}
                </td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => onTogglePremium(profile.id, profile.is_premium)}
                    disabled={updatingId === profile.id}
                    className={
                      profile.is_premium
                        ? 'flex items-center gap-1.5 rounded-lg bg-red-50 px-3 py-1.5 text-xs font-medium text-red-600 transition-colors hover:bg-red-100 disabled:opacity-50'
                        : 'flex items-center gap-1.5 rounded-lg bg-amber-50 px-3 py-1.5 text-xs font-medium text-amber-600 transition-colors hover:bg-amber-100 disabled:opacity-50'
                    }
                  >
                    <Crown className="h-3.5 w-3.5" strokeWidth={1.5} />
                    {profile.is_premium ? 'لغو ویژه' : 'ارتقا به ویژه'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}