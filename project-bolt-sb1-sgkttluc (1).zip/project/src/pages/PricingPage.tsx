import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Check,
  Crown,
  Building2,
  X,
  Copy,
  CreditCard,
  Send,
  MessageCircle,
  Sparkles,
  ArrowLeft,
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { createPremiumRequest } from '@/lib/premium';

const CARD_NUMBER = '6104-3378-8278-3457'; // ← شماره کارت خود را وارد کنید
const CARD_HOLDER = 'مهدی مستاجران';
const TELEGRAM_ID = '@mahdimostajeran';

export function PricingPage() {
  const { user } = useAuth();
  const [showPayment, setShowPayment] = useState(false);
  const [copied, setCopied] = useState(false);
  const [formData, setFormData] = useState({
    full_name: '',
    phone: '',
    telegram_username: '',
    receipt_note: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleCopyCard = () => {
    navigator.clipboard.writeText(CARD_NUMBER.replace(/-/g, ''));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSubmitting(true);
    setError('');
    try {
      await createPremiumRequest({
        user_id: user.id,
        full_name: formData.full_name,
        phone: formData.phone,
        telegram_username: formData.telegram_username,
        receipt_note: formData.receipt_note,
        amount: 399000,
      });
      setSubmitted(true);
    } catch (err: any) {
      setError(err.message || 'خطا در ثبت درخواست');
    } finally {
      setSubmitting(false);
    }
  };

  const handleTelegramClick = () => {
    window.open(`https://t.me/${TELEGRAM_ID.replace('@', '')}`, '_blank');
  };

  return (
    <div className="min-h-screen gradient-mesh">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5 sm:px-6">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 shadow-md">
            <Sparkles className="h-5 w-5 text-white" strokeWidth={1.5} />
          </div>
          <span className="text-lg font-extrabold text-gray-800">کارتین</span>
        </Link>
        <Link
          to="/"
          className="flex items-center gap-1.5 rounded-xl px-4 py-2 text-sm font-medium text-gray-600 transition-colors hover:bg-white hover:text-primary-600"
        >
          <ArrowLeft className="h-4 w-4" strokeWidth={1.5} />
          بازگشت
        </Link>
      </nav>

      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-16">
        <div className="mb-12 text-center">
          <h1 className="text-3xl font-extrabold text-gray-800 sm:text-4xl">
            پلن‌های قیمت‌گذاری
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-gray-500">
            با نسخه رایگان شروع کنید و در صورت نیاز به امکانات بیشتر، ارتقا دهید.
          </p>
        </div>

        <div className="grid gap-5 lg:grid-cols-3">
          {/* Free */}
          <div className="rounded-3xl bg-white p-8 shadow-[0_2px_12px_rgba(0,0,0,0.04)]">
            <h3 className="text-lg font-extrabold text-gray-800">رایگان</h3>
            <p className="mt-1 text-sm text-gray-500">برای شروع و استفاده شخصی</p>
            <p className="mt-6 text-4xl font-extrabold text-gray-800">
              ۰<span className="text-base font-medium text-gray-400"> تومان</span>
            </p>
            <ul className="mt-6 space-y-3">
              {[
                'ساخت کارت ویزیت دیجیتال',
                'لینک اختصاصی',
                'QR Code',
                'ذخیره در مخاطبین (vCard)',
                'آمار بازدید پایه',
              ].map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm text-gray-600">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary-600" strokeWidth={2} />
                  {item}
                </li>
              ))}
            </ul>
            <Link
              to={user ? '/dashboard' : '/auth?mode=signup'}
              className="mt-8 block rounded-2xl bg-gray-100 py-3.5 text-center text-sm font-bold text-gray-700 transition-colors hover:bg-gray-200"
            >
              {user ? 'ورود به داشبورد' : 'شروع رایگان'}
            </Link>
          </div>

          {/* Pro */}
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary-600 to-accent-600 p-8 text-white shadow-2xl lg:scale-105">
            <span className="absolute top-4 left-4 rounded-full bg-white/20 px-3 py-1 text-[10px] font-bold backdrop-blur-sm">
              پیشنهاد ویژه
            </span>
            <div className="flex items-center gap-2">
              <Crown className="h-5 w-5" strokeWidth={1.5} />
              <h3 className="text-lg font-extrabold">حرفه‌ای</h3>
            </div>
            <p className="mt-1 text-sm text-white/80">برای فریلنسرها و متخصصین</p>
            <div className="mt-6">
              <p className="text-4xl font-extrabold">
                ۳۹۹<span className="text-base font-medium text-white/70"> هزار تومان / ماه</span>
              </p>
              <p className="mt-2 text-xs text-white/80">کمتر از قیمت یک مینی‌پیتزا در ماه! 🍕</p>
            </div>
            <ul className="mt-6 space-y-3">
              {[
                'تمام امکانات نسخه رایگان',
                'آمار بازدید پیشرفته و نمودار',
                'صفحه‌ساز هوشمند (AI)',
                'معرفی صوتی و ویدیویی',
                'قالب‌های اختصاصی',
                'حذف لوگوی پلتفرم',
                'پشتیبانی اولویت‌دار',
              ].map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm">
                  <Check className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={2} />
                  {item}
                </li>
              ))}
            </ul>
            <button
              onClick={() => setShowPayment(true)}
              className="mt-8 block w-full rounded-2xl bg-white py-3.5 text-center text-sm font-bold text-primary-700 transition-transform hover:scale-[1.02]"
            >
              ارتقا به نسخه حرفه‌ای
            </button>
          </div>

          {/* Enterprise */}
          <div className="rounded-3xl bg-white p-8 shadow-[0_2px_12px_rgba(0,0,0,0.04)]">
            <div className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-gray-700" strokeWidth={1.5} />
              <h3 className="text-lg font-extrabold text-gray-800">سازمانی</h3>
            </div>
            <p className="mt-1 text-sm text-gray-500">برای شرکت‌ها و تیم‌ها</p>
            <p className="mt-6 text-4xl font-extrabold text-gray-800">
              سفارشی<span className="text-base font-medium text-gray-400"> / توافقی</span>
            </p>
            <ul className="mt-6 space-y-3">
              {[
                'تمام امکانات نسخه حرفه‌ای',
                'کارت ویزیت اختصاصی برای هر کارمند',
                'پنل مدیریت سازمانی',
                'قالب اختصاصی با لوگوی شرکت',
                'آمار تیمی و گزارش‌گیری',
                'پشتیبانی اختصاصی',
              ].map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm text-gray-600">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary-600" strokeWidth={2} />
                  {item}
                </li>
              ))}
            </ul>
            <button
              onClick={handleTelegramClick}
              className="mt-8 flex w-full items-center justify-center gap-2 rounded-2xl bg-gray-900 py-3.5 text-center text-sm font-bold text-white transition-colors hover:bg-gray-800"
            >
              <MessageCircle className="h-4 w-4" strokeWidth={2} />
              درخواست مشاوره
            </button>
          </div>
        </div>

        <p className="mt-8 text-center text-xs text-gray-400">
          * قیمت‌گذاری کارت ویزیت NFC هیبریدی به زودی اعلام می‌شود.
        </p>
      </div>

      {/* Payment Modal */}
      <AnimatePresence>
        {showPayment && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
          >
            <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setShowPayment(false)} />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative z-10 max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl sm:p-8"
            >
              <button
                onClick={() => setShowPayment(false)}
                className="absolute top-4 left-4 rounded-full p-2 text-gray-400 transition-colors hover:bg-gray-100"
              >
                <X className="h-5 w-5" strokeWidth={1.5} />
              </button>

              {submitted ? (
                <div className="py-8 text-center">
                  <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50">
                    <Check className="h-8 w-8 text-emerald-600" strokeWidth={2} />
                  </div>
                  <h3 className="text-xl font-extrabold text-gray-800">درخواست شما ثبت شد!</h3>
                  <p className="mx-auto mt-3 max-w-sm text-sm leading-relaxed text-gray-500">
                    لطفاً برای تسریع در تأیید، رسید پرداخت خود را به تلگرام پشتیبانی ارسال کنید.
                  </p>
                  <button
                    onClick={handleTelegramClick}
                    className="mt-6 inline-flex items-center gap-2 rounded-2xl bg-gradient-to-l from-primary-600 to-primary-500 px-6 py-3 text-sm font-bold text-white shadow-md transition-transform hover:scale-105"
                  >
                    <Send className="h-4 w-4" strokeWidth={2} />
                    ارسال رسید به تلگرام
                  </button>
                </div>
              ) : (
                <>
                  <div className="mb-5 flex items-center gap-2">
                    <CreditCard className="h-5 w-5 text-primary-600" strokeWidth={1.5} />
                    <h3 className="text-lg font-bold text-gray-800">پرداخت کارت به کارت</h3>
                  </div>

                  <div className="mb-5 rounded-2xl bg-gradient-to-l from-primary-50 to-accent-50 p-4 ring-1 ring-primary-100">
                    <p className="text-xs text-gray-600">مبلغ قابل پرداخت:</p>
                    <p className="mt-1 text-2xl font-extrabold text-primary-700">۳۹۹,۰۰۰ تومان</p>
                    <p className="mt-1 text-[11px] text-gray-500">اشتراک یک ماهه نسخه حرفه‌ای</p>
                  </div>

                  <div className="mb-5 rounded-2xl bg-gray-50 p-4">
                    <p className="mb-2 text-xs font-medium text-gray-600">شماره کارت:</p>
                    <div className="flex items-center justify-between gap-2 rounded-xl bg-white px-3 py-2 ring-1 ring-gray-200">
                      <span className="font-mono text-sm font-bold text-gray-800" dir="ltr">
                        {CARD_NUMBER}
                      </span>
                      <button
                        onClick={handleCopyCard}
                        className="flex items-center gap-1 rounded-lg bg-primary-50 px-2 py-1 text-[10px] font-bold text-primary-700"
                      >
                        {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                        {copied ? 'کپی شد' : 'کپی'}
                      </button>
                    </div>
                    <p className="mt-2 text-xs text-gray-500">
                      به نام: <span className="font-bold text-gray-700">{CARD_HOLDER}</span>
                    </p>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-3">
                    <input
                      type="text"
                      required
                      placeholder="نام و نام خانوادگی *"
                      value={formData.full_name}
                      onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                      className="w-full rounded-xl border border-gray-100 bg-gray-50 px-4 py-2.5 text-sm focus:border-primary-300 focus:bg-white"
                    />
                    <input
                      type="tel"
                      required
                      placeholder="شماره تماس *"
                      dir="ltr"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full rounded-xl border border-gray-100 bg-gray-50 px-4 py-2.5 text-left text-sm focus:border-primary-300 focus:bg-white"
                    />
                    <input
                      type="text"
                      placeholder="آیدی تلگرام (اختیاری)"
                      dir="ltr"
                      value={formData.telegram_username}
                      onChange={(e) => setFormData({ ...formData, telegram_username: e.target.value })}
                      className="w-full rounded-xl border border-gray-100 bg-gray-50 px-4 py-2.5 text-left text-sm focus:border-primary-300 focus:bg-white"
                    />
                    <textarea
                      rows={2}
                      placeholder="شماره پیگیری یا توضیح (اختیاری)"
                      value={formData.receipt_note}
                      onChange={(e) => setFormData({ ...formData, receipt_note: e.target.value })}
                      className="w-full resize-none rounded-xl border border-gray-100 bg-gray-50 px-4 py-2.5 text-sm focus:border-primary-300 focus:bg-white"
                    />

                    {error && <div className="rounded-xl bg-red-50 px-4 py-2 text-xs text-red-600">{error}</div>}

                    <button
                      type="submit"
                      disabled={submitting || !user}
                      className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-primary-600 to-primary-500 py-3.5 text-sm font-bold text-white shadow-md transition-all hover:shadow-lg disabled:opacity-50"
                    >
                      {submitting ? (
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                      ) : (
                        <>
                          ثبت درخواست و ارسال رسید
                          <ArrowLeft className="h-4 w-4" strokeWidth={2} />
                        </>
                      )}
                    </button>

                    {!user && (
                      <p className="text-center text-[11px] text-amber-600">
                        برای ثبت درخواست، ابتدا{' '}
                        <Link to="/auth" className="font-bold underline">
                          وارد حساب
                        </Link>{' '}
                        شوید.
                      </p>
                    )}
                  </form>

                  <p className="mt-4 text-center text-[10px] leading-relaxed text-gray-400">
                    پس از واریز، رسید خود را به تلگرام پشتیبانی ارسال کنید. حداکثر تا ۲۴ ساعت تأیید می‌شود.
                  </p>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}