import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Users, UserCheck } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { getFollowers, getFollowing } from '@/lib/profiles';
import type { Profile } from '@/types';

export function NetworkTab() {
  const { user } = useAuth();
  const [tab, setTab] = useState<'followers' | 'following'>('followers');
  const [followers, setFollowers] = useState<Profile[]>([]);
  const [following, setFollowing] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    Promise.all([getFollowers(user.id), getFollowing(user.id)])
      .then(([f, g]) => {
        setFollowers(f);
        setFollowing(g);
      })
      .finally(() => setLoading(false));
  }, [user]);

  const list = tab === 'followers' ? followers : following;

  return (
    <div className="space-y-4">
      {/* Tabs */}
      <div className="flex gap-2 rounded-2xl bg-white p-1.5 shadow-[0_2px_12px_rgba(0,0,0,0.04)]">
        <motion.button
          onClick={() => setTab('followers')}
          whileHover={{ y: -2 }}
          whileTap={{ scale: 0.97 }}
          className={`flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-medium transition-all ${
            tab === 'followers' ? 'bg-primary-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'
          }`}
        >
          <Users className="h-4 w-4" strokeWidth={1.5} />
          فالوورها
          <span className={`rounded-full px-2 py-0.5 text-xs ${tab === 'followers' ? 'bg-white/20' : 'bg-gray-100'}`}>
            {followers.length}
          </span>
        </motion.button>
        <motion.button
          onClick={() => setTab('following')}
          whileHover={{ y: -2 }}
          whileTap={{ scale: 0.97 }}
          className={`flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-medium transition-all ${
            tab === 'following' ? 'bg-primary-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'
          }`}
        >
          <UserCheck className="h-4 w-4" strokeWidth={1.5} />
          فالووینگ‌ها
          <span className={`rounded-full px-2 py-0.5 text-xs ${tab === 'following' ? 'bg-white/20' : 'bg-gray-100'}`}>
            {following.length}
          </span>
        </motion.button>
      </div>

      {/* List */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary-200 border-t-primary-600" />
        </div>
      ) : list.length === 0 ? (
        <div className="rounded-2xl bg-white p-12 text-center shadow-[0_2px_12px_rgba(0,0,0,0.04)]">
          <Users className="mx-auto mb-3 h-12 w-12 text-gray-300" strokeWidth={1.5} />
          <p className="text-sm text-gray-500">
            {tab === 'followers' ? 'هنوز کسی شما را دنبال نکرده است' : 'هنوز کسی را دنبال نمی‌کنید'}
          </p>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {list.map((p, i) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <Link
                to={`/${p.username}`}
                className="flex items-center gap-3 rounded-2xl bg-white p-4 shadow-[0_2px_12px_rgba(0,0,0,0.04)] transition-shadow hover:shadow-[0_8px_30px_rgba(0,0,0,0.08)]"
              >
                {p.avatar_url ? (
                  <img src={p.avatar_url} alt={p.full_name} className="h-12 w-12 rounded-full object-cover" />
                ) : (
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary-50 text-lg font-bold text-primary-600">
                    {p.full_name.charAt(0) || '?'}
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium text-gray-800">{p.full_name}</p>
                  <p className="truncate text-xs text-gray-500">{p.headline || p.username}</p>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
