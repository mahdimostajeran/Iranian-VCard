import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Sparkles,
  X,
  Link as LinkIcon,
  QrCode,
  Contact,
  Share2,
  Check,
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { getMyProfile } from '@/lib/profiles';
import { downloadVCard } from '@/lib/vcard';
import { QRModal } from '@/components/QRModal';
import type { ProfileWithRelations } from '@/types';

export function QuickShareFab() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [qrOpen, setQrOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [profile, setProfile] = useState<ProfileWithRelations | null>(null);
  const [loading, setLoading] = useState(false);

  if (!user) return null;

  const ensureProfile = async (): Promise<ProfileWithRelations | null> => {
    if (profile) return profile;
    setLoading(true);
    try {
      const p = await getMyProfile();
      if (p) {
        setProfile(p);
        return p;
      }
      return null;
    } catch {
      return null;
    } finally {
      setLoading(false);
    }
  };

  const handleOpen = async () => {
    if (!profile) await ensureProfile();
    setOpen(true);
  };

  const handleCopy = async () => {
    const p = await ensureProfile();
    if (!p?.username) return;
    try {
      await navigator.clipboard.writeText(`${window.location.origin}/${p.username}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
      const input = document.createElement('input');
      input.value = `${window.location.origin}/${p.username}`;
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      document.body.removeChild(input);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleShare = async () => {
    const p = await ensureProfile();
    if (!p?.username) return;
    const url = `${window.location.origin}/${p.username}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: p.full_name,
          text: `کارت ویزیت ${p.full_name}`,
          url,
        });
      } catch {
        // User cancelled
      }
    } else {
      await handleCopy();
    }
  };

  const handleSaveContact = async () => {
    const p = await ensureProfile();
    if (!p) return;
    try {
      await downloadVCard(p, p.social_links, `${window.location.origin}/${p.username}`);
    } catch (err) {
      console.error('[QuickShare] vCard failed:', err);
    }
  };

  const handleQR = async () => {
    await ensureProfile();
    setOpen(false);
    setTimeout(() => setQrOpen(true), 150);
  };

  return (
    <>
      <motion.button
        onClick={handleOpen}
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.95 }}
        className="fixed bottom-20 left-4 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-primary-600 to-accent-600 shadow-[0_8px_24px_rgba(20,184,166,0.4)] md:bottom-6 md:left-6"
        aria-label="اشتراک سریع کارت"
      >
        <Sparkles className="h-6 w-6 text-white" strokeWidth={2} />
      </motion.button>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="fixed bottom-0 left-0 right-0 z-50 rounded-t-3xl bg-white p-5 pb-8 shadow-2xl"
            >
              <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-gray-200" />
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-gray-800">اشتراک سریع کارت</h3>
                  <p className="mt-0.5 text-xs text-gray-400">
                    در هر لحظه کارت خود را به دیگران معرفی کنید
                  </p>
                </div>
                <button
                  onClick={() => setOpen(false)}
                  className="rounded-full p-2 hover:bg-gray-100"
                >
                  <X className="h-5 w-5 text-gray-500" />
                </button>
              </div>

              {loading && !profile ? (
                <div className="flex justify-center py-8">
                  <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary-200 border-t-primary-600" />
                </div>
              ) : !profile ? (
                <div className="rounded-xl bg-amber-50 p-4 text-center text-xs text-amber-800">
                  هنوز کارتی نساخته‌اید. ابتدا از داشبورد کارت خود را بسازید.
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={handleCopy}
                    className="flex flex-col items-center gap-2 rounded-2xl bg-primary-50 p-4 text-primary-700 transition-colors hover:bg-primary-100"
                  >
                    {copied ? <Check className="h-6 w-6" /> : <LinkIcon className="h-6 w-6" />}
                    <span className="text-xs font-bold">{copied ? 'کپی شد!' : 'کپی لینک'}</span>
                  </button>
                  <button
                    onClick={handleQR}
                    className="flex flex-col items-center gap-2 rounded-2xl bg-accent-50 p-4 text-accent-700 transition-colors hover:bg-accent-100"
                  >
                    <QrCode className="h-6 w-6" />
                    <span className="text-xs font-bold">نمایش QR</span>
                  </button>
                  <button
                    onClick={handleSaveContact}
                    className="flex flex-col items-center gap-2 rounded-2xl bg-emerald-50 p-4 text-emerald-700 transition-colors hover:bg-emerald-100"
                  >
                    <Contact className="h-6 w-6" />
                    <span className="text-xs font-bold">ذخیره vCard</span>
                  </button>
                  <button
                    onClick={handleShare}
                    className="flex flex-col items-center gap-2 rounded-2xl bg-amber-50 p-4 text-amber-700 transition-colors hover:bg-amber-100"
                  >
                    <Share2 className="h-6 w-6" />
                    <span className="text-xs font-bold">اشتراک‌گذاری</span>
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {qrOpen && profile && (
        <QRModal
          open={qrOpen}
          onClose={() => setQrOpen(false)}
          url={`${window.location.origin}/${profile.username}`}
        />
      )}
    </>
  );
}