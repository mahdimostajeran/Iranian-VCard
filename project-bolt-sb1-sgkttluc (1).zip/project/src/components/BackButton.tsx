import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Home } from 'lucide-react';

interface Props {
  showHome?: boolean;
  className?: string;
}

export function BackButton({ showHome = true, className = '' }: Props) {
  const navigate = useNavigate();

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <motion.button
        onClick={() => navigate(-1)}
        whileHover={{ scale: 1.03, x: 2 }}
        whileTap={{ scale: 0.97 }}
        className="flex items-center gap-1.5 rounded-xl bg-white px-3.5 py-2 text-xs font-medium text-gray-700 shadow-sm transition-colors hover:bg-gray-50"
      >
        <ArrowRight className="h-3.5 w-3.5" strokeWidth={1.5} />
        بازگشت
      </motion.button>
      {showHome && (
        <Link
          to="/"
          className="flex items-center gap-1.5 rounded-xl bg-white px-3.5 py-2 text-xs font-medium text-gray-700 shadow-sm transition-colors hover:bg-gray-50"
        >
          <Home className="h-3.5 w-3.5" strokeWidth={1.5} />
          صفحه اصلی
        </Link>
      )}
    </div>
  );
}