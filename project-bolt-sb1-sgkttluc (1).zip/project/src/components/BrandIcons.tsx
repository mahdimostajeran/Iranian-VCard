import type { IconType } from 'react-icons';
import {
  FiLinkedin,
  FiInstagram,
  FiSend,
  FiMessageCircle,
  FiTwitter,
  FiYoutube,
  FiFacebook,
  FiGithub,
  FiMail,
  FiGlobe,
  FiLink,
  FiMessageSquare,
  FiRadio,
  FiMusic,
} from 'react-icons/fi';
import type { Platform } from '@/types';

export const brandIcons: Record<Platform, IconType> = {
  linkedin: FiLinkedin,
  instagram: FiInstagram,
  telegram: FiSend,
  whatsapp: FiMessageCircle,
  twitter: FiTwitter,
  youtube: FiYoutube,
  facebook: FiFacebook,
  tiktok: FiMusic,
  github: FiGithub,
  email: FiMail,
  website: FiGlobe,
  eitaa: FiSend,
  bale: FiSend,
  rubika: FiMessageSquare,
  soroush: FiRadio,
  igap: FiLink,
  custom: FiLink,
};

export const brandLabels: Record<Platform, string> = {
  linkedin: 'لینکدین',
  instagram: 'اینستاگرام',
  telegram: 'تلگرام',
  whatsapp: 'واتساپ',
  twitter: 'توییتر (X)',
  youtube: 'یوتیوب',
  facebook: 'فیسبوک',
  tiktok: 'تیک‌تاک',
  github: 'گیت‌هاب',
  email: 'ایمیل',
  website: 'وب‌سایت',
  eitaa: 'ایتا',
  bale: 'بله',
  rubika: 'روبیکا',
  soroush: 'سروش',
  igap: 'آی‌گپ',
  custom: 'لینک دلخواه',
};

interface BrandIconProps {
  platform: Platform;
  size?: number;
  className?: string;
}

export function BrandIcon({ platform, size = 20, className = '' }: BrandIconProps) {
  const Icon = brandIcons[platform];
  if (!Icon) return null;
  return <Icon size={size} className={className} />;
}