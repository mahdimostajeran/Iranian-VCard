import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import {
  Mail,
  Phone,
  Globe,
  QrCode,
  Contact,
  Building2,
  StickyNote,
  Save,
  X,
  Bookmark,
} from 'lucide-react';
import { BrandIcon, brandLabels } from '@/components/BrandIcons';
import type { ProfileWithRelations } from '@/types';

interface Card3DProps {
  profile: ProfileWithRelations;
  onSaveContact?: () => void;
  onShowQR?: () => void;
  size?: 'default' | 'large';
}

const NOTE_STORAGE_KEY = (profileId: string) => `kartin_note_${profileId}`;
const BOOKMARK_KEY = (profileId: string) => `kartin_bookmark_${profileId}`;

export function Card3D({
  profile,
  onSaveContact,
  onShowQR,
  size = 'default',
}: Card3DProps) {
  const [flipped, setFlipped] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [note, setNote] = useState('');
  const [noteSaved, setNoteSaved] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const hasAnimatedRef = useRef(false);

  const handleFlip = () => setFlipped((v) => !v);

  const isCorporate = profile.template_type === 'corporate';

  useEffect(() => {
    try {
      const saved = localStorage.getItem(NOTE_STORAGE_KEY(profile.id));
      if (saved) setNote(saved);
      const bookmark = localStorage.getItem(BOOKMARK_KEY(profile.id));
      if (bookmark === 'true') setIsBookmarked(true);
    } catch {
      // ignore
    }
  }, [profile.id]);

  useEffect(() => {
    if (hasAnimatedRef.current) return;
    hasAnimatedRef.current = true;

    const timer = setTimeout(() => {
      setFlipped(true);
      setTimeout(() => setFlipped(false), 900);
      setShowHint(true);
      setTimeout(() => setShowHint(false), 6000);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  const handleSaveNote = () => {
    try {
      localStorage.setItem(NOTE_STORAGE_KEY(profile.id), note);
      setNoteSaved(true);
      setTimeout(() => setNoteSaved(false), 2000);
    } catch {
      // ignore
    }
  };

  const handleClearNote = () => {
    setNote('');
    try {
      localStorage.removeItem(NOTE_STORAGE_KEY(profile.id));
    } catch {
      // ignore
    }
  };

  const handleToggleBookmark = () => {
    const newState = !isBookmarked;
    setIsBookmarked(newState);
    try {
      localStorage.setItem(BOOKMARK_KEY(profile.id), newState ? 'true' : 'false');
    } catch {
      // ignore
    }
  };

  const frontBg = isCorporate
    ? 'from-slate-800 via-slate-900 to-primary-900'
    : 'from-primary-600 via-primary-700 to-accent-700';

  const backBg = isCorporate
    ? 'from-primary-900 via-slate-900 to-slate-800'
    : 'from-accent-700 via-primary-700 to-primary-600';

  const containerMaxWidth =
    size === 'large'
      ? 'max-w-[340px] sm:max-w-lg md:max-w-xl lg:max-w-2xl'
      : 'max-w-[320px] sm:max-w-md md:max-w-lg lg:max-w-2xl';

  const aspectRatio = size === 'large' ? '1.7 / 1' : '1.6 / 1';

  return (
    <div className="flex w-full flex-col items-center gap-4 sm:gap-6">
      <div className={`w-full ${containerMaxWidth}`} style={{ perspective: '1600px' }}>
        <motion.div
          className="relative w-full cursor-pointer"
          style={{ transformStyle: 'preserve-3d' }}
          animate={{ rotateY: flipped ? 180 : 0 }}
          transition={{ duration: 0.9, ease: [0.4, 0, 0.2, 1] }}
          onClick={handleFlip}
        >
          {/* FRONT */}
          <div
            className="relative w-full"
            style={{
              aspectRatio,
              backfaceVisibility: 'hidden',
              WebkitBackfaceVisibility: 'hidden',
            }}
          >
            <div
              className={`relative h-full w-full overflow-hidden rounded-2xl bg-gradient-to-br ${frontBg} p-4 shadow-[0_20px_60px_rgba(0,0,0,0.25)] sm:rounded-3xl sm:p-6 md:p-8 lg:p-9`}
            >
              <div
                className="absolute inset-0 opacity-[0.08]"
                style={{
                  backgroundImage:
                    'radial-gradient(circle at 20% 30%, white 1px, transparent 1px), radial-gradient(circle at 80% 70%, white 1px, transparent 1px)',
                  backgroundSize: '32px 32px, 32px 32px',
                }}
              />
              <div className="absolute -top-20 -right-20 h-48 w-48 rounded-full bg-white/5 blur-3xl sm:h-64 sm:w-64" />
              <div className="absolute -bottom-20 -left-20 h-48 w-48 rounded-full bg-white/5 blur-3xl sm:h-64 sm:w-64" />

              <div className="relative flex h-full flex-col">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    <div className="flex h-6 w-6 items-center justify-center rounded-md bg-white/15 backdrop-blur-sm sm:h-8 sm:w-8 sm:rounded-lg">
                      <span className="text-[10px] font-extrabold text-white sm:text-sm">ک</span>
                    </div>
                    <span className="text-[10px] font-semibold text-white/85 sm:text-sm">کارتین</span>
                  </div>
                  <span className="rounded-full bg-white/10 px-2 py-0.5 text-[8px] font-medium text-white/85 backdrop-blur-sm sm:px-3 sm:py-1 sm:text-[11px]">
                    {isCorporate ? 'کارت شرکتی' : 'کارت شخصی'}
                  </span>
                </div>

                <div className="flex flex-1 items-center gap-3 py-3 sm:gap-4 sm:py-4 md:gap-5">
                  <div className="shrink-0">
                    {profile.avatar_url ? (
                      <img
                        src={profile.avatar_url}
                        alt={profile.full_name}
                        className="h-16 w-16 rounded-xl object-cover shadow-2xl ring-2 ring-white/40 sm:h-20 sm:w-20 sm:rounded-2xl md:h-24 md:w-24 lg:h-28 lg:w-28"
                      />
                    ) : (
                      <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-white/25 text-2xl font-bold text-white shadow-2xl ring-2 ring-white/40 backdrop-blur-sm sm:h-20 sm:w-20 sm:rounded-2xl sm:text-3xl md:h-24 md:w-24 md:text-4xl lg:h-28 lg:w-28 lg:text-5xl">
                        {profile.full_name.charAt(0)}
                      </div>
                    )}
                  </div>

                  <div className="min-w-0 flex-1 text-right" dir="rtl">
                    <h2 className="truncate text-base font-extrabold leading-tight text-white drop-shadow-md sm:text-xl md:text-2xl lg:text-3xl">
                      {profile.full_name || 'بدون نام'}
                    </h2>
                    {profile.headline && (
                      <p className="mt-1 truncate text-[11px] font-medium text-white/90 sm:mt-1.5 sm:text-sm md:text-base lg:text-lg">
                        {profile.headline}
                      </p>
                    )}
                    {profile.company && (
                      <div className="mt-1 flex items-center gap-1 sm:mt-1.5 sm:gap-1.5">
                        <Building2
                          className="h-3 w-3 shrink-0 text-white/70 sm:h-3.5 sm:w-3.5 md:h-4 md:w-4"
                          strokeWidth={1.8}
                        />
                        <p className="truncate text-[10px] font-medium text-white/85 sm:text-xs md:text-sm lg:text-base">
                          {profile.company}
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-end justify-between gap-2">
                  <div className="min-w-0 flex-1 space-y-1 text-left sm:space-y-1.5" dir="ltr">
                    {profile.phone && (
                      <a
                        href={`tel:${profile.phone}`}
                        onClick={(e) => e.stopPropagation()}
                        className="group flex items-center gap-1.5 text-[10px] text-white/95 transition-colors hover:text-white sm:gap-2 sm:text-xs md:text-sm"
                      >
                        <Phone
                          className="h-3 w-3 shrink-0 text-white/70 transition-transform group-hover:scale-110 sm:h-3.5 sm:w-3.5 md:h-4 md:w-4"
                          strokeWidth={1.8}
                        />
                        <span className="truncate font-mono font-medium underline-offset-4 group-hover:underline">
                          {profile.phone}
                        </span>
                      </a>
                    )}
                    {profile.email && (
                      <a
                        href={`mailto:${profile.email}`}
                        onClick={(e) => e.stopPropagation()}
                        className="group flex items-center gap-1.5 text-[10px] text-white/95 transition-colors hover:text-white sm:gap-2 sm:text-xs md:text-sm"
                      >
                        <Mail
                          className="h-3 w-3 shrink-0 text-white/70 transition-transform group-hover:scale-110 sm:h-3.5 sm:w-3.5 md:h-4 md:w-4"
                          strokeWidth={1.8}
                        />
                        <span className="truncate font-medium underline-offset-4 group-hover:underline">
                          {profile.email}
                        </span>
                      </a>
                    )}
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleBookmark();
                    }}
                    className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-md backdrop-blur-sm transition-all sm:h-9 sm:w-9 sm:rounded-lg ${
                      isBookmarked
                        ? 'bg-amber-400 text-amber-900'
                        : 'bg-white/15 text-white hover:bg-white/25'
                    }`}
                    title={isBookmarked ? 'حذف از بوکمارک' : 'افزودن به بوکمارک'}
                  >
                    <Bookmark
                      className="h-3.5 w-3.5 sm:h-4 sm:w-4"
                      strokeWidth={1.8}
                      fill={isBookmarked ? 'currentColor' : 'none'}
                    />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* BACK */}
          <div
            className="absolute inset-0 w-full"
            style={{
              aspectRatio,
              backfaceVisibility: 'hidden',
              WebkitBackfaceVisibility: 'hidden',
              transform: 'rotateY(180deg)',
            }}
          >
            <div
              className={`relative h-full w-full overflow-hidden rounded-2xl bg-gradient-to-br ${backBg} p-4 shadow-[0_20px_60px_rgba(0,0,0,0.25)] sm:rounded-3xl sm:p-6 md:p-8 lg:p-9`}
            >
              <div
                className="absolute inset-0 opacity-[0.07]"
                style={{
                  backgroundImage:
                    'linear-gradient(45deg, white 25%, transparent 25%, transparent 75%, white 75%), linear-gradient(45deg, white 25%, transparent 25%, transparent 75%, white 75%)',
                  backgroundSize: '16px 16px',
                  backgroundPosition: '0 0, 8px 8px',
                }}
              />

              <div className="relative flex h-full flex-col">
                <div className="flex-1">
                  <p className="mb-1.5 text-[9px] font-bold tracking-wide text-white/60 sm:mb-2 sm:text-xs md:text-sm">
                    درباره من
                  </p>
                  {profile.bio ? (
                    <p className="line-clamp-3 text-xs leading-relaxed text-white/95 sm:line-clamp-4 sm:text-sm md:text-base lg:text-lg">
                      {profile.bio}
                    </p>
                  ) : (
                    <p className="text-xs leading-relaxed text-white/70 sm:text-sm md:text-base">
                      توضیحاتی ثبت نشده است.
                    </p>
                  )}

                  {profile.skills.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1 sm:mt-3 sm:gap-1.5 md:mt-4 md:gap-2">
                      {profile.skills.slice(0, 4).map((skill) => (
                        <span
                          key={skill.id}
                          className="rounded-full bg-white/15 px-2 py-0.5 text-[9px] font-medium text-white/90 backdrop-blur-sm sm:px-2.5 sm:py-1 sm:text-[11px] md:px-3 md:text-xs lg:text-sm"
                        >
                          {skill.skill_name}
                        </span>
                      ))}
                      {profile.skills.length > 4 && (
                        <span className="rounded-full bg-white/15 px-2 py-0.5 text-[9px] font-medium text-white/90 backdrop-blur-sm sm:px-2.5 sm:text-[11px] md:px-3 md:text-xs">
                          +{profile.skills.length - 4}
                        </span>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex items-end justify-between gap-2">
                  <div className="flex flex-wrap gap-1.5 sm:gap-2 md:gap-2.5">
                    {profile.website && (
                      <a
                        href={
                          profile.website.startsWith('http')
                            ? profile.website
                            : `https://${profile.website}`
                        }
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex h-7 w-7 items-center justify-center rounded-md bg-white/15 text-white backdrop-blur-sm transition-all hover:scale-110 hover:bg-white/25 sm:h-8 sm:w-8 sm:rounded-lg md:h-10 md:w-10"
                        title="وب‌سایت"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Globe className="h-3.5 w-3.5 sm:h-4 sm:w-4 md:h-5 md:w-5" strokeWidth={1.6} />
                      </a>
                    )}
                    {profile.social_links.map((link) => (
                      <a
                        key={link.id}
                        href={link.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex h-7 w-7 items-center justify-center rounded-md bg-white/15 text-white backdrop-blur-sm transition-all hover:scale-110 hover:bg-white/25 sm:h-8 sm:w-8 sm:rounded-lg md:h-10 md:w-10"
                        title={link.custom_label || brandLabels[link.platform]}
                        onClick={(e) => e.stopPropagation()}
                      >
                        <BrandIcon platform={link.platform} size={16} />
                      </a>
                    ))}
                  </div>

                  {onShowQR && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onShowQR();
                      }}
                      className="flex shrink-0 items-center gap-1 rounded-md bg-white/15 px-2 py-1.5 text-[9px] font-bold text-white backdrop-blur-sm transition-all hover:scale-105 hover:bg-white/25 sm:rounded-lg sm:px-3 sm:py-2 sm:text-[11px] md:px-4 md:py-2.5 md:text-sm"
                    >
                      <QrCode className="h-3 w-3 sm:h-4 sm:w-4 md:h-5 md:w-5" strokeWidth={2} />
                      QR
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {showHint && (
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          className="text-center text-xs font-medium text-primary-600 sm:text-sm"
        >
          👆 روی کارت ضربه بزنید تا بچرخد
        </motion.p>
      )}

      {/* یادداشت شخصی */}
      <div className="w-full max-w-md rounded-2xl bg-white p-4 shadow-[0_2px_12px_rgba(0,0,0,0.04)] sm:p-5">
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-50">
              <StickyNote className="h-4 w-4 text-amber-600" strokeWidth={1.8} />
            </div>
            <div>
              <p className="text-xs font-bold text-gray-800 sm:text-sm">یادداشت شخصی</p>
              <p className="text-[10px] text-gray-400 sm:text-xs">فقط روی گوشی شما ذخیره می‌شود</p>
            </div>
          </div>
          {note && (
            <button
              onClick={handleClearNote}
              className="rounded-lg bg-red-50 p-1.5 text-red-600 transition-colors hover:bg-red-100"
              title="پاک کردن"
            >
              <X className="h-3.5 w-3.5" strokeWidth={2} />
            </button>
          )}
        </div>

        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="یادداشتی برای خودتان بنویسید..."
          rows={3}
          className="w-full resize-none rounded-xl border border-gray-100 bg-gray-50 px-3 py-2.5 text-xs text-gray-700 transition-all focus:border-primary-300 focus:bg-white focus:shadow-[0_0_0_3px_rgba(20,184,166,0.1)] sm:text-sm"
        />

        <button
          onClick={handleSaveNote}
          disabled={!note.trim()}
          className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-amber-500 py-2.5 text-xs font-bold text-white shadow-md transition-all hover:bg-amber-600 disabled:opacity-50 sm:text-sm"
        >
          {noteSaved ? (
            <>
              <Save className="h-3.5 w-3.5 sm:h-4 sm:w-4" strokeWidth={2} />
              ذخیره شد
            </>
          ) : (
            <>
              <Save className="h-3.5 w-3.5 sm:h-4 sm:w-4" strokeWidth={2} />
              ذخیره یادداشت
            </>
          )}
        </button>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
        {onSaveContact && (
          <motion.button
            onClick={onSaveContact}
            whileHover={{ y: -2, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="flex items-center gap-1.5 rounded-xl bg-primary-600 px-3.5 py-2 text-xs font-medium text-white shadow-md transition-colors hover:bg-primary-700 sm:gap-2 sm:px-5 sm:py-2.5 sm:text-sm md:px-6 md:py-3 md:text-base"
          >
            <Contact className="h-3.5 w-3.5 sm:h-4 sm:w-4 md:h-5 md:w-5" strokeWidth={1.5} />
            ذخیره در مخاطبین
          </motion.button>
        )}
        {onShowQR && (
          <motion.button
            onClick={onShowQR}
            whileHover={{ y: -2, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="flex items-center gap-1.5 rounded-xl bg-white px-3.5 py-2 text-xs font-medium text-gray-700 shadow-sm transition-shadow hover:shadow-md sm:gap-2 sm:px-5 sm:py-2.5 sm:text-sm md:px-6 md:py-3 md:text-base"
          >
            <QrCode className="h-3.5 w-3.5 sm:h-4 sm:w-4 md:h-5 md:w-5" strokeWidth={1.5} />
            کد QR
          </motion.button>
        )}
      </div>

      <p className="text-center text-[10px] text-gray-400 sm:text-xs md:text-sm">
        روی کارت کلیک کنید تا ۳۶۰ درجه بچرخد
      </p>
    </div>
  );
}