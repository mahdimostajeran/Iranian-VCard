import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Eye,
  Download,
  TrendingUp,
  BarChart3,
  Crown,
  Lock,
  MapPin,
  Monitor,
  Users,
  Calendar,
  ArrowUpRight,
  Activity,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import {
  getAnalytics,
  getPageViewDetails,
  type DailyViewData,
  type PageViewDetail,
} from '@/lib/analytics';

interface Props {
  profileId: string;
  isPremium: boolean;
}

// نام کامل روزهای هفته — شنبه اول
const WEEK_DAYS_FA = [
  'شنبه',
  'یکشنبه',
  'دوشنبه',
  'سه‌شنبه',
  'چهارشنبه',
  'پنجشنبه',
  'جمعه',
];

/**
 * تبدیل تاریخ ISO به ایندکس روز هفته فارسی
 * getDay() در JS: 0=یکشنبه, 1=دوشنبه, ..., 6=شنبه
 * در تقویم ما: 0=شنبه, 1=یکشنبه, ..., 6=جمعه
 */
function getPersianDayIndex(isoDate: string): number {
  const jsDay = new Date(isoDate).getDay(); // 0=Sun, 6=Sat
  // تبدیل: Sat(6)→0, Sun(0)→1, Mon(1)→2, ..., Fri(5)→6
  return (jsDay + 1) % 7;
}

const FREE_VIEWS_LIMIT = 3;

export function AnalyticsTab({ profileId, isPremium }: Props) {
  const [data, setData] = useState<{
    totalViews: number;
    totalDownloads: number;
    todayViews: number;
    dailyViews: DailyViewData[];
  } | null>(null);
  const [viewDetails, setViewDetails] = useState<PageViewDetail[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      getAnalytics(profileId),
      isPremium ? getPageViewDetails(profileId, 20) : Promise.resolve([]),
    ])
      .then(([analytics, details]) => {
        setData(analytics);
        setViewDetails(details);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [profileId, isPremium]);

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary-200 border-t-primary-600" />
      </div>
    );
  }

  if (!data) return null;

  const maxViews = Math.max(...data.dailyViews.map((d) => d.views), 1);
  const totalWeekViews = data.dailyViews.reduce((sum, d) => sum + d.views, 0);

  const stats = [
    {
      label: 'بازدید کل',
      value: data.totalViews,
      icon: Eye,
      color: 'from-primary-400 to-primary-600',
      bg: 'bg-primary-50',
    },
    {
      label: 'ذخیره در مخاطبین',
      value: data.totalDownloads,
      icon: Download,
      color: 'from-accent-400 to-accent-600',
      bg: 'bg-accent-50',
    },
    {
      label: 'بازدید امروز',
      value: data.todayViews,
      icon: TrendingUp,
      color: 'from-emerald-400 to-emerald-600',
      bg: 'bg-emerald-50',
    },
  ];

  const formatDate = (iso: string) => {
    try {
      return new Date(iso).toLocaleDateString('fa-IR', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return iso;
    }
  };

  return (
    <div className="space-y-6">
      {/* ====== Stat cards ====== */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="relative overflow-hidden rounded-2xl bg-white p-6 shadow-[0_2px_12px_rgba(0,0,0,0.04)]"
            >
              <div className="mb-4 flex items-center justify-between">
                <div
                  className={`flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${stat.color} shadow-md`}
                >
                  <Icon className="h-5 w-5 text-white" strokeWidth={1.8} />
                </div>
                <ArrowUpRight
                  className="h-4 w-4 text-gray-300"
                  strokeWidth={2}
                />
              </div>
              <p className="text-3xl font-extrabold text-gray-800">
                {stat.value.toLocaleString('fa-IR')}
              </p>
              <p className="mt-1.5 text-sm font-medium text-gray-500">
                {stat.label}
              </p>
            </motion.div>
          );
        })}
      </div>

      {/* ====== Chart — بازدید ۷ روز اخیر ====== */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="rounded-2xl bg-white p-6 shadow-[0_2px_12px_rgba(0,0,0,0.04)] sm:p-8"
      >
        {/* Header */}
        <div className="mb-8 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="flex items-center gap-2 text-base font-bold text-gray-800">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-50">
                <BarChart3 className="h-4 w-4 text-primary-600" strokeWidth={2} />
              </div>
              بازدید ۷ روز اخیر
            </h3>
            <p className="mr-10 mt-1 text-xs text-gray-400">
              مجموع این هفته: {totalWeekViews.toLocaleString('fa-IR')} بازدید
            </p>
          </div>
          <div className="flex items-center gap-2 rounded-lg bg-primary-50 px-3 py-1.5">
            <Activity className="h-3.5 w-3.5 text-primary-600" strokeWidth={2} />
            <span className="text-xs font-bold text-primary-700">
              میانگین روزانه: {Math.round(totalWeekViews / 7).toLocaleString('fa-IR')}
            </span>
          </div>
        </div>

        {/* Chart */}
        <div className="flex items-end justify-between gap-2 sm:gap-4" style={{ height: '220px' }}>
          {data.dailyViews.map((day, i) => {
            const dayIndex = getPersianDayIndex(day.date);
            const dayName = WEEK_DAYS_FA[dayIndex];
            const heightPct = (day.views / maxViews) * 100;
            const isToday = i === data.dailyViews.length - 1;

            return (
              <div key={day.date} className="flex flex-1 flex-col items-center gap-2">
                {/* Value */}
                <motion.span
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + i * 0.05 }}
                  className={`text-sm font-extrabold ${
                    day.views > 0 ? 'text-primary-700' : 'text-gray-300'
                  }`}
                >
                  {day.views.toLocaleString('fa-IR')}
                </motion.span>

                {/* Bar */}
                <div className="relative flex w-full flex-1 items-end">
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: `${Math.max(heightPct, 4)}%` }}
                    transition={{
                      delay: 0.4 + i * 0.08,
                      type: 'spring',
                      stiffness: 100,
                      damping: 15,
                    }}
                    className={`w-full rounded-t-xl transition-colors ${
                      isToday
                        ? 'bg-gradient-to-t from-accent-600 to-accent-400 shadow-[0_-4px_20px_rgba(14,165,233,0.3)]'
                        : 'bg-gradient-to-t from-primary-600 to-primary-400'
                    }`}
                    style={{ minHeight: '6px' }}
                  />
                </div>

                {/* Day name */}
                <div className="flex flex-col items-center gap-0.5">
                  <span
                    className={`text-xs font-bold ${
                      isToday ? 'text-accent-700' : 'text-gray-600'
                    }`}
                  >
                    {dayName}
                  </span>
                  {isToday && (
                    <span className="rounded-full bg-accent-100 px-2 py-0.5 text-[9px] font-bold text-accent-700">
                      امروز
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </motion.div>

      {/* ====== بازدیدکنندگان اخیر ====== */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="rounded-2xl bg-white p-6 shadow-[0_2px_12px_rgba(0,0,0,0.04)] sm:p-8"
      >
        <div className="mb-5 flex items-center justify-between">
          <h3 className="flex items-center gap-2 text-base font-bold text-gray-800">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-50">
              <Users className="h-4 w-4 text-primary-600" strokeWidth={2} />
            </div>
            بازدیدکنندگان اخیر
          </h3>
          {!isPremium && (
            <span className="flex items-center gap-1 rounded-full bg-amber-50 px-3 py-1 text-[10px] font-bold text-amber-700">
              <Lock className="h-3 w-3" strokeWidth={2.5} />
              ویژه
            </span>
          )}
        </div>

        {isPremium ? (
          viewDetails.length > 0 ? (
            <div className="space-y-2.5">
              {viewDetails.map((view, i) => (
                <motion.div
                  key={view.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="flex items-center gap-3 rounded-xl bg-gray-50 p-3.5 transition-colors hover:bg-gray-100"
                >
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary-100 text-xs font-bold text-primary-700">
                    {view.viewer_device === 'موبایل' ? '📱' : view.viewer_device === 'تبلت' ? '📲' : '💻'}
                  </div>
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-3 text-xs text-gray-600">
                      {view.viewer_city && (
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" strokeWidth={1.8} />
                          {view.viewer_city}
                        </span>
                      )}
                      {view.viewer_device && (
                        <span className="flex items-center gap-1">
                          <Monitor className="h-3 w-3" strokeWidth={1.8} />
                          {view.viewer_device}
                        </span>
                      )}
                      <span className="flex items-center gap-1 text-gray-400">
                        <Calendar className="h-3 w-3" strokeWidth={1.8} />
                        {formatDate(view.created_at)}
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="rounded-xl bg-gray-50 py-12 text-center">
              <Users className="mx-auto mb-3 h-10 w-10 text-gray-300" strokeWidth={1} />
              <p className="text-sm text-gray-400">
                هنوز جزئیات بازدیدکننده‌ای ثبت نشده است.
              </p>
            </div>
          )
        ) : (
          <>
            {/* نمایش محدود ۳ مورد */}
            {data.totalViews > 0 && (
              <div className="mb-4 space-y-2.5">
                {[1, 2, 3]
                  .slice(0, Math.min(FREE_VIEWS_LIMIT, data.totalViews))
                  .map((_, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-3 rounded-xl bg-gray-50 p-3.5 opacity-50"
                    >
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gray-200 text-xs font-bold text-gray-400">
                        ؟
                      </div>
                      <div className="flex-1 space-y-1.5">
                        <div className="h-3 w-32 rounded bg-gray-200" />
                        <div className="h-2.5 w-20 rounded bg-gray-100" />
                      </div>
                    </div>
                  ))}
              </div>
            )}

            {/* Locked overlay */}
            <div className="rounded-2xl bg-gradient-to-l from-amber-50 to-orange-50 p-6 text-center ring-1 ring-amber-100">
              <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-amber-100">
                <Lock className="h-6 w-6 text-amber-600" strokeWidth={1.8} />
              </div>
              <p className="text-sm font-bold text-gray-800">
                مشاهده جزئیات بازدیدکنندگان
              </p>
              <p className="mx-auto mt-2 max-w-sm text-xs leading-relaxed text-gray-600">
                ببینید بازدیدکنندگان از چه شهری هستند، با چه دستگاهی وارد شده‌اند و چه زمانی
                از کارت شما بازدید کرده‌اند.
              </p>
              <Link
                to="/pricing"
                className="mt-4 inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 px-5 py-2.5 text-xs font-bold text-white shadow-md transition-transform hover:scale-105"
              >
                <Crown className="h-3.5 w-3.5" strokeWidth={2} />
                ارتقا به نسخه ویژه
              </Link>
            </div>
          </>
        )}
      </motion.div>
    </div>
  );
}