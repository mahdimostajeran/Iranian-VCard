import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Check, Crown, Lock } from 'lucide-react';
import { generateCardContent, type AIGenerateResult } from '@/lib/ai';
import { upsertProfile } from '@/lib/profiles';
import type { ProfileWithRelations } from '@/types';

export function AIBuilderTab({ profile }: { profile: ProfileWithRelations }) {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AIGenerateResult | null>(null);
  const [applied, setApplied] = useState(false);
  const [error, setError] = useState('');

  if (!profile.is_premium) {
    return (
      <div className="space-y-6">
        <div className="rounded-2xl bg-white p-8 shadow-[0_2px_12px_rgba(0,0,0,0.04)] sm:p-10">
          <div className="flex flex-col items-center text-center">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: 'spring', stiffness: 200, damping: 15 }}
              className="mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 shadow-lg"
            >
              <Crown className="h-8 w-8 text-white" strokeWidth={1.5} />
            </motion.div>

            <h3 className="text-lg font-bold text-gray-800">صفحه‌ساز هوشمند</h3>
            <p className="mt-2 max-w-xs text-sm leading-relaxed text-gray-500">
              با هوش مصنوعی، فقط چند جمله درباره خودتان بنویسید و تیتر و بیوگرافی حرفه‌ای برای کارت ویزیت خود به‌صورت خودکار تولید کنید.
            </p>

            <div className="mt-6 flex items-center gap-2 rounded-xl bg-primary-50 px-4 py-2.5 text-xs font-medium text-primary-700">
              <Lock className="h-3.5 w-3.5" strokeWidth={1.5} />
              این ویژگی مخصوص کاربران نسخه ویژه است
            </div>

            <motion.a
              href="mailto:info@example.com?subject=ارتقا به نسخه ویژه"
              whileHover={{ scale: 1.03, y: -2 }}
              whileTap={{ scale: 0.97 }}
              className="mt-6 flex items-center gap-2 rounded-xl bg-gradient-to-l from-amber-500 to-amber-600 px-6 py-3 text-sm font-bold text-white shadow-lg transition-shadow hover:shadow-xl"
            >
              <Crown className="h-4 w-4" strokeWidth={1.5} />
              ارتقا به نسخه ویژه
            </motion.a>
          </div>
        </div>
      </div>
    );
  }

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setError('');
    setResult(null);
    try {
      const r = await generateCardContent(prompt);
      setResult(r);
    } catch (err: any) {
      setError(err.message || 'خطا در تولید محتوا');
    } finally {
      setLoading(false);
    }
  };

  const handleApply = async () => {
    if (!result) return;
    setApplied(true);
    setError('');
    try {
      await upsertProfile({ headline: result.headline, bio: result.bio });
      setTimeout(() => setApplied(false), 3000);
    } catch {
      setError('خطا در ذخیره');
    }
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl bg-white p-6 shadow-[0_2px_12px_rgba(0,0,0,0.04)] sm:p-8">
        <div className="mb-4 flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 shadow-md">
            <Sparkles className="h-5 w-5 text-white" strokeWidth={1.5} />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-800">صفحه‌ساز هوشمند</h3>
            <p className="text-xs text-gray-500">تولید محتوا با هوش مصنوعی (نسخه بتا)</p>
          </div>
        </div>

        <label className="mb-2 block text-xs font-medium text-gray-600">
          درباره خود یا حرفه‌تان بنویسید
        </label>
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          rows={4}
          className="w-full resize-none rounded-xl border border-gray-100 bg-gray-50 px-4 py-3 text-sm text-gray-800 transition-all focus:border-primary-300 focus:bg-white focus:shadow-[0_0_0_3px_rgba(20,184,166,0.1)]"
          placeholder="مثال: من مشاور املاک در تهران هستم و در زمینه خرید و فروش آپارتمان تخصص دارم..."
        />

        <motion.button
          onClick={handleGenerate}
          disabled={loading || !prompt.trim()}
          whileHover={{ scale: 1.01, y: -2 }}
          whileTap={{ scale: 0.98 }}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-primary-600 py-3 text-sm font-bold text-white shadow-md transition-colors hover:bg-primary-700 disabled:opacity-50"
        >
          {loading ? (
            <>
              <div className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white" />
              در حال تولید...
            </>
          ) : (
            <>
              <Sparkles className="h-5 w-5" strokeWidth={1.5} />
              تولید محتوا
            </>
          )}
        </motion.button>

        {error && (
          <p className="mt-3 text-xs text-red-500">{error}</p>
        )}
      </div>

      <AnimatePresence>
        {result && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            className="rounded-2xl bg-white p-6 shadow-[0_8px_30px_rgba(0,0,0,0.06)] sm:p-8"
          >
            <div className="mb-4 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary-600" strokeWidth={1.5} />
              <h4 className="text-sm font-bold text-gray-800">نتیجه تولید شده</h4>
            </div>

            <div className="space-y-4">
              <div>
                <p className="mb-1 text-xs font-medium text-gray-500">عنوان شغلی</p>
                <p className="rounded-xl bg-primary-50 px-4 py-2.5 text-sm font-medium text-primary-700">
                  {result.headline}
                </p>
              </div>
              <div>
                <p className="mb-1 text-xs font-medium text-gray-500">بیوگرافی</p>
                <p className="rounded-xl bg-gray-50 px-4 py-2.5 text-sm leading-relaxed text-gray-700">
                  {result.bio}
                </p>
              </div>
            </div>

            <motion.button
              onClick={handleApply}
              whileHover={{ scale: 1.01, y: -2 }}
              whileTap={{ scale: 0.98 }}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-primary-600 py-3 text-sm font-bold text-white shadow-md transition-colors hover:bg-primary-700"
            >
              {applied ? (
                <>
                  <Check className="h-5 w-5" strokeWidth={1.5} />
                  اعمال شد!
                </>
              ) : (
                'اعمال روی کارت'
              )}
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
