import { motion, AnimatePresence } from 'framer-motion';
import { X, Copy, Check, ExternalLink } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { useState, useEffect } from 'react';

interface Props {
  open: boolean;
  onClose: () => void;
  url: string;
}

export function QRModal({ open, onClose, url }: Props) {
  const [copied, setCopied] = useState(false);
  const [normalizedUrl, setNormalizedUrl] = useState(url);

  // Ensure the URL always starts with https:// so QR scanners auto-open it
  useEffect(() => {
    if (!url) return;
    if (/^https?:\/\//i.test(url)) {
      setNormalizedUrl(url);
    } else {
      setNormalizedUrl(`https://${url}`);
    }
  }, [url]);

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(normalizedUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback for browsers that block clipboard
      const input = document.createElement('input');
      input.value = normalizedUrl;
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      document.body.removeChild(input);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
        >
          <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={onClose} />
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            className="relative z-10 w-full max-w-sm rounded-3xl bg-white p-6 shadow-[0_20px_60px_rgba(0,0,0,0.15)]"
          >
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-bold text-gray-800">کد QR کارت</h3>
              <motion.button
                onClick={onClose}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="rounded-full p-2 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-600"
                aria-label="بستن"
              >
                <X className="h-5 w-5" strokeWidth={1.5} />
              </motion.button>
            </div>

            <div className="flex flex-col items-center gap-4">
              <div className="rounded-2xl bg-white p-4 shadow-[0_4px_20px_rgba(20,184,166,0.1)]">
                <QRCodeSVG
                  value={normalizedUrl}
                  size={200}
                  level="H"
                  bgColor="#ffffff"
                  fgColor="#0f766e"
                />
              </div>
              <p className="text-center text-sm text-gray-500">
                این کد را با دوربین گوشی اسکن کنید تا کارت ویزیت باز شود
              </p>

              <div className="flex w-full gap-3">
                <motion.button
                  onClick={copyLink}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gray-100 py-3 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-200"
                >
                  {copied ? (
                    <>
                      <Check className="h-4 w-4 text-primary-600" strokeWidth={1.5} />
                      کپی شد
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4" strokeWidth={1.5} />
                      کپی لینک
                    </>
                  )}
                </motion.button>
                <motion.a
                  href={normalizedUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-primary-600 py-3 text-sm font-medium text-white transition-colors hover:bg-primary-700"
                >
                  <ExternalLink className="h-4 w-4" strokeWidth={1.5} />
                  باز کردن
                </motion.a>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}