import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Plus,
  Crown,
  Trash2,
  Star,
  Copy,
  Check,
  ExternalLink,
  Lock,
  Globe,
  CreditCard,
  Eye,
  EyeOff,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import {
  getMyCards,
  createCard,
  deleteCard,
  setPrimaryCard,
} from '@/lib/cards';
import type { Card } from '@/types';

export function MyCardsTab() {
  const [cards, setCards] = useState<Card[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const list = await getMyCards();
      setCards(list);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleCreate = async () => {
    setCreating(true);
    try {
      const newUsername = `card-${Math.random().toString(36).slice(2, 8)}`;
      await createCard({
        username: newUsername,
        full_name: 'کارت جدید',
        is_private: false,
      });
      await load();
    } catch (err: any) {
      alert(err.message || 'خطا در ساخت کارت');
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async (cardId: string) => {
    if (!confirm('آیا از حذف این کارت مطمئن هستید؟')) return;
    try {
      await deleteCard(cardId);
      setCards(cards.filter((c) => c.id !== cardId));
    } catch (err: any) {
      alert(err.message || 'خطا در حذف');
    }
  };

  const handleSetPrimary = async (cardId: string) => {
    try {
      await setPrimaryCard(cardId);
      await load();
    } catch (err: any) {
      alert(err.message || 'خطا');
    }
  };

  const handleCopy = async (username: string, id: string) => {
    await navigator.clipboard.writeText(`${window.location.origin}/${username}`);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary-200 border-t-primary-600" />
      </div>
    );
  }

  const userPremium = cards.some((c) => c.is_premium);
  const canCreateMore = userPremium ? cards.length < 5 : cards.length < 1;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="rounded-2xl bg-white p-6 shadow-[0_2px_12px_rgba(0,0,0,0.04)] sm:p-8">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-gray-800">کارت‌های من</h3>
            <p className="mt-1 text-xs text-gray-500">
              {userPremium
                ? `${cards.length} از ۵ کارت (نسخه ویژه)`
                : `${cards.length} کارت (رایگان — ۱ کارت)`}
            </p>
          </div>
          {canCreateMore && (
            <motion.button
              onClick={handleCreate}
              disabled={creating}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="flex items-center gap-2 rounded-xl bg-primary-600 px-4 py-2.5 text-sm font-bold text-white shadow-md transition-colors hover:bg-primary-700 disabled:opacity-50"
            >
              <Plus className="h-4 w-4" strokeWidth={2} />
              کارت جدید
            </motion.button>
          )}
          {!userPremium && cards.length >= 1 && (
            <Link
              to="/pricing"
              className="flex items-center gap-2 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 px-4 py-2.5 text-sm font-bold text-white shadow-md transition-transform hover:scale-105"
            >
              <Crown className="h-4 w-4" strokeWidth={2} />
              ارتقا
            </Link>
          )}
        </div>

        {!userPremium && (
          <div className="rounded-xl bg-amber-50 p-3 text-xs text-amber-800 ring-1 ring-amber-100">
            💡 با نسخه ویژه می‌توانید تا ۵ کارت برای خود بسازید (مثلاً: کارت شخصی، شرکتی، پروژه).
          </div>
        )}
      </div>

      {/* Cards List */}
      <div className="grid gap-4 sm:grid-cols-2">
        {cards.map((card) => (
          <motion.div
            key={card.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative rounded-2xl bg-white p-5 shadow-[0_2px_12px_rgba(0,0,0,0.04)]"
          >
            {/* Badges */}
            <div className="absolute top-3 left-3 flex gap-1.5">
              {card.is_primary && (
                <span className="flex items-center gap-1 rounded-full bg-primary-100 px-2 py-0.5 text-[10px] font-bold text-primary-700">
                  <Star className="h-2.5 w-2.5" fill="currentColor" />
                  اصلی
                </span>
              )}
              {card.is_private ? (
                <span className="flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-600">
                  <Lock className="h-2.5 w-2.5" />
                  خصوصی
                </span>
              ) : (
                <span className="flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700">
                  <Globe className="h-2.5 w-2.5" />
                  عمومی
                </span>
              )}
            </div>

            <div className="mb-3 flex items-start gap-3">
              {card.avatar_url ? (
                <img
                  src={card.avatar_url}
                  alt={card.full_name || ''}
                  className="h-12 w-12 rounded-xl object-cover"
                />
              ) : (
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 text-lg font-bold text-primary-600">
                  {(card.full_name || card.username || '?').charAt(0)}
                </div>
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate font-bold text-gray-800">
                  {card.full_name || 'بدون نام'}
                </p>
                <p className="truncate text-xs text-gray-500">
                  {card.headline || 'بدون تیتر'}
                </p>
                <p className="mt-1 truncate font-mono text-[10px] text-gray-400" dir="ltr">
                  /{card.username}
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap gap-1.5">
              <button
                onClick={() => handleCopy(card.username, card.id)}
                className="flex items-center gap-1 rounded-lg bg-gray-50 px-2.5 py-1.5 text-[11px] font-medium text-gray-700 transition-colors hover:bg-gray-100"
              >
                {copiedId === card.id ? (
                  <Check className="h-3 w-3" />
                ) : (
                  <Copy className="h-3 w-3" />
                )}
                {copiedId === card.id ? 'کپی شد' : 'کپی لینک'}
              </button>

              <Link
                to={`/${card.username}`}
                className="flex items-center gap-1 rounded-lg bg-primary-50 px-2.5 py-1.5 text-[11px] font-medium text-primary-700 transition-colors hover:bg-primary-100"
              >
                <ExternalLink className="h-3 w-3" />
                مشاهده
              </Link>

              {!card.is_primary && (
                <>
                  <button
                    onClick={() => handleSetPrimary(card.id)}
                    className="flex items-center gap-1 rounded-lg bg-amber-50 px-2.5 py-1.5 text-[11px] font-medium text-amber-700 transition-colors hover:bg-amber-100"
                  >
                    <Star className="h-3 w-3" />
                    اصلی کن
                  </button>
                  <button
                    onClick={() => handleDelete(card.id)}
                    className="flex items-center gap-1 rounded-lg bg-red-50 px-2.5 py-1.5 text-[11px] font-medium text-red-600 transition-colors hover:bg-red-100"
                  >
                    <Trash2 className="h-3 w-3" />
                    حذف
                  </button>
                </>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {cards.length === 0 && (
        <div className="rounded-2xl bg-white p-12 text-center shadow-sm">
          <CreditCard className="mx-auto mb-3 h-12 w-12 text-gray-300" strokeWidth={1} />
          <p className="text-sm text-gray-400">هنوز کارتی نساخته‌اید</p>
        </div>
      )}
    </div>
  );
}