import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Users,
  Phone,
  MapPin,
  Monitor,
  Calendar,
  Crown,
  UserPlus,
  Lock,
  Eye,
  TrendingUp,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { getMyContacts, type ContactSave } from '@/lib/analytics';
import type { ProfileWithRelations } from '@/types';

const FREE_CONTACTS_LIMIT = 3;

export function ContactsTab({ profile }: { profile: ProfileWithRelations }) {
  const [contacts, setContacts] = useState<ContactSave[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getMyContacts(profile.id)
      .then(setContacts)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [profile.id]);

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary-200 border-t-primary-600" />
      </div>
    );
  }

  const isPremium = profile.is_premium;
  const visibleContacts = isPremium ? contacts : contacts.slice(0, FREE_CONTACTS_LIMIT);
  const hiddenCount = isPremium ? 0 : Math.max(0, contacts.length - FREE_CONTACTS_LIMIT);

  // حالت خالی
  if (contacts.length === 0) {
    return (
      <div className="rounded-2xl bg-white p-12 text-center shadow-sm">
        <UserPlus className="mx-auto mb-3 h-12 w-12 text-gray-300" strokeWidth={1} />
        <p className="text-sm text-gray-400">هنوز کسی کارت شما را ذخیره نکرده است.</p>
        <p className="mt-2 text-xs text-gray-400">
          لینک کارت خود را به اشتراک بگذارید تا مخاطبین بیشتری جذب کنید.
        </p>
      </div>
    );
  }

  const formatDate = (iso: string) => {
    try {
      return new Date(iso).toLocaleDateString('fa-IR', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return iso;
    }
  };

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="mb-4 flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-sm font-bold text-gray-800">
          <Users className="h-4 w-4 text-primary-600" strokeWidth={1.5} />
          مخاطبین من
          <span className="rounded-full bg-primary-50 px-2 py-0.5 text-[10px] font-bold text-primary-700">
            {contacts.length}
          </span>
        </h3>
        {!isPremium && (
          <span className="rounded-full bg-amber-50 px-2.5 py-1 text-[10px] font-bold text-amber-700">
            نمایش {FREE_CONTACTS_LIMIT} مورد اول
          </span>
        )}
      </div>

      {/* Contacts */}
      {visibleContacts.map((contact, i) => (
        <motion.div
          key={contact.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.05 }}
          className="rounded-2xl bg-white p-5 shadow-sm transition-shadow hover:shadow-md"
        >
          <div className="flex items-start gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary-500 to-accent-500 text-sm font-bold text-white">
              {(contact.saved_by_name || '?').charAt(0)}
            </div>
            <div className="flex-1">
              <p className="font-bold text-gray-800">
                {contact.saved_by_name || 'کاربر مهمان'}
              </p>
              <div className="mt-1.5 flex flex-wrap gap-3 text-xs text-gray-500">
                {contact.saved_by_phone && (
                  <span className="flex items-center gap-1" dir="ltr">
                    <Phone className="h-3 w-3" strokeWidth={1.5} />
                    {contact.saved_by_phone}
                  </span>
                )}
                {contact.saved_by_device && (
                  <span className="flex items-center gap-1">
                    <Monitor className="h-3 w-3" strokeWidth={1.5} />
                    {contact.saved_by_device}
                  </span>
                )}
                <span className="flex items-center gap-1 text-gray-400">
                  <Calendar className="h-3 w-3" strokeWidth={1.5} />
                  {formatDate(contact.created_at)}
                </span>
              </div>
            </div>
          </div>
        </motion.div>
      ))}

      {/* Locked preview (برای کاربران رایگان) */}
      {hiddenCount > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="overflow-hidden rounded-2xl bg-white shadow-sm"
        >
          {/* Blurred contact (نمایش مبهم) */}
          <div className="relative">
            <div className="pointer-events-none select-none p-5 opacity-40 blur-[6px]">
              <div className="flex items-start gap-3">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gray-300 text-sm font-bold text-white">
                  ؟
                </div>
                <div className="flex-1">
                  <div className="h-4 w-32 rounded bg-gray-300" />
                  <div className="mt-2 flex gap-3">
                    <div className="h-3 w-24 rounded bg-gray-200" />
                    <div className="h-3 w-20 rounded bg-gray-200" />
                  </div>
                </div>
              </div>
            </div>

            {/* Lock overlay */}
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-b from-white/40 to-white/80 p-4 text-center">
              <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-amber-100">
                <Lock className="h-5 w-5 text-amber-600" strokeWidth={1.5} />
              </div>
              <p className="text-sm font-bold text-gray-800">
                {hiddenCount} مخاطب دیگر
              </p>
              <p className="mt-1 text-[11px] text-gray-500">
                برای دیدن همه، نسخه ویژه را فعال کنید
              </p>
              <Link
                to="/pricing"
                className="mt-3 inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 px-4 py-2 text-[11px] font-bold text-white shadow-md transition-transform hover:scale-105"
              >
                <Crown className="h-3.5 w-3.5" strokeWidth={2} />
                ارتقا به نسخه ویژه
              </Link>
            </div>
          </div>
        </motion.div>
      )}

      {/* Premium upsell (برای کاربران رایگان با تعداد کم) */}
      {!isPremium && contacts.length > 0 && hiddenCount === 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="rounded-2xl bg-gradient-to-l from-amber-50 to-orange-50 p-5 ring-1 ring-amber-100"
        >
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 shadow-sm">
              <Crown className="h-5 w-5 text-white" strokeWidth={1.5} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-bold text-gray-800">نسخه ویژه را فعال کنید</p>
              <p className="mt-1 text-[11px] leading-relaxed text-gray-600">
                با نسخه ویژه، آمار کامل بازدیدها، شهر و دستگاه بازدیدکنندگان، و همه مخاطبین خود را می‌بینید.
              </p>
              <Link
                to="/pricing"
                className="mt-3 inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 px-4 py-2 text-[11px] font-bold text-white shadow-md transition-transform hover:scale-105"
              >
                <Crown className="h-3.5 w-3.5" strokeWidth={2} />
                فعال‌سازی نسخه ویژه
              </Link>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}