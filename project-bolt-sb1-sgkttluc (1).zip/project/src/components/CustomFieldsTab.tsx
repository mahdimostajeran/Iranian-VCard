import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Plus,
  Eye,
  EyeOff,
  Save,
  Star,
  Trash2,
  ChevronUp,
  ChevronDown,
} from 'lucide-react';
import type { CustomField } from '@/types';
import { upsertProfile } from '@/lib/profiles';

const SUGGESTED_FIELDS = [
  { label: 'شماره دفتر', icon: '📞' },
  { label: 'شماره واتساپ', icon: '💬' },
  { label: 'کد پستی', icon: '📮' },
  { label: 'آدرس', icon: '📍' },
  { label: 'ساعت کاری', icon: '🕐' },
  { label: 'شماره فکس', icon: '📠' },
  { label: 'وب‌سایت شخصی', icon: '🌐' },
  { label: 'کد ملی', icon: '🆔' },
  { label: 'شماره ثبت شرکت', icon: '🏢' },
];

export function CustomFieldsTab({
  initialFields,
  onSave,
}: {
  initialFields: CustomField[];
  onSave?: () => void;
}) {
  const [fields, setFields] = useState<CustomField[]>(
    (initialFields || []).map((f, i) => ({ ...f, priority: f.priority ?? i }))
  );
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [newLabel, setNewLabel] = useState('');

  const addField = (label = '') => {
    const finalLabel = label || newLabel.trim();
    if (!finalLabel) return;
    setFields([
      ...fields,
      {
        label: finalLabel,
        value: '',
        icon: '📌',
        is_public: true,
        priority: fields.length,
      },
    ]);
    setNewLabel('');
  };

  const updateField = (index: number, patch: Partial<CustomField>) => {
    setFields(fields.map((f, i) => (i === index ? { ...f, ...patch } : f)));
  };

  const removeField = (index: number) => {
    setFields(fields.filter((_, i) => i !== index).map((f, i) => ({ ...f, priority: i })));
  };

  const moveUp = (index: number) => {
    if (index === 0) return;
    const next = [...fields];
    [next[index - 1], next[index]] = [next[index], next[index - 1]];
    setFields(next.map((f, i) => ({ ...f, priority: i })));
  };

  const moveDown = (index: number) => {
    if (index === fields.length - 1) return;
    const next = [...fields];
    [next[index + 1], next[index]] = [next[index], next[index + 1]];
    setFields(next.map((f, i) => ({ ...f, priority: i })));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await upsertProfile({ custom_fields: fields } as any);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
      if (onSave) onSave();
    } catch (err) {
      console.error('[CustomFields] Save failed:', err);
    } finally {
      setSaving(false);
    }
  };

  const inputClass =
    'w-full rounded-xl border border-gray-100 bg-gray-50 px-3 py-2 text-sm text-gray-800 transition-all focus:border-primary-300 focus:bg-white focus:shadow-[0_0_0_3px_rgba(20,184,166,0.1)]';

  return (
    <div className="space-y-6">
      <div className="rounded-2xl bg-white p-6 shadow-[0_2px_12px_rgba(0,0,0,0.04)] sm:p-8">
        <h3 className="mb-2 text-base font-bold text-gray-800">فیلدهای سفارشی کارت</h3>
        <p className="mb-4 text-xs text-gray-500">
          هر اطلاعاتی که می‌خواهید روی کارت شما ظاهر شود — با اولویت‌بندی و کنترل نمایش.
        </p>

        {/* پیشنهادها */}
        <div className="mb-5 flex flex-wrap gap-2">
          {SUGGESTED_FIELDS.map((s) => (
            <button
              key={s.label}
              type="button"
              onClick={() => addField(s.label)}
              className="rounded-full bg-primary-50 px-3 py-1.5 text-xs font-medium text-primary-700 ring-1 ring-primary-100 transition-colors hover:bg-primary-100"
            >
              {s.icon} {s.label}
            </button>
          ))}
        </div>

        {/* فیلد جدید */}
        <div className="mb-5 flex gap-2">
          <input
            value={newLabel}
            onChange={(e) => setNewLabel(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addField();
              }
            }}
            className={inputClass}
            placeholder="نام فیلد دلخواه (مثلاً: شماره دفتر)..."
          />
          <button
            type="button"
            onClick={() => addField()}
            disabled={!newLabel.trim()}
            className="flex items-center gap-1 rounded-xl bg-primary-600 px-4 text-sm font-medium text-white disabled:opacity-50"
          >
            <Plus className="h-4 w-4" />
            افزودن
          </button>
        </div>

        {/* لیست فیلدها */}
        {fields.length === 0 ? (
          <div className="rounded-xl bg-gray-50 p-8 text-center text-xs text-gray-400">
            هنوز فیلدی اضافه نکرده‌اید. از پیشنهادهای بالا یا فیلد دلخواه استفاده کنید.
          </div>
        ) : (
          <div className="space-y-2">
            {fields.map((field, i) => (
              <motion.div
                key={i}
                layout
                className="rounded-xl border border-gray-100 bg-white p-3"
              >
                <div className="flex items-start gap-2">
                  <div className="flex flex-col gap-0.5">
                    <button
                      type="button"
                      onClick={() => moveUp(i)}
                      disabled={i === 0}
                      className="rounded p-1 text-gray-400 hover:bg-gray-100 disabled:opacity-30"
                    >
                      <ChevronUp className="h-3 w-3" />
                    </button>
                    <button
                      type="button"
                      onClick={() => moveDown(i)}
                      disabled={i === fields.length - 1}
                      className="rounded p-1 text-gray-400 hover:bg-gray-100 disabled:opacity-30"
                    >
                      <ChevronDown className="h-3 w-3" />
                    </button>
                  </div>

                  <input
                    value={field.icon || '📌'}
                    onChange={(e) => updateField(i, { icon: e.target.value })}
                    className="w-10 rounded-lg border border-gray-100 bg-gray-50 px-1 py-2 text-center text-lg"
                    maxLength={2}
                  />

                  <input
                    value={field.label}
                    onChange={(e) => updateField(i, { label: e.target.value })}
                    className="w-32 rounded-lg border border-gray-100 bg-gray-50 px-2 py-2 text-xs font-medium"
                    placeholder="برچسب"
                  />

                  <input
                    value={field.value}
                    onChange={(e) => updateField(i, { value: e.target.value })}
                    className="flex-1 rounded-lg border border-gray-100 bg-gray-50 px-2 py-2 text-xs"
                    placeholder="مقدار"
                  />

                  <button
                    type="button"
                    onClick={() => updateField(i, { is_public: !field.is_public })}
                    className={`rounded-lg p-2 ${
                      field.is_public
                        ? 'bg-emerald-50 text-emerald-600'
                        : 'bg-gray-100 text-gray-400'
                    }`}
                    title={field.is_public ? 'نمایش در کارت' : 'فقط در سایت'}
                  >
                    {field.is_public ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                  </button>

                  <button
                    type="button"
                    onClick={() => removeField(i)}
                    className="rounded-lg bg-red-50 p-2 text-red-600 hover:bg-red-100"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>

                <div className="mt-2 flex items-center gap-2 text-[10px] text-gray-400">
                  <Star className="h-3 w-3" />
                  اولویت {i + 1}
                  {!field.is_public && <span className="mr-1">— مخفی از کارت عمومی</span>}
                </div>
              </motion.div>
            ))}
          </div>
        )}

        <div className="mt-5 rounded-xl bg-amber-50 p-3 text-[11px] leading-relaxed text-amber-800">
          💡 <strong>راهنما:</strong> فیلدهایی که «چشم سبز» دارند در کارت عمومی نمایش داده می‌شوند.
          ترتیب نمایش را با فلش‌های بالا/پایین تنظیم کنید — هرچه بالاتر، مهم‌تر.
        </div>

        <button
          type="button"
          onClick={handleSave}
          disabled={saving}
          className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-primary-600 py-3 text-sm font-bold text-white shadow-md transition-colors hover:bg-primary-700 disabled:opacity-50"
        >
          {saved ? (
            <>
              <Save className="h-4 w-4" />
              ذخیره شد!
            </>
          ) : saving ? (
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
          ) : (
            <>
              <Save className="h-4 w-4" />
              ذخیره فیلدهای سفارشی
            </>
          )}
        </button>
      </div>
    </div>
  );
}