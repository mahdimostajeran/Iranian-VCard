import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  User,
  Briefcase,
  Tag,
  Mail,
  Phone,
  Globe,
  ImageIcon,
  Save,
  Plus,
  X,
  Check,
  Image,
  Music,
  Video,
  Trash2,
  Crown,
  Building2,
  Share2,
} from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuth } from '@/hooks/useAuth';
import {
  upsertProfile,
  updateSkills,
  updateSocialLinks,
  checkUsernameAvailable,
} from '@/lib/profiles';
import {
  uploadAvatar,
  uploadCoverImage,
  uploadAudio,
  uploadVideo,
  deleteFile,
} from '@/lib/storage';
import type { ProfileWithRelations, TemplateType, Platform } from '@/types';

// شبکه‌های رایگان (۴ مورد اول همیشه در دسترس)
const FREE_SOCIAL_PLATFORMS: { value: Platform; label: string }[] = [
  { value: 'linkedin', label: 'لینکدین' },
  { value: 'instagram', label: 'اینستاگرام' },
  { value: 'telegram', label: 'تلگرام' },
  { value: 'whatsapp', label: 'واتساپ' },
];

// شبکه‌های ویژه (نیاز به پلن حرفه‌ای)
const PREMIUM_SOCIAL_PLATFORMS: { value: Platform; label: string }[] = [
  { value: 'twitter', label: 'توییتر (X)' },
  { value: 'youtube', label: 'یوتیوب' },
  { value: 'facebook', label: 'فیسبوک' },
  { value: 'tiktok', label: 'تیک‌تاک' },
  { value: 'github', label: 'گیت‌هاب' },
];

// شبکه‌های داخلی ایران (نیاز به پلن حرفه‌ای)
const IRANIAN_SOCIAL_PLATFORMS: { value: Platform; label: string }[] = [
  { value: 'eitaa', label: 'ایتا' },
  { value: 'bale', label: 'بله' },
  { value: 'rubika', label: 'روبیکا' },
  { value: 'soroush', label: 'سروش' },
  { value: 'igap', label: 'آی‌گپ' },
];

const schema = z.object({
  username: z.string().min(3, 'نام کاربری حداقل ۳ کاراکتر'),
  full_name: z.string().min(1, 'نام الزامی است'),
  headline: z.string().optional(),
  company: z.string().optional(),
  bio: z.string().max(300, 'بیوگرافی حداکثر ۳۰۰ کاراکتر').optional(),
  email: z.string().email('ایمیل نامعتبر').optional().or(z.literal('')),
  phone: z.string().optional(),
  website: z.string().optional(),
  template_type: z.enum(['personal', 'corporate']),
});

type FormData = z.infer<typeof schema>;

const DRAFT_KEY = 'card_draft';

function loadDraft(): Partial<FormData> | null {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return null;
    return parsed;
  } catch {
    return null;
  }
}

export function EditCardTab({
  profile,
  onProfileUpdate,
}: {
  profile: ProfileWithRelations;
  onProfileUpdate?: () => void;
}) {
  const { user } = useAuth();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [avatarUploading, setAvatarUploading] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState(profile.avatar_url || '');
  const [coverUploading, setCoverUploading] = useState(false);
  const [coverUrl, setCoverUrl] = useState(profile.cover_image_url || '');
  const [audioUploading, setAudioUploading] = useState(false);
  const [audioUrl, setAudioUrl] = useState(profile.audio_intro_url || '');
  const [videoUploading, setVideoUploading] = useState(false);
  const [videoUrl, setVideoUrl] = useState(profile.video_url || '');
  const [mediaError, setMediaError] = useState('');
  const [skills, setSkills] = useState<string[]>(profile.skills.map((s) => s.skill_name));
  const [skillInput, setSkillInput] = useState('');
  const [usernameError, setUsernameError] = useState('');
  const [socialLinks, setSocialLinks] = useState<{ platform: Platform; url: string }[]>(
    profile.social_links.map((l) => ({ platform: l.platform, url: l.url }))
  );

  const draft = loadDraft();

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      username: draft?.username ?? profile.username,
      full_name: draft?.full_name ?? profile.full_name,
      headline: draft?.headline ?? profile.headline,
      company: draft?.company ?? profile.company ?? '',
      bio: draft?.bio ?? profile.bio,
      email: draft?.email ?? profile.email,
      phone: draft?.phone ?? profile.phone,
      website: draft?.website ?? profile.website,
      template_type: (draft?.template_type ?? profile.template_type) as TemplateType,
    },
  });

  const templateType = watch('template_type');

  useEffect(() => {
    const subscription = watch((values) => {
      try {
        localStorage.setItem(DRAFT_KEY, JSON.stringify(values));
      } catch {
        // ignore
      }
    });
    return () => subscription.unsubscribe();
  }, [watch]);

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setAvatarUploading(true);
    setMediaError('');
    try {
      const url = await uploadAvatar(file, user.id);
      setAvatarUrl(url);
      await upsertProfile({ avatar_url: url });
      if (onProfileUpdate) onProfileUpdate();
    } catch (err: any) {
      setMediaError(err.message || 'خطا در آپلود');
    } finally {
      setAvatarUploading(false);
    }
  };

  const handleRemoveAvatar = async () => {
    if (!user) return;
    if (!confirm('آیا از حذف عکس پروفایل مطمئن هستید؟')) return;
    setMediaError('');
    try {
      await deleteFile('avatars', user.id, 'avatar.jpg');
      setAvatarUrl('');
      await upsertProfile({ avatar_url: '' });
      if (onProfileUpdate) onProfileUpdate();
    } catch (err: any) {
      setMediaError(err.message || 'خطا در حذف عکس');
    }
  };

  const handleCoverChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setCoverUploading(true);
    setMediaError('');
    try {
      const url = await uploadCoverImage(file, user.id);
      setCoverUrl(url);
      await upsertProfile({ cover_image_url: url });
      if (onProfileUpdate) onProfileUpdate();
    } catch (err: any) {
      setMediaError(err.message || 'خطا در آپلود کاور');
    } finally {
      setCoverUploading(false);
    }
  };

  const handleRemoveCover = async () => {
    if (!user) return;
    if (!confirm('آیا از حذف تصویر کاور مطمئن هستید؟')) return;
    setMediaError('');
    try {
      await deleteFile('covers', user.id, 'cover.jpg');
      setCoverUrl('');
      await upsertProfile({ cover_image_url: '' });
      if (onProfileUpdate) onProfileUpdate();
    } catch (err: any) {
      setMediaError(err.message || 'خطا در حذف کاور');
    }
  };

  const handleAudioChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setAudioUploading(true);
    setMediaError('');
    try {
      const url = await uploadAudio(file, user.id);
      setAudioUrl(url);
      await upsertProfile({ audio_intro_url: url });
      if (onProfileUpdate) onProfileUpdate();
    } catch (err: any) {
      setMediaError(err.message || 'خطا در آپلود صوت');
    } finally {
      setAudioUploading(false);
    }
  };

  const handleVideoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setVideoUploading(true);
    setMediaError('');
    try {
      const url = await uploadVideo(file, user.id);
      setVideoUrl(url);
      await upsertProfile({ video_url: url });
      if (onProfileUpdate) onProfileUpdate();
    } catch (err: any) {
      setMediaError(err.message || 'خطا در آپلود ویدیو');
    } finally {
      setVideoUploading(false);
    }
  };

  const addSkill = () => {
    const s = skillInput.trim();
    if (s && !skills.includes(s)) {
      setSkills([...skills, s]);
      setSkillInput('');
    }
  };

  const removeSkill = (s: string) => {
    setSkills(skills.filter((x) => x !== s));
  };

  const updateSocialUrl = (platform: Platform, url: string) => {
    setSocialLinks((prev) => {
      const existing = prev.find((l) => l.platform === platform);
      if (existing) {
        return prev.map((l) => (l.platform === platform ? { ...l, url } : l));
      }
      return [...prev, { platform, url }];
    });
  };

  const getSocialUrl = (platform: Platform) =>
    socialLinks.find((l) => l.platform === platform)?.url ?? '';

  const onSubmit = async (data: FormData) => {
    if (!user) return;
    setSaving(true);
    setUsernameError('');
    try {
      const available = await checkUsernameAvailable(data.username);
      if (!available) {
        setUsernameError('این نام کاربری قبلاً گرفته شده است');
        setSaving(false);
        return;
      }

      await upsertProfile({
        username: data.username,
        full_name: data.full_name,
        headline: data.headline ?? '',
        company: data.company ?? '',
        bio: data.bio ?? '',
        email: data.email ?? '',
        phone: data.phone ?? '',
        website: data.website ?? '',
        template_type: data.template_type,
      });
      await updateSkills(user.id, skills);
      await updateSocialLinks(user.id, socialLinks);

      localStorage.removeItem(DRAFT_KEY);

      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
      if (onProfileUpdate) onProfileUpdate();
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const inputClass =
    'w-full rounded-xl border border-gray-100 bg-gray-50 px-4 py-2.5 text-sm text-gray-800 transition-all focus:border-primary-300 focus:bg-white focus:shadow-[0_0_0_3px_rgba(20,184,166,0.1)]';

  const cardClass = 'rounded-2xl bg-white p-6 shadow-[0_2px_12px_rgba(0,0,0,0.04)] sm:p-8';
  const sectionTitle = 'mb-5 flex items-center gap-2 text-sm font-semibold text-gray-700';
  const iconProps = { className: 'h-4 w-4 text-primary-600', strokeWidth: 1.5 } as const;

  const filledSocialCount = socialLinks.filter((l) => l.url.trim()).length;

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
      {draft && (
        <div className="rounded-2xl bg-amber-50 px-4 py-3 text-xs text-amber-700 ring-1 ring-amber-100">
          📝 تغییرات ذخیره‌نشده شما بازیابی شد.
        </div>
      )}

      {/* Avatar */}
      <div className={cardClass}>
        <h3 className={sectionTitle}>
          <ImageIcon {...iconProps} />
          عکس پروفایل
        </h3>
        <div className="flex items-center gap-4">
          <div className="relative">
            {avatarUrl ? (
              <img
                src={avatarUrl}
                alt="avatar"
                className="h-20 w-20 rounded-full object-cover ring-2 ring-primary-200"
              />
            ) : (
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary-50 text-2xl font-bold text-primary-600 ring-2 ring-primary-200">
                {profile.full_name.charAt(0) || '?'}
              </div>
            )}
            {avatarUploading && (
              <div className="absolute inset-0 flex items-center justify-center rounded-full bg-white/70">
                <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary-300 border-t-primary-600" />
              </div>
            )}
          </div>
          <div className="flex flex-col gap-2">
            <motion.label
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="cursor-pointer rounded-xl bg-gray-100 px-4 py-2.5 text-center text-sm font-medium text-gray-700 transition-colors hover:bg-gray-200"
            >
              {avatarUrl ? 'تغییر عکس' : 'آپلود عکس'}
              <input type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
            </motion.label>
            {avatarUrl && (
              <motion.button
                type="button"
                onClick={handleRemoveAvatar}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="flex items-center justify-center gap-1.5 rounded-xl bg-red-50 px-4 py-2.5 text-sm font-medium text-red-600 transition-colors hover:bg-red-100"
              >
                <Trash2 className="h-4 w-4" strokeWidth={1.5} />
                حذف عکس
              </motion.button>
            )}
          </div>
        </div>
      </div>

      {mediaError && (
        <div className="rounded-xl bg-red-50 px-4 py-3 text-xs text-red-600">{mediaError}</div>
      )}

      {/* Cover Image */}
      <div className={cardClass}>
        <h3 className={sectionTitle}>
          <Image {...iconProps} />
          تصویر کاور
        </h3>
        <p className="mb-3 text-xs text-gray-400">JPG یا PNG، حداکثر ۲ مگابایت</p>
        {coverUrl ? (
          <div className="relative mb-3 overflow-hidden rounded-xl">
            <img src={coverUrl} alt="cover" className="h-32 w-full object-cover" />
            {coverUploading && (
              <div className="absolute inset-0 flex items-center justify-center bg-white/70">
                <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary-300 border-t-primary-600" />
              </div>
            )}
          </div>
        ) : null}
        <div className="flex gap-2">
          <motion.label
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="cursor-pointer rounded-xl bg-gray-100 px-4 py-2.5 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-200"
          >
            {coverUrl ? 'تغییر کاور' : 'آپلود کاور'}
            <input
              type="file"
              accept="image/jpeg,image/png"
              onChange={handleCoverChange}
              className="hidden"
            />
          </motion.label>
          {coverUrl && (
            <motion.button
              type="button"
              onClick={handleRemoveCover}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="flex items-center gap-1.5 rounded-xl bg-red-50 px-4 py-2.5 text-sm font-medium text-red-600 transition-colors hover:bg-red-100"
            >
              <Trash2 className="h-4 w-4" strokeWidth={1.5} />
              حذف کاور
            </motion.button>
          )}
        </div>
      </div>

      {/* Audio Intro — Premium only */}
      <div className={cardClass}>
        <h3 className={sectionTitle}>
          <Music {...iconProps} />
          معرفی صوتی
          <span className="mr-2 rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-bold text-amber-700">
            ویژه
          </span>
        </h3>
        <p className="mb-3 text-xs text-gray-400">MP3 یا M4A، حداکثر ۵ مگابایت</p>
        {profile.is_premium ? (
          <>
            {audioUrl && (
              <div className="mb-3">
                <audio controls src={audioUrl} className="w-full" style={{ accentColor: '#14b8a6' }} />
                {audioUploading && <p className="mt-1 text-xs text-gray-400">در حال آپلود...</p>}
              </div>
            )}
            <motion.label
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="cursor-pointer rounded-xl bg-gray-100 px-4 py-2.5 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-200"
            >
              {audioUrl ? 'تغییر صوت' : 'آپلود صوت'}
              <input
                type="file"
                accept="audio/mpeg,audio/mp3,audio/m4a,audio/x-m4a"
                onChange={handleAudioChange}
                className="hidden"
              />
            </motion.label>
          </>
        ) : (
          <div className="rounded-2xl bg-gradient-to-l from-amber-50 to-orange-50 p-4 ring-1 ring-amber-100">
            <p className="text-xs leading-relaxed text-gray-700">
              🎙️ <span className="font-bold">با معرفی صوتی، صدای خود را به مخاطبین برسانید.</span>{' '}
              یک پیام کوتاه صوتی ضبط کنید و کارت ویزیتتان را زنده‌تر کنید.
            </p>
            <Link
              to="/pricing"
              className="mt-3 inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 px-4 py-2 text-xs font-bold text-white shadow-md transition-transform hover:scale-105"
            >
              <Crown className="h-3.5 w-3.5" strokeWidth={2} />
              ارتقا به ویژه و فعال‌سازی
            </Link>
          </div>
        )}
      </div>

      {/* Video Intro — Premium only */}
      <div className={cardClass}>
        <h3 className={sectionTitle}>
          <Video {...iconProps} />
          معرفی ویدیویی
          <span className="mr-2 rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-bold text-amber-700">
            ویژه
          </span>
        </h3>
        <p className="mb-3 text-xs text-gray-400">MP4، حداکثر ۲۰ مگابایت</p>
        {profile.is_premium ? (
          <>
            {videoUrl && (
              <div className="mb-3">
                <video controls src={videoUrl} className="w-full rounded-xl" style={{ maxHeight: '200px' }} />
                {videoUploading && <p className="mt-1 text-xs text-gray-400">در حال آپلود...</p>}
              </div>
            )}
            <motion.label
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="cursor-pointer rounded-xl bg-gray-100 px-4 py-2.5 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-200"
            >
              {videoUrl ? 'تغییر ویدیو' : 'آپلود ویدیو'}
              <input type="file" accept="video/mp4" onChange={handleVideoChange} className="hidden" />
            </motion.label>
          </>
        ) : (
          <div className="rounded-2xl bg-gradient-to-l from-amber-50 to-orange-50 p-4 ring-1 ring-amber-100">
            <p className="text-xs leading-relaxed text-gray-700">
              🎬 <span className="font-bold">با یک ویدیوی کوتاه، خودتان را معرفی کنید.</span>{' '}
              ویدیو اولین چیزی است که مخاطب را جذب می‌کند.
            </p>
            <Link
              to="/pricing"
              className="mt-3 inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-l from-amber-500 to-orange-500 px-4 py-2 text-xs font-bold text-white shadow-md transition-transform hover:scale-105"
            >
              <Crown className="h-3.5 w-3.5" strokeWidth={2} />
              ارتقا به ویژه و فعال‌سازی
            </Link>
          </div>
        )}
      </div>

      {/* Template selector */}
      <div className={cardClass}>
        <h3 className={sectionTitle}>نوع قالب</h3>
        <div className="grid grid-cols-2 gap-3">
          <motion.button
            type="button"
            onClick={() => setValue('template_type', 'personal')}
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.98 }}
            className={`rounded-xl border-2 p-4 text-right transition-all ${
              templateType === 'personal'
                ? 'border-primary-500 bg-primary-50 shadow-[0_4px_16px_rgba(20,184,166,0.1)]'
                : 'border-gray-100 bg-white hover:border-gray-200'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-medium text-gray-800">شخصی</span>
              {templateType === 'personal' && <Check className="h-4 w-4 text-primary-600" strokeWidth={1.5} />}
            </div>
            <p className="mt-1 text-xs text-gray-500">سبک شخصی و صمیمی</p>
          </motion.button>

          <div className="relative rounded-xl border-2 border-dashed border-gray-200 bg-gray-50 p-4 text-right opacity-60">
            <span className="absolute top-2 left-2 rounded-full bg-gray-200 px-2 py-0.5 text-[9px] font-bold text-gray-600">
              به زودی
            </span>
            <div className="flex items-center justify-between">
              <span className="font-medium text-gray-500">شرکتی</span>
            </div>
            <p className="mt-1 text-xs text-gray-400">سبک رسمی و حرفه‌ای</p>
          </div>
        </div>
      </div>

      {/* Basic info */}
      <div className={cardClass}>
        <h3 className={sectionTitle}>
          <User {...iconProps} />
          اطلاعات شخصی
        </h3>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-gray-600">نام کاربری (URL)</label>
            <div className="relative flex">
              <span
                className="flex items-center rounded-r-xl border border-l-0 border-gray-200 bg-gray-100 px-3 text-xs text-gray-400"
                dir="ltr"
              >
                /
              </span>
              <input
                {...register('username')}
                dir="ltr"
                className={`${inputClass} rounded-l-xl rounded-r-none`}
                placeholder="username"
              />
            </div>
            {usernameError && <p className="mt-1 text-xs text-red-500">{usernameError}</p>}
            {errors.username && <p className="mt-1 text-xs text-red-500">{errors.username.message}</p>}
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-gray-600">نام و نام خانوادگی</label>
            <input {...register('full_name')} className={inputClass} placeholder="نام شما" />
            {errors.full_name && <p className="mt-1 text-xs text-red-500">{errors.full_name.message}</p>}
          </div>
          <div className="sm:col-span-2">
            <label className="mb-1.5 block text-xs font-medium text-gray-600">عنوان شغلی / تیتر</label>
            <div className="relative">
              <Briefcase
                className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400"
                strokeWidth={1.5}
              />
              <input {...register('headline')} className={`${inputClass} pr-10`} placeholder="طراح محصول ارشد" />
            </div>
          </div>
          <div className="sm:col-span-2">
            <label className="mb-1.5 block text-xs font-medium text-gray-600">
              نام شرکت / سازمان (اختیاری)
            </label>
            <div className="relative">
              <Building2
                className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400"
                strokeWidth={1.5}
              />
              <input {...register('company')} className={`${inputClass} pr-10`} placeholder="مثلاً: شرکت فناوری کارتین" />
            </div>
          </div>
          <div className="sm:col-span-2">
            <label className="mb-1.5 block text-xs font-medium text-gray-600">بیوگرافی</label>
            <textarea
              {...register('bio')}
              rows={3}
              className={`${inputClass} resize-none`}
              placeholder="معرفی کوتاه از خودتان..."
            />
            {errors.bio && <p className="mt-1 text-xs text-red-500">{errors.bio.message}</p>}
          </div>
        </div>
      </div>

      {/* Skills */}
      <div className={cardClass}>
        <h3 className={sectionTitle}>
          <Tag {...iconProps} />
          مهارت‌ها
        </h3>
        <div className="flex gap-2">
          <input
            value={skillInput}
            onChange={(e) => setSkillInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addSkill();
              }
            }}
            className={inputClass}
            placeholder="افزودن مهارت..."
          />
          <motion.button
            type="button"
            onClick={addSkill}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-1 rounded-xl bg-primary-600 px-4 text-sm font-medium text-white transition-colors hover:bg-primary-700"
          >
            <Plus className="h-4 w-4" strokeWidth={1.5} />
          </motion.button>
        </div>
        {skills.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-2">
            {skills.map((s) => (
              <span
                key={s}
                className="flex items-center gap-1.5 rounded-full bg-primary-50 px-3 py-1.5 text-xs font-medium text-primary-700 ring-1 ring-primary-100"
              >
                {s}
                <button
                  type="button"
                  onClick={() => removeSkill(s)}
                  className="text-primary-400 transition-colors hover:text-primary-700"
                >
                  <X className="h-3.5 w-3.5" strokeWidth={1.5} />
                </button>
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Contact info */}
      <div className={cardClass}>
        <h3 className={sectionTitle}>
          <Mail {...iconProps} />
          اطلاعات تماس
        </h3>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-gray-600">ایمیل</label>
            <div className="relative">
              <Mail
                className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400"
                strokeWidth={1.5}
              />
              <input
                {...register('email')}
                dir="ltr"
                className={`${inputClass} pr-10 text-left`}
                placeholder="you@example.com"
              />
            </div>
            {errors.email && <p className="mt-1 text-xs text-red-500">{errors.email.message}</p>}
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-gray-600">تلفن</label>
            <div className="relative">
              <Phone
                className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400"
                strokeWidth={1.5}
              />
              <input
                {...register('phone')}
                dir="ltr"
                className={`${inputClass} pr-10 text-left`}
                placeholder="+98 912 ..."
              />
            </div>
          </div>
          <div className="sm:col-span-2">
            <label className="mb-1.5 block text-xs font-medium text-gray-600">وب‌سایت</label>
            <div className="relative">
              <Globe
                className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400"
                strokeWidth={1.5}
              />
              <input
                {...register('website')}
                dir="ltr"
                className={`${inputClass} pr-10 text-left`}
                placeholder="https://..."
              />
            </div>
          </div>
        </div>
      </div>

      {/* Social links */}
      <div className={cardClass}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className={sectionTitle}>
            <Share2 {...iconProps} />
            شبکه‌های اجتماعی
          </h3>
          <span
            className={`rounded-full px-3 py-1 text-[10px] font-bold ${
              profile.is_premium
                ? 'bg-emerald-50 text-emerald-700'
                : filledSocialCount > 4
                  ? 'bg-red-50 text-red-700'
                  : 'bg-amber-50 text-amber-700'
            }`}
          >
            {profile.is_premium ? '✅ نسخه ویژه' : `${filledSocialCount} / 4 رایگان`}
          </span>
        </div>

        {/* شبکه‌های رایگان */}
        <p className="mb-3 text-xs font-bold text-gray-500">📱 شبکه‌های رایگان</p>
        <div className="grid gap-4 sm:grid-cols-2">
          {FREE_SOCIAL_PLATFORMS.map((p) => (
            <div key={p.value}>
              <label className="mb-1.5 block text-xs font-medium text-gray-600">{p.label}</label>
              <input
                dir="ltr"
                value={getSocialUrl(p.value)}
                onChange={(e) => updateSocialUrl(p.value, e.target.value)}
                className={`${inputClass} text-left`}
                placeholder={`https://${p.value}.com/...`}
              />
            </div>
          ))}
        </div>

        {/* شبکه‌های ویژه */}
        <div className="mt-6 border-t border-gray-100 pt-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-xs font-bold text-gray-500">⭐ شبکه‌های ویژه</p>
            {!profile.is_premium && (
              <Link
                to="/pricing"
                className="flex items-center gap-1 rounded-lg bg-gradient-to-l from-amber-500 to-orange-500 px-2.5 py-1 text-[10px] font-bold text-white shadow-sm transition-transform hover:scale-105"
              >
                <Crown className="h-3 w-3" strokeWidth={2} />
                ارتقا برای فعال‌سازی
              </Link>
            )}
          </div>

          {profile.is_premium ? (
            <>
              <div className="grid gap-4 sm:grid-cols-2">
                {PREMIUM_SOCIAL_PLATFORMS.map((p) => (
                  <div key={p.value}>
                    <label className="mb-1.5 block text-xs font-medium text-gray-600">{p.label}</label>
                    <input
                      dir="ltr"
                      value={getSocialUrl(p.value)}
                      onChange={(e) => updateSocialUrl(p.value, e.target.value)}
                      className={`${inputClass} text-left`}
                      placeholder={`https://${p.value}.com/...`}
                    />
                  </div>
                ))}
              </div>

              <p className="mt-5 mb-3 text-xs font-bold text-gray-500">🇮🇷 شبکه‌های داخلی ایران</p>
              <div className="grid gap-4 sm:grid-cols-2">
                {IRANIAN_SOCIAL_PLATFORMS.map((p) => (
                  <div key={p.value}>
                    <label className="mb-1.5 block text-xs font-medium text-gray-600">{p.label}</label>
                    <input
                      dir="ltr"
                      value={getSocialUrl(p.value)}
                      onChange={(e) => updateSocialUrl(p.value, e.target.value)}
                      className={`${inputClass} text-left`}
                      placeholder={`https://${p.value}.ir/...`}
                    />
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="rounded-2xl bg-gradient-to-l from-amber-50 to-orange-50 p-4 text-center ring-1 ring-amber-100">
              <p className="text-xs leading-relaxed text-gray-700">
                🔒 برای افزودن شبکه‌های اجتماعی بیشتر (توییتر، یوتیوب، تیک‌تاک و...) و شبکه‌های داخلی
                (ایتا، بله، روبیکا و...) به نسخه ویژه ارتقا دهید.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Save button */}
      <div className="sticky bottom-20 z-10 md:bottom-4">
        <motion.button
          type="submit"
          disabled={saving}
          whileHover={{ scale: 1.01, y: -2 }}
          whileTap={{ scale: 0.98 }}
          className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary-600 py-4 text-sm font-bold text-white shadow-[0_8px_24px_rgba(20,184,166,0.25)] transition-all hover:bg-primary-700 disabled:opacity-50"
        >
          {saved ? (
            <>
              <Check className="h-5 w-5" strokeWidth={1.5} />
              ذخیره شد!
            </>
          ) : saving ? (
            <div className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white" />
          ) : (
            <>
              <Save className="h-5 w-5" strokeWidth={1.5} />
              ذخیره تغییرات
            </>
          )}
        </motion.button>
      </div>
    </form>
  );
}