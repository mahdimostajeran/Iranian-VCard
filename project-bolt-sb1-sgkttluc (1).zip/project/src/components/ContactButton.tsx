import { motion } from 'framer-motion';
import { Mail, Phone, Globe } from 'lucide-react';
import { BrandIcon, brandLabels } from '@/components/BrandIcons';
import type { Platform } from '@/types';

const ICON_SIZE = 20;
const ICON_STROKE = 1.5;

interface Props {
  platform: Platform;
  url: string;
  label?: string;
}

export function ContactButton({ platform, url, label }: Props) {
  return (
    <motion.a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      whileHover={{ y: -4, scale: 1.04 }}
      whileTap={{ scale: 0.96 }}
      transition={{ type: 'spring', stiffness: 400, damping: 17 }}
      className="group flex w-[86px] flex-col items-center gap-2 rounded-2xl bg-white p-3 shadow-[0_2px_12px_rgba(0,0,0,0.04)] transition-shadow hover:shadow-[0_8px_30px_rgba(0,0,0,0.08)]"
    >
      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary-50 text-primary-600 transition-transform group-hover:scale-110 group-hover:bg-primary-100">
        <BrandIcon platform={platform} size={ICON_SIZE} />
      </div>
      <span className="w-full truncate text-center text-[11px] font-medium text-gray-600">
        {label ?? brandLabels[platform]}
      </span>
    </motion.a>
  );
}

export function DirectContactButton({
  icon: Icon,
  label,
  href,
}: {
  icon: typeof Mail;
  label: string;
  href: string;
}) {
  return (
    <motion.a
      href={href}
      whileHover={{ y: -4, scale: 1.04 }}
      whileTap={{ scale: 0.96 }}
      transition={{ type: 'spring', stiffness: 400, damping: 17 }}
      className="group flex w-[86px] flex-col items-center gap-2 rounded-2xl bg-white p-3 shadow-[0_2px_12px_rgba(0,0,0,0.04)] transition-shadow hover:shadow-[0_8px_30px_rgba(0,0,0,0.08)]"
    >
      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary-50 text-primary-600 transition-transform group-hover:scale-110 group-hover:bg-primary-100">
        <Icon className="h-5 w-5" strokeWidth={ICON_STROKE} />
      </div>
      <span className="w-full truncate text-center text-[11px] font-medium text-gray-600">
        {label}
      </span>
    </motion.a>
  );
}

export { Mail, Phone, Globe };