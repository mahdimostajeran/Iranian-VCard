import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { getMyProfile } from '@/lib/profiles';
import type { ProfileWithRelations } from '@/types';

export function useMyProfile() {
  const { user, loading: authLoading } = useAuth();
  const [profile, setProfile] = useState<ProfileWithRelations | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      setProfile(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    getMyProfile()
      .then(setProfile)
      .finally(() => setLoading(false));
  }, [user, authLoading]);

  return { profile, setProfile, loading };
}
